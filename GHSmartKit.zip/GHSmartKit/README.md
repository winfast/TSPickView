# GHSmartKit

[![CI Status](https://img.shields.io/travis/Qincc/GHSmartKit.svg?style=flat)](https://travis-ci.org/Qincc/GHSmartKit)
[![Version](https://img.shields.io/cocoapods/v/GHSmartKit.svg?style=flat)](https://cocoapods.org/pods/GHSmartKit)
[![License](https://img.shields.io/cocoapods/l/GHSmartKit.svg?style=flat)](https://cocoapods.org/pods/GHSmartKit)
[![Platform](https://img.shields.io/cocoapods/p/GHSmartKit.svg?style=flat)](https://cocoapods.org/pods/GHSmartKit)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

GHSmartKit is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'GHSmartKit'
```

## Author

Qincc, 418891087@qq.com

## License

GHSmartKit is available under the MIT license. See the LICENSE file for more info.
