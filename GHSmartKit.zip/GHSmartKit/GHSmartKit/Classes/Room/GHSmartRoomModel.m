//
//  GHSmartRoomModel.m
//  GHSmartKit
//
//  Created by Qincc on 2021/6/24.
//

#import "GHSmartRoomModel.h"
#import <MJExtension/MJExtension.h>

@implementation GHSmartRoomModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{
        @"devices":GHSmartDeviceModel.class
    };
}

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{
        @"ID":@[@"id"]
    };
}

@end
