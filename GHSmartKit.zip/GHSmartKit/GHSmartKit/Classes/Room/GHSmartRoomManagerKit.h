//
//  GHSmartRoomManagerKit.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/24.
//

#import <Foundation/Foundation.h>
#import "GHSmartRoomModel.h"
#import "GHSmartDeviceModel.h"
#import "GHCancelRequest.h"

@interface GHSmartRoomManagerKit : NSObject<GHCancelRequest>

@property (nonatomic, strong, readonly) GHSmartRoomModel *roomModel;

/// device list
@property (nonatomic, strong, readonly) NSArray <GHSmartDeviceModel *> *deviceList;

/// group list
//@property (nonatomic, strong, readonly) NSArray <TuyaSmartGroupModel *> *groupList;

+ (instancetype)roomWithRoomId:(NSString *)roomId homeId:(NSString *)homeId;

- (instancetype)int NS_UNAVAILABLE;

/// Get the room detail.
///
/// @param complete     Called when the task finishes.
- (NSString *)getRoomDetailWithComplete:(void(^)(id data, NSError *error))complete;

/// Rename the room.
///
/// @param roomName    Room name
/// @param complete     Called when the task finishes.
- (NSString *)updateRoomName:(NSString *)roomName complete:(void(^)(id data, NSError *error))complete;

/// Edit room icon.
///
/// @param icon room icon
/// @param complete  Called when the task finishes.
- (NSString *)updateIcon:(UIImage *)icon complete:(void(^)(id data, NSError *error))complete;

/// Add device to the room.
///
/// @param deviceId    Device ID
/// @param complete     Called when the task finishes.
- (NSString *)addDeviceWithDeviceId:(NSString *)deviceId complete:(void(^)(id data, NSError *error))complete;


/// Remove device from the room.
///
/// @param deviceId    Device ID
/// @param complete     Called when the task finishes.
- (NSString *)removeDeviceWithDeviceId:(NSString *)deviceId complete:(void(^)(id data, NSError *error))complete;


/// Add group to the room.
///
/// @param groupId     Group ID
/// @param complete     Called when the task finishes.
- (NSString *)addGroupWithGroupId:(NSString *)groupId complete:(void(^)(id data, NSError *error))complete;


/// Remove group from the room
///
/// @param groupId     Group ID
/// @param complete     Called when the task finishes.
- (NSString *)removeGroupWithGroupId:(NSString *)groupId complete:(void(^)(id data, NSError *error))complete;


/// Batch modification of the relationship between rooms, groups and devices.
///
/// @param deviceGroupList  List of devices or groups.
/// @param complete          Called when the task finishes.
- (NSString *)saveBatchRoomRelationWithDeviceGroupList:(NSArray <NSString *> *)deviceGroupList
                                              complete:(void(^)(id data, NSError *error))complete;

@end

