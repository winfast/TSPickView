//
//  GHSmartRoomModel.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/24.
//

#import <Foundation/Foundation.h>
#import "GHSmartDeviceModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface GHSmartRoomModel : NSObject

// room Id
@property (nonatomic, copy) NSString *ID;

// order
@property (nonatomic, strong) NSNumber *displayOrder;

// room icon
@property (nonatomic, copy) NSString *iconUrl;

// room name
@property (nonatomic, copy) NSString *name;

//
@property (nonatomic, copy) NSArray<GHSmartDeviceModel *> *devices;

@end

NS_ASSUME_NONNULL_END
