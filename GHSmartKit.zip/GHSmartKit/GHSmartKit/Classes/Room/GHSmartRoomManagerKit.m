//
//  GHSmartRoomManagerKit.m
//  GHSmartKit
//
//  Created by Qincc on 2021/6/24.
//

#import "GHSmartRoomManagerKit.h"
#import <GHNetworkModule/GHNetwork.h>
#import "GHSmartRoomModel.h"
#import "GHSmartKitStringDefine.h"
#import "GHSmartKitNetworkRequest.h"
#import <MJExtension/MJExtension.h>

@interface GHSmartRoomManagerKit ()

@property (nonatomic, copy) NSString *roomId;
@property (nonatomic, copy) NSString *homeId;

@property (nonatomic, strong) GHSmartRoomModel *roomModel;

/// device list
@property (nonatomic, strong) NSArray <GHSmartDeviceModel *> *deviceList;

@end

@implementation GHSmartRoomManagerKit

+ (instancetype)roomWithRoomId:(NSString *)roomId homeId:(NSString *)homeId {
    GHSmartRoomManagerKit *manager = GHSmartRoomManagerKit.alloc.init;
    manager.roomId = roomId;
    manager.homeId = homeId;
    return manager;
}

- (NSString *)getRoomDetailWithComplete:(void(^)(id data, NSError *error))complet {
    GHSmartKitNetworkRequest *request = [[GHSmartKitNetworkRequest alloc] initWithSmartKitRequestType:GHSmartKitRequestTypeRoomInfo];
    request.methodPath = [NSString stringWithFormat:GHSmartKit_Room_HomeId_RoomId_Info, self.homeId, self.roomId];
    return [[GHNetworkModule share] sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        if (response.status == GHNetworkResponseStatusSuccess) {
            self.roomModel = [GHSmartRoomModel mj_objectWithKeyValues:response.data];
            !complet ?: complet(self.roomModel, nil);
        } else {
            !complet ?: complet(nil, response.error);
        }
    }];
}

- (NSString *)updateRoomName:(NSString *)roomName complete:(void(^)(id data, NSError *error))complete {
    GHSmartKitNetworkRequest *request = [[GHSmartKitNetworkRequest alloc] initWithSmartKitRequestType:GHSmartKitRequestTypeRoomUpdate];
    request.normalParams = @{
        @"hoomId":self.homeId,
        @"roomId":self.roomId,
        @"roomName":roomName
    };
    return [[GHNetworkModule share] sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        if (response.status == GHNetworkResponseStatusSuccess) {
            self.roomModel.name = roomName;
            !complete ?: complete(self.roomModel, nil);
        } else {
            !complete ?: complete(nil, response.error);
        }
    }];
}

- (NSString *)updateIcon:(UIImage *)icon complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)addDeviceWithDeviceId:(NSString *)deviceId complete:(void(^)(id data, NSError *error))complete {
    GHSmartKitNetworkRequest *request = [[GHSmartKitNetworkRequest alloc] initWithSmartKitRequestType:GHSmartKitRequestTypeRoomUpdate];
    request.methodPath = [NSString stringWithFormat:GHSmartKit_Device_HomeId_RoomId_DeviceId_Add, self.homeId, self.roomId, deviceId];
    return [[GHNetworkModule share] sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        if (response.status == GHNetworkResponseStatusSuccess) {
 
            !complete ?: complete(self.roomModel, nil);
        } else {
            !complete ?: complete(nil, response.error);
        }
    }];
}

- (NSString *)removeDeviceWithDeviceId:(NSString *)deviceId complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)addGroupWithGroupId:(NSString *)groupId complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)removeGroupWithGroupId:(NSString *)groupId complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)saveBatchRoomRelationWithDeviceGroupList:(NSArray <NSString *> *)deviceGroupList
                                              complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

#pragma mark - GHCancelRequest
+ (void)cancelRequest:(NSString *)reqeustId {
    [GHNetworkModule.share cancelRequestWithRequestID:reqeustId];
}


@end
