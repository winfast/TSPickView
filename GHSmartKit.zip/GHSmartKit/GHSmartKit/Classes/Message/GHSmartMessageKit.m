//
//  GHSmartMessage.m
//  GHSmartKit
//
//  Created by Qincc on 2021/7/1.
//

#import "GHSmartMessageKit.h"
#import <GHNetworkModule/GHNetwork.h>

@implementation GHSmartMessageKit

- (NSString *)fetchMessageListWithListRequestModel:(GHSmartMessageListRequestModel *)listRequestModel
                                          complete:(void(^)(id data, NSError *error))complete {
    
    return [GHNetworkModule.share sendRequest:listRequestModel cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        !complete ?: complete(response.data, response.error);
    }];
}

- (NSString *)fetchMessageDetailListWithListRequestModel:(GHSmartMessageDetailListRequestModel *)detailListRequestModel
                                                complete:(void(^)(id data, NSError *error))complete {
    return [GHNetworkModule.share sendRequest:detailListRequestModel cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        !complete ?: complete(response.data, response.error);
    }];
}

- (NSString *)getLatestMessageWithComplete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)readMessageWithReadRequestModel:(GHSmartMessageListReadRequestModel *)readRequestModel complete:(void(^)(id data, NSError *error))complete {
    return [GHNetworkModule.share sendRequest:readRequestModel cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        !complete ?: complete(response.data, response.error);
    }];;
}

- (NSString *)deleteMessageWithDeleteRequestModel:(GHSmartMessageListReadRequestModel *)deleteRequestModel complete:(void(^)(id data, NSError *error))complete {
    return [GHNetworkModule.share sendRequest:deleteRequestModel cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        !complete ?: complete(response.data, response.error);
    }];
}


+ (void)cancelRequest:(NSString *)reqeustId {
    [GHNetworkModule.share cancelRequestWithRequestID:reqeustId];
}

@end
