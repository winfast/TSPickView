//
//  GHSmartMessageKit.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/1.
//

#import <Foundation/Foundation.h>
#import "GHCancelRequest.h"
#import "GHSmartKitNetworkRequest.h"


@interface GHSmartMessageKit : NSObject<GHCancelRequest>

/// Fetch message list.
/// @param listRequestModel Provide listRequestModel to fetch the TuyaSmartMessageListModel.
/// @param complete Called when the task finishes successfully. A list of GHSmartMessageListModel will be returned.
- (NSString *)fetchMessageListWithListRequestModel:(GHSmartMessageListRequestModel *)listRequestModel
                                    complete:(void(^)(id data, NSError *error))complete;

/// Fetch message detail list.
/// @param detailListRequestModel Provide a listRequestModel to fetch the TuyaSmartMessageListModel.
/// @param complete Called when the task finishes successfully. A list of GHSmartMessageListModel will be returned.
- (NSString *)fetchMessageDetailListWithListRequestModel:(GHSmartMessageDetailListRequestModel *)detailListRequestModel
                                          complete:(void(^)(id data, NSError *error))complete;

/// Get three types of messages if there are new ones.
/// @param complete Called when the task finishes.
- (NSString *)getLatestMessageWithComplete:(void(^)(id data, NSError *error))complete;

/// Set the message center list data to read.
/// @param readRequestModel List of read messages (support all read).
/// @param complete Called when the task finishes.
- (NSString *)readMessageWithReadRequestModel:(GHSmartMessageListReadRequestModel *)readRequestModel complete:(void(^)(id data, NSError *error))complete;


/// Delete message center list data.
/// @param deleteRequestModel List of deleted messages (delete all is not supported).
/// @param complete Called when the task finishes.
- (NSString *)deleteMessageWithDeleteRequestModel:(GHSmartMessageListReadRequestModel *)deleteRequestModel complete:(void(^)(id data, NSError *error))complete;


@end

