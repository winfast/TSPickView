//
//  GHSmartMessageListModel.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/1.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GHSmartMessageListModel : NSObject

@end

NS_ASSUME_NONNULL_END
