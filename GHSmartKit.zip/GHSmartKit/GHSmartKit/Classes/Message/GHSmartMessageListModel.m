//
//  GHSmartMessageListModel.m
//  GHSmartKit
//
//  Created by Qincc on 2021/7/1.
//

#import "GHSmartMessageListModel.h"

@implementation GHSmartMessageListModel

@end
