//
//  GOSmartShareMemberModel.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/30.
//

#import <Foundation/Foundation.h>

@interface GOSmartShareMemberModel : NSObject

/// Relationship Id
@property (nonatomic, strong) NSNumber *memberId;

/// Remark name
@property (nonatomic, copy) NSString *nickName;

/// User name (cell phone number/email number)
@property (nonatomic, copy) NSString *userName;

/// Avatar address.
@property (nonatomic, copy) NSString *iconUrl;

@end
