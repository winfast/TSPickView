//
//  GHSmartHomeMemberKit.m
//  GHSmartKit
//
//  Created by Qincc on 2021/6/29.
//

#import "GHSmartHomeMemberKit.h"
#import <GHNetworkModule/GHNetwork.h>

@implementation GHSmartHomeMemberKit

- (NSString *)removeHomeMemberWithMemberId:(long long)memberId
                                  complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

///// Update home member info
/////
///// @param memberRequestModel request model, Set the corresponding property
///// @param success            Called when the task finishes successfully.
///// @param failure            If error occurred while adding the task, this block will be called.
//- (void)updateHomeMemberInfoWithMemberRequestModel:(GHSmartHomeMemberRequestModel *)memberRequestModel
//                                           success:(TYSuccessHandler)success
//                                           failure:(TYFailureError)failure;


- (NSString *)getAuthRoomListWithHomeId:(long long)homeID
                               memberID:(long long)memberID
                               complete:(void(^)(NSArray *list, NSError *error))complete {
    return nil;
}

- (NSString *)getAuthSceneListWithHomeID:(long long)homeID
                                memberID:(long long)memberID
                                complete:(void(^)(NSArray *list, NSError *error))complete {
    return nil;
}

- (NSString *)saveAuthRoomListWithHomeId:(long long)homeID
                                memberID:(long long)memberID
                                 roomIDs:(NSArray <NSNumber *> *)roomIDs
                                complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)saveAuthSceneListWithHomeId:(long long)homeID
                                 memberID:(long long)memberID
                                  ruleIDs:(NSArray <NSString *> *)ruleIDs
                                 complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

#pragma mark - GHCancelRequest
+ (void)cancelRequest:(NSString *)reqeustId {
    [GHNetworkModule.share cancelRequestWithRequestID:reqeustId];
}


@end
