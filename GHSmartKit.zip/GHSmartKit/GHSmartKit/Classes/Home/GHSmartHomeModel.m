//
//  GHSmartHomeModel.m
//  GHSmartKit
//
//  Created by Qincc on 2021/6/23.
//

#import "GHSmartHomeModel.h"
#import <MJExtension/MJExtension.h>

@implementation GHSmartHomeModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{
        @"rooms":GHSmartRoomModel.class,
        @"devices":GHSmartDeviceModel.class
    };
}

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{
        @"ID":@[@"id"]
    };
}

@end
