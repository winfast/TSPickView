//
//  GHSmartHomeMemberModel.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/29.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GHSmartHomeMemberModel : NSObject

// member Id (long long)
@property (nonatomic, copy) NSString *memberId;

// Head portraits of members
@property (nonatomic, copy) NSString *headPic;

// name of members
@property (nonatomic, copy) NSString *name;

// role
@property (nonatomic, strong) NSNumber *role;

// home Id
@property (nonatomic, copy) NSString *homeId;

// mobile
@property (nonatomic, copy) NSString *mobile;

// user name
@property (nonatomic, copy) NSString *userName;

// uid
@property (nonatomic, copy) NSString *uid;

// state of deal
@property (nonatomic, strong) NSNumber *dealStatus;

@end

NS_ASSUME_NONNULL_END
