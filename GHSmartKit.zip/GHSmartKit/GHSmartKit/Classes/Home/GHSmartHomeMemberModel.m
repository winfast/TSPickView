//
//  GHSmartHomeMemberModel.m
//  GHSmartKit
//
//  Created by Qincc on 2021/6/29.
//

#import "GHSmartHomeMemberModel.h"

@implementation GHSmartHomeMemberModel

@end
