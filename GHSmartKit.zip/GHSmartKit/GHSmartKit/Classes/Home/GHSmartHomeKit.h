//
//  GHSmartHomeKit.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/29.
//  家庭操作类，处理当前家庭的操作,不是所有的方法全部实现

#import <Foundation/Foundation.h>
#import <GHNetworkModule/GHNetwork.h>
#import "GHCancelRequest.h"
#import "GHSmartHomeModel.h"
#import "GHSmartDeviceOTAModel.h"
#import "GHSmartRoomModel.h"
#import "GHSmartDeviceModel.h"
#import "GHCancelRequest.h"
#import "GHSmartKitNetworkRequest.h"

@class GHSmartHomeKit;

@protocol GHSmartHomeKitDelegate <NSObject>


/// The delegate of home update information, such as the name, online
///
/// @param home instance
- (void)homeDidUpdateInfo:(GHSmartHomeKit *)home;


/// The delegate of shared device list update.
///
/// @param home instance
- (void)homeDidUpdateSharedInfo:(GHSmartHomeKit *)home;


/// The delegate when a new room is added.
///
/// @param home instance
/// @param room roomModel
- (void)home:(GHSmartHomeKit *)home didAddRoom:(GHSmartRoomModel *)room;


/// The delegate when an existing room is removed.
///
/// @param home     instance
/// @param roomId   roomId
- (void)home:(GHSmartHomeKit *)home didRemoveRoom:(NSString *)roomId;


/// The delegate of room update information, such as the name.
///
/// @param home     instance
/// @param room     roomModel
- (void)home:(GHSmartHomeKit *)home roomInfoUpdate:(GHSmartRoomModel *)room;


/// The delegate of relation update of room, group and device.
///
/// @param home instance
/// @param room roomModel
- (void)home:(GHSmartHomeKit *)home roomRelationUpdate:(GHSmartRoomModel *)room;


/// The delegate when a new device is added.
///
/// @param home     instance
/// @param device   deviceModel
- (void)home:(GHSmartHomeKit *)home didAddDeivice:(GHSmartDeviceModel *)device;


/// The delegate when an existing device is removed.
///
/// @param home     instance
/// @param devId    devId
- (void)home:(GHSmartHomeKit *)home didRemoveDeivice:(NSString *)devId;


/// The delegate of device update information, such as the name.
///
/// @param home     instance
/// @param device   deviceModel
- (void)home:(GHSmartHomeKit *)home deviceInfoUpdate:(GHSmartDeviceModel *)device;


/// The delegate of device dps update.
///
/// @param home     instance
/// @param device   deviceModel
/// @param dps      dps
- (void)home:(GHSmartHomeKit *)home device:(GHSmartDeviceModel *)device dpsUpdate:(NSDictionary *)dps;


///// The delegate of warning information update.
/////
///// @param home         instance
///// @param device       deviceModel
///// @param warningInfo  warning Info
//- (void)home:(GHSmartHomeModel *)home device:(TuyaSmartDeviceModel *)device warningInfoUpdate:(NSDictionary *)warningInfo;
//
//
///// The delegate of device firmware upgrade status update.
/////
///// @param home                home instance
///// @param device              deviceModel
///// @param upgradeStatusModel  upgradeStatusModel
//- (void)home:(GHSmartHomeModel *)home device:(TuyaSmartDeviceModel *)device firmwareUpgradeStatusModel:(TuyaSmartFirmwareUpgradeStatusModel *)upgradeStatusModel;


///// the delegate when family/shared devices ota status are updated
///// @param home The home instance
///// @param otaModelList OTA model list
//- (void)home:(GHSmartHomeModel *)home didUpdateOTAModelList:(NSArray<TuyaSmartDeviceOTAModel *> *)otaModelList;

/// The delegate when a new group is added.
///
/// @param home     instance
///  @param group    groupModel
//- (void)home:(GHSmartHomeModel *)home didAddGroup:(TuyaSmartGroupModel *)group;


/// The delegate of group dps update.
///
/// @param home     instance
/// @param group    groupModel
/// @param dps      dps
//- (void)home:(GHSmartHomeModel *)home group:(TuyaSmartGroupModel *)group dpsUpdate:(NSDictionary *)dps;


/// The delegate when an existing group is removed.
///
/// @param home     instance
/// @param groupId  groupId
- (void)home:(GHSmartHomeKit *)home didRemoveGroup:(NSString *)groupId;

//
///// The delegate of group update information, such as the name.
/////
///// @param home     instance
///// @param group    groupModel
//- (void)home:(GHSmartHomeModel *)home groupInfoUpdate:(TuyaSmartGroupModel *)group;

@end


@interface GHSmartHomeKit : NSObject<GHCancelRequest>

/// 设置当前家庭设置的委托
@property (nonatomic, weak) id<GHSmartHomeKitDelegate> delegate;

/// 当前家庭的详情模型
@property (nonatomic, strong, readonly) GHSmartHomeModel *homeModel;

/// 当前家庭的房间列表
@property (nonatomic, copy, readonly) NSArray<GHSmartRoomModel *> *roomList;

/// 当前家庭的设备列表
@property (nonatomic, copy, readonly) NSArray<GHSmartDeviceModel *> *deviceList;

/// 当前家庭的组列表
@property (nonatomic, copy, readonly) NSArray *groupList;

/// 当前家庭的分享设备列表
@property (nonatomic, copy, readonly) NSArray *sharedDeviceList;

/// 当前家庭的分享组列表
@property (nonatomic, copy, readonly) NSArray *sharedGroupList;

/// 当前家庭的可升级的设备列表
@property (nonatomic, copy, readonly) NSArray<GHSmartDeviceOTAModel *> *deviceOtaList;


- (instancetype)init NS_UNAVAILABLE;

/// 初始化方式
/// @param homeId 家庭ID  该方法不是单例模式
+ (instancetype)homeWithHomeId:(NSString *)homeId;


/// After initializing the home object, you need to get the details of the family, homeModel, roomList, deviceList, groupList to have the data。
/// @param complete Called when the task finishes . TuyaSmartHomeModel will be returned and error is nil. Call when the task error, error wii be exit and homeModel is nil
- (NSString *)getHomeDetailWithComplete:(void(^)(GHSmartHomeModel *homeModel, NSError *error))complete;

/// After get home details, update device ota status
/// @param complete Called when the task finishes.
- (NSString *)getDeviceOTAStatusWithComplete:(void(^)(NSArray <GHSmartDeviceOTAModel *> *deviceOtaList, NSError *error))complete;


/// Update home info, API version 2.0.
///
/// @param homeName    Home name
/// @param geoName     City name
/// @param latitude    Lat
/// @param longitude   Lon
/// @param complete     Called when the task finishes.
- (NSString *)updateHomeInfoWithName:(NSString *)homeName
                             geoName:(NSString *)geoName
                            latitude:(double)latitude
                           longitude:(double)longitude
                            complete:(void(^)(id data, NSError *error))complete;



/// Update home info,API version 3.0
///
/// @param homeName    Home name
/// @param geoName     City name
/// @param latitude    Lat
/// @param longitude   Lon
/// @param rooms       Room name array
/// @param overWriteRoom     NSDictionary now only support "overWriteRoom":boolean
/// @param complete     Called when the task finishes.
- (NSString *)updateHomeInfoWithName:(NSString *)homeName
                             geoName:(NSString *)geoName
                            latitude:(double)latitude
                           longitude:(double)longitude
                               rooms:(NSArray *)rooms
                       overWriteRoom:(BOOL)overWriteRoom
                            complete:(void(^)(id data, NSError *error))complete;


/// Remove a home.
///
/// @param complete     Called when the task finishes successfully.
- (NSString *)dismissHomeWithComplete:(void(^)(id data, NSError *error))complete;


/// Sorting of devices and groups under the entire family.
/// @param orderList order list [@{@"bizId": @"XXX", @"bizType": @"XXX"},@{@"bizId": @"XXX",@"bizType": @"XXX"}], where bizId is the device's devId or group's groupId, device's bizType = @"6" group's bizType = @"5".
/// @param complete Called when the task finishes successfully.
- (NSString *)sortDeviceOrGroupWithOrderList:(NSArray<NSDictionary *> *)orderList
                                    complete:(void(^)(id data, NSError *error))complete;


#pragma mark - Room


/// Add a new room
///
/// @param name        Room name.
/// @param roomId    Room Id  (default is nil)
/// @param complete     Called when the task finishes.
- (NSString *)addHomeRoomWithName:(NSString *)name
                           roomId:(NSString *)roomId
                         complete:(void(^)(id data, NSError *error))complete;


/// Remove a room
///
/// @param roomId      Room  Id
/// @param complete     Called when the task finishes.
- (NSString *)removeHomeRoomWithRoomId:(NSString *)roomId
                              complete:(void(^)(id data, NSError *error))complete;


/// Homes sort
///
/// @param roomList    Homes list
/// @param complete     Called when the task finishes.
- (NSString *)sortRoomList:(NSArray <GHSmartRoomModel *> *)roomList
                  complete:(void(^)(id data, NSError *error))complete;


#pragma mark - home member

/// Get home member list
///
/// @param complete     Called when the task finishes successfully. A list of TuyaSmartHomeMemberModel will be returned and error is nil.
///                   Called when the task finishes error. error will be returned and memberList is nil.
- (NSString *)getHomeMemberListWithComplete:(void(^)(id data, NSError *error))complete;;


/// Add a home member
///
/// @param requestModel member model
/// @param complete      Called when the task finishes.
- (NSString *)addHomeMemberWithAddMemeberRequestModel:(GHSmartHomeAddMemberRequestModel *)requestModel
                                       complete:(void(^)(id data, NSError *error))complete;

/// Accept or reject to shared home
///
/// @param accept       A boolean value indicates whether to accept the invitation.
/// @param complete      Called when the task finishes.
- (NSString *)joinFamilyWithAccept:(BOOL)accept
                          complete:(void(^)(id data, NSError *error))complete;


/// Sync home device list
///
/// @complete success Called when the task finishes.
- (NSString *)syncHomeDeviceListWithComplete:(void(^)(id data, NSError *error))complete;

@end


