//
//  GHSmartHomeMemberKit.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/29.
//

#import <Foundation/Foundation.h>
#import "GHCancelRequest.h"

@interface GHSmartHomeMemberKit : NSObject<GHCancelRequest>

/// Remove a home member.
///
/// @param memberId    Member Id
/// @param complete     Called when the task finishes.
- (NSString *)removeHomeMemberWithMemberId:(long long)memberId
                                  complete:(void(^)(id data, NSError *error))complete;


///// Update home member info
/////
///// @param memberRequestModel request model, Set the corresponding property
///// @param success            Called when the task finishes successfully.
///// @param failure            If error occurred while adding the task, this block will be called.
//- (void)updateHomeMemberInfoWithMemberRequestModel:(GHSmartHomeMemberRequestModel *)memberRequestModel
//                                           success:(TYSuccessHandler)success
//                                           failure:(TYFailureError)failure;


/// Get a list of optional rooms.
/// @param homeID homeID
/// @param memberID member id
/// @param complete Called when the task finishes.
- (NSString *)getAuthRoomListWithHomeId:(long long)homeID
                               memberID:(long long)memberID
                               complete:(void(^)(NSArray *list, NSError *error))complete;

/// Get a list of optional scenes or automations.
/// @param homeID homeID
/// @param memberID member id
/// @param complete Called when the task finishes.
- (NSString *)getAuthSceneListWithHomeID:(long long)homeID
                                memberID:(long long)memberID
                                complete:(void(^)(NSArray *list, NSError *error))complete;


/// Update the list of rooms to which custom roles have access.
/// @param homeID homeID
/// @param memberID member id
/// @param roomIDs List of room IDs with permission.
/// @param complete Called when the task finishes.
- (NSString *)saveAuthRoomListWithHomeId:(long long)homeID
                                memberID:(long long)memberID
                                 roomIDs:(NSArray <NSNumber *> *)roomIDs
                                complete:(void(^)(id data, NSError *error))complete;


/// Update the list of scenes to which custom roles have access.
/// @param homeID homeID
/// @param memberID member id
/// @param ruleIDs List of scene IDs with permissions.
/// @param complete Called when the task finishes.
- (NSString *)saveAuthSceneListWithHomeId:(long long)homeID
                                 memberID:(long long)memberID
                                  ruleIDs:(NSArray <NSString *> *)ruleIDs
                                 complete:(void(^)(id data, NSError *error))complete;

@end
