//
//  GHSmartHomeKit.m
//  GHSmartKit
//
//  Created by Qincc on 2021/6/29.
//  TODO:部分的委托还不知道什么功能，给我的感觉是有可能是HomeKit的回调，所以不一定需要实现

#import "GHSmartHomeKit.h"
#import "GHSmartKitStringDefine.h"
#import <MJExtension/MJExtension.h>

@interface GHSmartHomeKit ()

@property (nonatomic, copy) NSString *homeId;

/// 当前家庭的详情模型
@property (nonatomic, strong) GHSmartHomeModel *homeModel;

/// 当前家庭的房间列表
@property (nonatomic, copy) NSArray<GHSmartRoomModel *> *roomList;

/// 当前家庭的设备列表
@property (nonatomic, copy) NSArray<GHSmartDeviceModel *> *deviceList;

/// 当前家庭的组列表
@property (nonatomic, copy) NSArray *groupList;

/// 当前家庭的分享设备列表
@property (nonatomic, copy) NSArray *sharedDeviceList;

/// 当前家庭的分享组列表
@property (nonatomic, copy) NSArray *sharedGroupList;

/// 当前家庭的可升级的设备列表
@property (nonatomic, copy) NSArray<GHSmartDeviceOTAModel *> *deviceOtaList;

@end

@implementation GHSmartHomeKit

+ (instancetype)homeWithHomeId:(NSString *)homeId {
    GHSmartHomeKit *homeKit = GHSmartHomeKit.alloc.init;
    homeKit.homeId = homeId;
    return homeKit;
}

- (NSString *)getHomeDetailWithComplete:(void(^)(GHSmartHomeModel *homeModel, NSError *error))complete {
    NSString *method = [NSString stringWithFormat:GHSmartKit_Home_Info, self.homeId];
    GHSmartKitNetworkRequest *request = [GHSmartKitNetworkRequest.alloc initWithSmartKitRequestType:GHSmartKitRequestTypeHomeDetail];
    request.methodPath = method;
    return [GHNetworkModule.share sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
       //数据解析
        self.homeModel = [GHSmartHomeModel mj_objectWithKeyValues:response.data];
        self.roomList = self.homeModel.rooms;
        self.deviceList = self.homeModel.devices;
        if (response.status == GHNetworkResponseStatusSuccess) {
            !complete ?: complete(self.homeModel, nil);
        } else {
            !complete ?: complete(nil, response.error);
        }
    }];
}

- (NSString *)getDeviceOTAStatusWithComplete:(void(^)(NSArray <GHSmartDeviceOTAModel *> *deviceOtaList, NSError *error))complete {
    return nil;
}

- (NSString *)updateHomeInfoWithName:(NSString *)homeName
                             geoName:(NSString *)geoName
                            latitude:(double)latitude
                           longitude:(double)longitude
                            complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)updateHomeInfoWithName:(NSString *)homeName
                             geoName:(NSString *)geoName
                            latitude:(double)latitude
                           longitude:(double)longitude
                               rooms:(NSArray *)rooms
                       overWriteRoom:(BOOL)overWriteRoom
                            complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)dismissHomeWithComplete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)sortDeviceOrGroupWithOrderList:(NSArray<NSDictionary *> *)orderList
                                    complete:(void(^)(id data, NSError *error))complete {
    return nil;
}


#pragma mark - Room

- (NSString *)addHomeRoomWithName:(NSString *)name
                           roomId:(NSString *)roomId
                         complete:(void(^)(id data, NSError *error))complete; {
    GHSmartKitNetworkRequest *request = [GHSmartKitNetworkRequest.alloc initWithSmartKitRequestType:GHSmartKitRequestTypeRoomAdd];
    NSMutableDictionary *normalParams = NSMutableDictionary.alloc.init;
    [normalParams setValue:name forKey:@"roomName"];
    [normalParams setValue:roomId forKey:@"roomId"];
    [normalParams setValue:self.homeId forKey:@"homeId"];
    request.normalParams = normalParams;
    return [GHNetworkModule.share sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        if (response.status == GHNetworkResponseStatusSuccess) {
           
            GHSmartRoomModel *roomModel = GHSmartRoomModel.alloc.init;
            roomModel.ID = response.data;
            roomModel.name = name;
            roomModel.devices = @[];
            roomModel.iconUrl = @"";
            
            //将该房间添加到数组中，更新本地缓存
            NSMutableArray *currRooms = self.roomList.mutableCopy;
            [currRooms addObject:roomModel];
            self.roomList = currRooms;
            
            !complete ?: complete(roomModel, nil);
        } else {
            !complete ?: complete(nil, response.error);
        }
    }];
}

- (NSString *)removeHomeRoomWithRoomId:(NSString *)roomId
                              complete:(void(^)(id data, NSError *error))complete {
    GHSmartKitNetworkRequest *request = [GHSmartKitNetworkRequest.alloc initWithSmartKitRequestType:GHSmartKitRequestTypeRoomRemove];

    request.methodPath = [NSString stringWithFormat:GHSmartKit_Room_HomeId_RoomId_Remove, self.homeId, roomId];
    return [GHNetworkModule.share sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        if (response.status == GHNetworkResponseStatusSuccess) {
           
            NSUInteger index = [[self.roomList valueForKey:@"ID"] indexOfObject:roomId];
            if (index == NSNotFound) {
                return;
            }
            //清空数组中的元素
            NSMutableArray *roomsArray = self.roomList.mutableCopy;
            [roomsArray removeObjectAtIndex:index];
            !complete ?: complete(roomId, nil);
        } else {
            !complete ?: complete(nil, response.error);
        }
    }];
}

- (NSString *)sortRoomList:(NSArray <GHSmartRoomModel *> *)roomList
                  complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

#pragma mark - home member

- (NSString *)getHomeMemberListWithComplete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)addHomeMemberWithAddMemeberRequestModel:(GHSmartHomeAddMemberRequestModel *)requestModel
                                             complete:(void(^)(id data, NSError *error))complete {
    return [GHNetworkModule.share sendRequest:requestModel cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        !complete ?: complete(response.data, response.error);
    }];
}

- (NSString *)joinFamilyWithAccept:(BOOL)accept
                          complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)syncHomeDeviceListWithComplete:(void(^)(id data, NSError *error))complete {
    return nil;
}

#pragma mark - GHCancelRequest
+ (void)cancelRequest:(NSString *)reqeustId {
    [GHNetworkModule.share cancelRequestWithRequestID:reqeustId];
}


@end
