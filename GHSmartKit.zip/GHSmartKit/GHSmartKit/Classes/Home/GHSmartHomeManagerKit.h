//
//  GHSmartHomeManagerKit.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/23.
//  家庭管理类， 用来获取家庭列表，添加，排序

#import <Foundation/Foundation.h>
#import "GHSmartHomeModel.h"
#import "GHCancelRequest.h"
#import <GHNetworkModule/GHNetwork.h>

@class GHSmartHomeManagerKit;

@protocol GHSmartHomeManagerDelegate <NSObject>

/// The delegate when a new home is added.
///
/// @param manager  instance
/// @param home     homeModel
- (void)homeManager:(GHSmartHomeManagerKit *)manager didAddHome:(GHSmartHomeModel *)home;

/// The delegate when an existing home is removed.
///
/// @param manager  instance
/// @param homeId   homeId
- (void)homeManager:(GHSmartHomeManagerKit *)manager didRemoveHome:(long long)homeId;

/// MQTT service connection success callback.
//- (void)serviceConnectedSuccess;

@end

@interface GHSmartHomeManagerKit : NSObject<GHCancelRequest>

@property (nonatomic, weak) id <GHSmartHomeManagerDelegate> delegate;

@property (nonatomic, copy, readonly) NSArray <GHSmartHomeModel *> *homes;

/// Get homes list. If you want to get home details, need to initialize a home, call getHomeDetailWithCpmplete:
///
/// @param complete Called when the task finishes. A list of TuyaSmartHomeModel will be returned or error.
- (NSString *)getHomeListWithComplete:(void(^)(NSArray <GHSmartHomeModel *> *homes, NSError *error))complete;


/// Adds a new home
/// 如果没有该值就给nil
/// @param homeName    Home name
/// @param geoName     City name
/// @param rooms       Rooms list
/// @param latitude    Latitude
/// @param longitude   Longitude
/// @param complete     Called when the task finishes.
- (NSString *)addHomeWithName:(NSString *)homeName
                      geoName:(NSString *)geoName
                        rooms:(NSArray <NSString *>*)rooms
                     latitude:(NSString *)latitude
                    longitude:(NSString *)longitude
                     complete:(void(^)(id data, NSError *error))complete;


/// Home sort
///
/// @param homeList    Homes list
/// @param complete     Called when the task finishes.
- (NSString *)sortHomeList:(NSArray <GHSmartHomeModel *> *)homeList
                  complete:(void(^)(id data, NSError *error))complete;

@end

