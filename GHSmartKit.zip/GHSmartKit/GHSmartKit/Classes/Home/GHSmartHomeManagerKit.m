//
//  GHSmartHomeManagerKit.m
//  GHSmartKit
//
//  Created by Qincc on 2021/6/23.
//

#import "GHSmartHomeManagerKit.h"
#import "GHSmartKitNetworkRequest.h"
#import "GHSmartConstValue.h"
#import <MJExtension/MJExtension.h>

@interface GHSmartHomeManagerKit ()

@property (nonatomic, copy) NSArray <GHSmartHomeModel *> *homes;

@end

@implementation GHSmartHomeManagerKit

- (NSString *)getHomeListWithComplete:(void(^)(NSArray <GHSmartHomeModel *> *homes, NSError *error))complete {
    GHSmartKitNetworkRequest *request = [GHSmartKitNetworkRequest.alloc initWithSmartKitRequestType:GHSmartKitRequestTypeHomeList];
    return [GHNetworkModule.share sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        if (response.status == GHNetworkResponseStatusSuccess) {
            self.homes = [GHSmartHomeModel mj_objectArrayWithKeyValuesArray:response.data];
            !complete ?: complete(self.homes, nil);
        } else {
            !complete ?: complete(nil, response.error);
        }
    }];
}

- (NSString *)addHomeWithName:(NSString *)homeName
                      geoName:(NSString *)geoName
                        rooms:(NSArray <NSString *>*)rooms
                     latitude:(NSString *)latitude
                    longitude:(NSString *)longitude
                     complete:(void(^)(id data, NSError *error))complete {
    GHSmartKitNetworkRequest *request = [GHSmartKitNetworkRequest.alloc initWithSmartKitRequestType:GHSmartKitRequestTypeHomeCreate];
    NSMutableDictionary *param = NSMutableDictionary.alloc.init;
    [param setValue:homeName forKey:@"name"];
    [param setValue:geoName forKey:@"geoName"];
    [param setValue:rooms forKey:@"roomList"];
    [param setValue:latitude forKey:@"lat"];
    [param setValue:longitude forKey:@"lon"];
    
    return [GHNetworkModule.share sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        //先处理数据本地缓存数据
        NSMutableArray *currHomes = self.homes.mutableCopy;
        GHSmartHomeModel *homeModel = [GHSmartHomeModel mj_objectWithKeyValues:response.data];
        [currHomes addObject:homeModel];
        self.homes = currHomes;
        
        //处理回调
        !complete ?: complete(homeModel, response.error);
        if ([self.delegate respondsToSelector:@selector(homeManager:didAddHome:)]) {
            [self.delegate homeManager:self didAddHome:homeModel];
        }
    }];
}

- (NSString *)sortHomeList:(NSArray <GHSmartHomeModel *> *)homeList
                  complete:(void(^)(id data, NSError *error))complete {
    GHSmartKitNetworkRequest *request = [GHSmartKitNetworkRequest.alloc initWithSmartKitRequestType:GHSmartKitRequestTypeHomeList];
    return [GHNetworkModule.share sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        !complete ?: complete(response.data, response.error);
        //需要重新刷新房间列表
//        if ([self.delegate respondsToSelector:@selector(homeManager:didAddHome:)]) {
//            [self.delegate homeManager:self didAddHome:response.data];
//        }
    }];
}

#pragma mark - GHCancelRequest
+ (void)cancelRequest:(NSString *)reqeustId {
    [GHNetworkModule.share cancelRequestWithRequestID:reqeustId];
}

@end
