//
//  GHSmartHomeModel.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import "GHSmartRoomModel.h"
#import "GHSmartDeviceModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface GHSmartHomeModel : NSObject

/// 家庭ID （long long）
@property (nonatomic, copy) NSString *ID;

/// 经纬度 （double）
@property (nonatomic, copy) NSString *lat;
@property (nonatomic, copy) NSString *lon;

/// GHHomeRoleType
@property (nonatomic, strong) NSNumber *role;

/// GHomeStatus
@property (nonatomic, strong) NSNumber *dealStatus;

/// order
@property (nonatomic, strong) NSNumber *displayOrder;

/// inviter's name
@property (nonatomic, copy) NSString *nickName;

/// home Background Pictures
@property (nonatomic, copy) NSString *backgroundURL;

/// home name
@property (nonatomic, copy) NSString *name;

/// home geographic location
@property (nonatomic, copy) NSString *geoName;

@property (nonatomic, copy) NSArray<GHSmartRoomModel *> *rooms;

@property (nonatomic, copy) NSArray<GHSmartDeviceModel *> *devices;

@end

NS_ASSUME_NONNULL_END
