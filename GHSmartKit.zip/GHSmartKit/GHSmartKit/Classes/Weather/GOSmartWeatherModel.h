//
//  GOSmartWeatherModel.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/30.
//

#import <Foundation/Foundation.h>


@interface GOSmartWeatherModel : NSObject

/// The weather icon.
@property (nonatomic, copy) NSString *icon;

/// Weather parameter name
@property (nonatomic, copy) NSString *name;

/// Parameter unit.
@property (nonatomic, copy) NSString *unit;

/// Parameter ID.
@property (nonatomic, strong) NSNumber *objId;

/// Whether to display; business layer not used.
@property (nonatomic, strong) NSNumber *show;

/// Weather parameter value.
@property (nonatomic, copy) NSString *value;

@property (nonatomic, copy) NSString *metaValue;
@property (nonatomic, copy) NSString *fieldName;
@property (nonatomic, copy) NSString *roomName;

@end
