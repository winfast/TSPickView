//
//  GHAsycSocketService.h
//  GHAsycSocketService
//
//  Created by Qincc on 2021/2/5.
//

typedef enum : UInt16 {
	//TCP
    GHOpCodeLogin = 0x8000,  					//App端登陆
    GHOpCodeLoginRecieve = 0x8001, 				//设备端收到的登录信息返回
    GHOpCodeReadDeviceStatus = 0x8010, 			//App端读取设备状态
    GHOpCodeReadDeviceStatusRecieve = 0x8011, 	//设备端收到的读取状态后的消息上报
    GHOpCodeWriteDeviceStatus = 0x8020,			//APP端修改状态
    GHOpCodeWriteDeviceStatusRecicev = 0x8021, 	//设备端修改成功后的状态上报
	GHOpCodeDeviceStatusUpdate = 0x8031,		//第三方修改状态上报
	GHOpCodeHeardbeat = 0x8888,
	
	//配网（不一定要使用）(192.168.0.1  6667)
	GHOpCodeWiFiList = 0x9010,  //APP端获取WiFi列表
	GHOpCodeWiFiListRecieve = 0x9011,  //设备端WiFi列表上报
	GHOpCodeConfigwiFiInfo = 0x9020, //APP端发送WiFi和SSID
	GHOpCodeConfigwiFiInfoRecieve = 0x9021, //设备端收到WiFi SSID和密码的回复
	GHOpCodeConfigWiFiError = 0x9031,    //设备端配网结果上报
	GHOpCodeConfigGetDeviceId = 0x9040,  //获取设备信息
	GHOpCodeConfigGetDeviceIdRecieve = 0x9041, //设备端返回信息
	
    //UDP
	GHOpCodeUDPReport = 0x8090,   //UDP状态上报
    GHOpCodeUDPSearch = 0xFFFF,		//UDP搜索
} GHOpCode;

typedef enum : UInt8 {
    GHStatusCodeSuccess = 0,                //执行成功
    GHStatusNormalError,                    //通用错误
    GHStatusSystemError,                    //系统内部错误
    GHStatusBusinessError,                  //业务执行失败
    GHStatusNotLogin,                       //不允许登录
    GHStatusCodeOperationCodeError = 21,    //操作码格式错误
    GHStatusCodeOperationCodeNotSupport = 22,//操作码错误
    GHStatusCodeVersionNotSuport = 31,      //版本不支持
    GHStatusCodePayloadError = 51,          //payload格式错误
    GHStatusCodePayloadDecryptError = 52,   //payload解密失败
	GHStatusCodeWiFiError = 60,             //配网失败
} GHStatusCode;

typedef struct HeaderData {
    UInt8 protocol;     // 协议版本
    UInt8 serviceType;  // 业务类型
    UInt16 sequenceld;  // 消息序列号
    UInt32 dataLenth;   // 数据包长度
} GHHeaderData;

typedef struct DataInfo {
    UInt8 version : 4;
    UInt8 security: 1;
    UInt8 reserved: 3;
    UInt8 statusCode;
    UInt16 opcode;
} GHDataInfo;
/*
 位域的定义形式为：类型说明符号 位域名：位域长度
 **长度单位是bit,而不是字节
 **位域是从低位向最高位分配内存的
 */

#import "GHUdpServiceSocket.h"


