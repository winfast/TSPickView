//
//  NSData+AES.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/1.
//

#import <Foundation/Foundation.h>

@interface NSData (AES)

/// 加密 ECB
/// @param securityKey 加密的Key
- (NSData *)aes128EncryptWithSecurityKey:(NSString *)securityKey;

/// 解密 CBC
/// @param securityKey 解谜的Key
- (NSData *)aes128DecryptWithSecurityKey:(NSString *)securityKey;

/// 加密 CBC
/// @param securityKey 加密的Key
- (NSData *)aes128EncryptWithSecurityKey:(NSString *)securityKey iv:(NSString *)iv;


/// 解密 ECB
/// @param securityKey 解谜的Key
- (NSData *)aes128DecryptWithSecurityKey:(NSString *)securityKey iv:(NSString *)iv;


/// 加密 ECB
/// @param securityKey 加密的Key
- (NSData *)aes256EncryptWithSecurityKey:(NSString *)securityKey;

/// 解密 ECB
/// @param securityKey 解谜的Key
- (NSData *)aes256DecryptWithSecurityKey:(NSString *)securityKey;


@end


@interface NSData (HexadecimalString)

/// 将NSData转换成16进制的字符串
- (NSString *)hexStringFromData;

/// 将16进制的字符串转换成NSData
/// @param hexString 16进制的字符串
- (NSData *)dataFromHexString:(NSString *)hexString;

@end

@interface NSData (Base64Encode)

/**
 * Base64编码
 */
- (NSData *)base64Encode;
 
/**
 * Base64解码
 */
- (NSData *)base64Dencode;

@end
