//
//  GHUdpServiceSocket.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/1.
//  Copyright © 2021 Cuco Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@class GHUdpServiceSocket;

@protocol GHUdpServiceSocketDelegate <NSObject>

/// 收到消息的委托
- (void)recieveWithSocket:(GHUdpServiceSocket *)socket data:(NSDictionary *)data;

@end

@interface GHUdpServiceSocket : NSObject

@property (nonatomic, weak) id<GHUdpServiceSocketDelegate> delegate;

/// 收到消息的回调
@property (nonatomic, copy) void (^recieveUdpServiceSocketData)(GHUdpServiceSocket *socket, NSDictionary *data);

- (instancetype)init NS_UNAVAILABLE;

/// 单例模式， 初始化
+ (instancetype)share;

/// 启动UDP服务器
- (void)startUDPServiceSocketWithPort:(NSInteger)port;

/// 发送消息
/// @param ipAddress 目标IP地址
/// @param port 目标端口
- (void)sendDataWithIPAddress:(NSString *)ipAddress port:(NSInteger)port;

/// 关闭UDP服务器
- (void)closetUDPServiceSocket;

@end
