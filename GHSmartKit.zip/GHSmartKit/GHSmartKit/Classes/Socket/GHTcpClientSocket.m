//
//  GHTcpClientSocket.m
//  GHSmartKit
//
//  Created by Qincc on 2021/7/1.
//

#import "GHTcpClientSocket.h"

#import <JSONKit/JSONKit.h>
#import "NSData+GHSmartKit.h"

@interface GHTcpClientSocket ()<GCDAsyncSocketDelegate>

/// TCP实例对象
@property (nonatomic, strong) GCDAsyncSocket *socket;
@property (nonatomic) NSInteger sendNum;
@property (nonatomic, strong) NSLock *readDataLock;
@property (nonatomic, strong) NSLock *writeDataLock;
@property (nonatomic, strong) NSMutableData *haveReadData;

@end

@implementation GHTcpClientSocket

/// 初始化单例模式
+ (instancetype)share {
    static dispatch_once_t onceToken;
    static GHTcpClientSocket *tcpSocet;
    dispatch_once(&onceToken, ^{
        tcpSocet = GHTcpClientSocket.currDeviceSocket;
    });
    return tcpSocet;
}

/// 初始化socket
+ (instancetype)currDeviceSocket {
    GHTcpClientSocket *tcpSocket = GHTcpClientSocket.alloc.init;
    return tcpSocket;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.haveReadData = NSMutableData.alloc.init;
        self.readDataLock = NSLock.alloc.init;
        self.writeDataLock = NSLock.alloc.init;
        self.sendNum = 0;
    }
    return self;
}


- (BOOL)connectTCPService:(NSString *)ipAddress port:(NSInteger)port {
    dispatch_queue_t mainQueue = dispatch_get_main_queue();
    self.socket = [[GCDAsyncSocket alloc] initWithDelegate:self delegateQueue:mainQueue];
    NSError *error = nil;
    if (![self.socket connectToHost:ipAddress onPort:port withTimeout:10 error:&error]) {
        NSLog(@"code = %ld, domian = %@", (long)error.code, error.domain);
        return NO;
    }
    return YES;
}

/// 断开TCP链接
- (void)disConnectTcpService {
    [self clearCallback];
    self.isConnected = NO;
    [self.socket setDelegate:nil];
    [self.socket disconnect];
    self.socket = nil;
    [self.haveReadData replaceBytesInRange:NSMakeRange(0, self.haveReadData.length) withBytes:NULL length:0];
}

- (void)clearCallback {
    self.delegate = nil;
    self.connectedSuccess = nil;
    self.recieveTcpSocket = nil;
}

/// 发送TCP消息
/// @param dict 发送的消息内容
- (void)postData:(NSDictionary *)dict {
    
}

- (void)postDataWithOpCode:(GHOpCode)opCode status:(NSDictionary *)status {
    [self postDataWithOpCode:opCode security:YES status:status sequenceld:self.sendNum];
}

- (void)postDataWithOpCode:(GHOpCode)opCode security:(BOOL)security status:(NSDictionary *)status {
    [self postDataWithOpCode:opCode security:security status:status sequenceld:self.sendNum];
}

- (void)postDataWithOpCode:(GHOpCode)opCode security:(BOOL)security status:(NSDictionary *)status sequenceld:(UInt16)sequenceld{
    [self.writeDataLock lock];
    NSMutableData *postData = NSMutableData.data;
    NSData *base64Data = nil;
    if (status.count > 0) {
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:status options:0 error:nil];
        if (security == YES) {
//            NSData *encryptData = [GHEncryption AES128EncryptDataWithData:jsonData secretKey:self.secretKey];  //对status进行加密
            NSData *encryptData = [jsonData aes128EncryptWithSecurityKey:self.securityKey iv:self.iv];
            base64Data = [encryptData base64Encode];
        } else {
            base64Data = jsonData;
        }
    }
    
    GHHeaderData data;
    data.protocol = 0x01;
    data.serviceType = 0x01;
    data.sequenceld = OSSwapHostToBigInt16(sequenceld);
    UInt32 result = OSSwapHostToBigInt32((UInt32)(base64Data.length + sizeof(GHDataInfo)));
    data.dataLenth = result;
    //data.sequenceld = sequenceld;
    //data.dataLenth = (UInt32)encryptData.length + sizeof(GHDataInfo);  //数据长度
    [postData appendData:[NSData dataWithBytes:&data length:sizeof(GHHeaderData)]];
    
    //数据部分的协议
    GHDataInfo dataInfo;
    dataInfo.version = 0x01;
    dataInfo.security = 0x01;
    if (security == NO) {
        dataInfo.security = 0x00;
    }
    dataInfo.reserved = 0x00;
    dataInfo.statusCode = 0;
    dataInfo.opcode = OSSwapHostToBigInt16(opCode);
    [postData appendData:[NSData dataWithBytes:&dataInfo length:sizeof(GHDataInfo)]];
    if (base64Data) {
        [postData appendData:base64Data];
    }
#if 0   //验证数据的正确性
    GHHeaderData currHeadData;
    [postData getBytes:&currHeadData range:NSMakeRange(0, sizeof(GHHeaderData))];
    NSLog(@"protocol = %d, serviceType = %d sequenceld = %d dataLenth = %d", currHeadData.protocol, currHeadData.serviceType, OSSwapHostToBigInt16(currHeadData.sequenceld), OSSwapHostToBigInt32(currHeadData.dataLenth));

    GHDataInfo currDataInfo;
    [postData getBytes:&currDataInfo range:NSMakeRange(sizeof(GHHeaderData), sizeof(GHDataInfo))];
    NSLog(@"version = %d, security = %d reserved = %d statusCode = %d opcode = %d", currDataInfo.version, currDataInfo.security, currDataInfo.reserved, currDataInfo.statusCode, OSSwapHostToBigInt16(currDataInfo.opcode));
    
    NSData *currJsonData = [postData subdataWithRange:NSMakeRange(sizeof(GHHeaderData) + sizeof(GHDataInfo), postData.length - sizeof(GHHeaderData) - sizeof(GHDataInfo))];
    NSData *base64Decode = [GHEncryption base64Dencode:currJsonData];
    NSData *decryptData = [GHEncryption AES128DecryptDataWithData:base64Decode secretKey:self.secretKey];  //解密
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:decryptData
                                                         options:kNilOptions
                                                           error:nil];
    NSLog(@"TCP Post JSon = %@", json.description);
#endif
    
    NSLog(@"postData = %@", postData);
    
    [self.socket writeData:postData withTimeout:10 tag:self.sendNum];

    self.sendNum++;
    [self.writeDataLock unlock];
}

#pragma mark - GCDAsyncSocketDelegate

- (void)socket:(GCDAsyncSocket *)sock didConnectToHost:(NSString *)host port:(uint16_t)port {
    [sock readDataWithTimeout:-1 tag:self.sendNum];
    
    // 清除连接失败的回调
    if (self.connectedFailed) {
        self.connectedFailed = nil;
    }
    
    // 把TCP状态设置为成功
    self.isConnected = YES;
    
    !self.connectedSuccess ?: self.connectedSuccess(self);
    if ([self.delegate respondsToSelector:@selector(connectedSuccess:)]) {
        [self.delegate connectedSuccess:self];
    }
}

- (void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag {
    self.sendNum++;
    
    [self.haveReadData appendData:data];
    do {
        [self.readDataLock lock];
        
        //消息头的长度
        NSUInteger headDataLenth = sizeof(GHHeaderData);
        //收到的数据长度不够， 需要继续接收新的数据
        if (self.haveReadData.length < headDataLenth) {
            [self.readDataLock unlock];
            [sock readDataWithTimeout:-1 tag:self.sendNum];
            return;
        }
        
        //获取消息头的内容
        GHHeaderData headData;
        [self.haveReadData getBytes:&headData range:NSMakeRange(0, headDataLenth)];
        UInt8 protocolVersion = headData.protocol;   //协议版本
        UInt8 serviceType = headData.serviceType;   //业务类型
        UInt16 sequenceId = OSSwapHostToBigInt16(headData.sequenceld);    //序列号
        UInt32 dataLenth = OSSwapHostToBigInt32(headData.dataLenth);      //数据包长度
        
        // 协议版本 默认值为0x01
        if (protocolVersion != 0x01) {
            [self.haveReadData replaceBytesInRange:NSMakeRange(0, [self.haveReadData length]) withBytes:NULL length:0];
            [self.readDataLock unlock];
            [sock readDataWithTimeout:-1 tag:self.sendNum];
            return;
        }
        
        // 业务类型 默认值为0x01
        if (serviceType != 0x01) {
            [self.haveReadData replaceBytesInRange:NSMakeRange(0, [self.haveReadData length]) withBytes:NULL length:0];
            [self.readDataLock unlock];
            [sock readDataWithTimeout:-1 tag:self.sendNum];
            return;
        }
        
        //如果消息部分长度小于4的时候
        if (dataLenth < sizeof(GHDataInfo)) {
            [self.haveReadData replaceBytesInRange:NSMakeRange(0, [self.haveReadData length]) withBytes:NULL length:0];
            [self.readDataLock unlock];
            [sock readDataWithTimeout:-1 tag:self.sendNum];
            return;
        }
        
        //如果数据的长度不够，继续接收新的数据
        if (dataLenth + headDataLenth > self.haveReadData.length) {
            [self.readDataLock unlock];
            [sock readDataWithTimeout:-1 tag:self.sendNum];
            return;
        }
        
        //获取设备端有效的数据
        NSData *deviceData = [self.haveReadData subdataWithRange:NSMakeRange(headDataLenth, dataLenth)];
        //获取消息的头4个字节的内容，用来处理消息信息
        GHDataInfo dataInfo;
        [deviceData getBytes:&dataInfo range:NSMakeRange(0, sizeof(GHDataInfo))];
        UInt8 version = dataInfo.version;   // 业务版本号
        UInt8 security = dataInfo.security; // 是否加密 1加密。0不加密
        UInt8 reserved = dataInfo.reserved; // 保留字段，默认值0
        GHStatusCode statusCode = dataInfo.statusCode; //状态码，标识业务处理的状态
        GHOpCode opcode = OSSwapHostToBigInt16(dataInfo.opcode);        //操作码（采用网络字节序), 如下表所示
        
        //如果返回状态码不是成功或者版本号不相等，不处理这条消息
        if (statusCode != GHStatusCodeSuccess) {
            [self.haveReadData replaceBytesInRange:NSMakeRange(0, headDataLenth + dataLenth) withBytes:NULL length:0];
            [self parseWithSocket:sock opCode:opcode statusCode:statusCode status:nil];
            [self.readDataLock unlock];
            [sock disconnect];
            return;
        } else {
            if (dataLenth == sizeof(GHDataInfo)) {  //没有消息内容
                [self.haveReadData replaceBytesInRange:NSMakeRange(0, headDataLenth + dataLenth) withBytes:NULL length:0];
                [self.readDataLock unlock];
            } else {
                //设备端发送的实际数据 从第12个字节开始， 长度是dataLen - 消息头长度（sizeof(GHDataInfo)）
                NSDictionary *json;
                NSData *deviceSmartData = [self.haveReadData subdataWithRange:NSMakeRange(headDataLenth + sizeof(GHDataInfo), dataLenth - sizeof(GHDataInfo))];
                if (security == 0) {  //不加密
                    json = [deviceSmartData objectFromJSONDataWithParseOptions:JKParseOptionValidFlags];
                } else {
                    // base64解密
                    NSData *base64Decode = [deviceSmartData base64Dencode];
                    //解密 将获取的数据解密
                    NSData *decryptData = [base64Decode aes128DecryptWithSecurityKey:self.securityKey iv:self.iv];
                    //解密后的数据转换成Json 不实用系统的解析是因为给过来的Data可能有结束符号导致Json解析异常
    //              NSDictionary *json = [NSJSONSerialization JSONObjectWithData:[str2 dataUsingEncoding:NSUTF8StringEncoding] options:kNilOptions error:nil];
                    json = [decryptData objectFromJSONDataWithParseOptions:JKParseOptionValidFlags];
                }
                if (!json) {
                    //json解析失败，清空这部分数据
                    [self.haveReadData replaceBytesInRange:NSMakeRange(0, headDataLenth + dataLenth) withBytes:NULL length:0];
                    if (self.haveReadData.length < headDataLenth) {
                        [self.readDataLock unlock];
                        [sock readDataWithTimeout:-1 tag:self.sendNum];
                        return;
                    } else {
                        [self.readDataLock unlock];
                    }
                } else {
                    if (opcode == GHOpCodeConfigwiFiInfoRecieve) { //AP配网的code
                        [self parseWithSocket:sock opCode:opcode statusCode:statusCode status:json];
                        //清除当前解析过的数据 长度为 包头长度+消息长度
                        [self.haveReadData replaceBytesInRange:NSMakeRange(0, headDataLenth + dataLenth) withBytes:NULL length:0];
                        [self.readDataLock unlock];
                    } else {
                        if (json[@"sid"] && [self.userData isEqualToString:json[@"sid"] ]) {
                            //数据解析成功, 而且是同一个设备
                            [self parseWithSocket:sock opCode:opcode statusCode:statusCode status:json];
                            //清除当前解析过的数据 长度为 包头长度+消息长度
                            [self.haveReadData replaceBytesInRange:NSMakeRange(0, headDataLenth + dataLenth) withBytes:NULL length:0];
                            [self.readDataLock unlock];
                        } else {
                            //当前的TCP链接错误， 处理方式是直接关闭
                            [self.readDataLock unlock];
                            [sock disconnect];
                            return;
                        }
                    }
                }
            }
        }
    } while (self.haveReadData.length > 0);
    
    [sock readDataWithTimeout:-1 tag:self.sendNum];
}


- (void)socketDidDisconnect:(GCDAsyncSocket *)sock withError:(NSError *)err {
    //关闭心跳定时器
    NSLog(@"TCP Socket disConnect = %@", err.description);
//    if (self.sendHeartbeatTimer) {
//        [self.sendHeartbeatTimer invalidate];
//        self.sendHeartbeatTimer = nil;
//    }
    
    self.securityKey = nil;
    self.iv = nil;

    [self.haveReadData replaceBytesInRange:NSMakeRange(0, self.haveReadData.length) withBytes:NULL length:0];
    [sock setDelegate:nil delegateQueue:NULL];
    sock.delegate = nil;
    sock = nil;
    
    //TCP断开的时候断开socket
    self.connectedSuccess = nil;
    self.recieveTcpSocket = nil;
    

    if (self.connectedFailed) { //连接失败的断开
        self.connectedFailed(self);
        self.connectedFailed = nil;
    }
    else if(self.connectedDisConnect) { //连接成功后的断开
        self.connectedDisConnect(self);
        self.connectedDisConnect = nil;
    }
    
    if (self.isConnected == YES) {
        if ([self.delegate respondsToSelector:@selector(connectedDisConnect:)]) {
            [self.delegate connectedDisConnect:self];
        }
    } else {
        if ([self.delegate respondsToSelector:@selector(connectedFailed:)]) {
            [self.delegate connectedFailed:self];
        }
    }
    //设置为连接失败的状态
    self.isConnected = NO;
}

//TODO:打算将数据封装成跟MQTT一样的格式，外面解密就非常的方便
- (void)parseWithSocket:(GCDAsyncSocket *)sock opCode:(GHOpCode)opCode statusCode:(GHStatusCode)statusCode status:(NSDictionary *)status{
    NSLog(@"TCP Socket recieve data");
    NSDictionary *recieveStatus = @{
        @"opCode":@(opCode),
        @"statusCode":@(statusCode),
        @"properties":status ?: @{}
    };
    !self.recieveTcpSocket ?: self.recieveTcpSocket(self, recieveStatus);
    if ([self.delegate respondsToSelector:@selector(recieveTcpSocket:data:)]) {
        [self.delegate recieveTcpSocket:self data:recieveStatus];
    }
}


#pragma mark - getter/setter

- (void)setSendNum:(NSInteger)sendNum {
    _sendNum = sendNum;
    if (_sendNum >= 0xFFFF) {
        _sendNum = 0;
    }
}

@end
