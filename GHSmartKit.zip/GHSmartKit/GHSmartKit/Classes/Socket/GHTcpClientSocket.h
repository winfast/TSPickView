//
//  GHTcpClientSocket.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/1.
//

#import <Foundation/Foundation.h>
#import <CocoaAsyncSocket/GCDAsyncSocket.h>
#import "GHSocket.h"

@class GHTcpClientSocket;

@protocol GHTcpClientSocketDelegate <NSObject>

- (void)connectedSuccess:(GHTcpClientSocket *)socke;
- (void)connectedFailed:(GHTcpClientSocket *)socke;
- (void)connectedDisConnect:(GHTcpClientSocket *)socket;
- (void)socketWriteTimeout:(GHTcpClientSocket *)socket;
- (void)recieveTcpSocket:(GHTcpClientSocket *)socket data:(NSDictionary *)data;

@end


@interface GHTcpClientSocket : NSObject

@property (nonatomic, strong) NSString *securityKey;
@property (nonatomic, strong) NSString *iv;
@property (nonatomic) UInt8 version;  //业务版本号

/// 委托
@property (nonatomic, weak) id<GHTcpClientSocketDelegate> delegate;

/// TCP实例对象
@property (nonatomic, strong, readonly) GCDAsyncSocket *socket;

/// 用来记录当前的Socket标识，没有任何作用
@property (nonatomic, strong) id userData;

/// TCP 连接状态
@property (nonatomic) BOOL isConnected;

/// TCP连接成功的回调
@property (nonatomic, copy) void (^connectedSuccess)(GHTcpClientSocket *socket);

/// TCP连接失败的回调
@property (nonatomic, copy) void (^connectedFailed)(GHTcpClientSocket *socket);

/// TCP 断开连接的回调
@property (nonatomic, copy) void (^connectedDisConnect)(GHTcpClientSocket *socket);

/// TCP 写数据超时的回调
@property (nonatomic, copy) void (^socketWriteTimeout)(GHTcpClientSocket *socket);

/// 收到设备发送的数据
@property (nonatomic, copy) void (^recieveTcpSocket)(GHTcpClientSocket *socket, NSDictionary *smartDeviceData);


//- (instancetype) __unavailable init;
- (instancetype)init NS_UNAVAILABLE;

/// 初始化单例模式
+ (instancetype)share;

/// 初始化socket
+ (instancetype)currDeviceSocket;

/// 创建TCP并且链接到hiding的IP和端口
/// @param ipAddress IP地址
/// @param port 端口
- (BOOL)connectTCPService:(NSString *)ipAddress port:(NSInteger)port;

/// 断开TCP链接
- (void)disConnectTcpService;

/// 发送TCP消息
/// @param dict 发送的消息内容
- (void)postData:(NSDictionary *)dict;


/// 数据发送
/// @param opCode 发送的opCode值
/// @param status 发送的状态
- (void)postDataWithOpCode:(GHOpCode)opCode status:(NSDictionary *)status;

/// 数据发送
/// @param opCode 发送的opCode值
/// @param security 是否加密
/// @param status 发送的状态
- (void)postDataWithOpCode:(GHOpCode)opCode security:(BOOL)security status:(NSDictionary *)status;


@end

