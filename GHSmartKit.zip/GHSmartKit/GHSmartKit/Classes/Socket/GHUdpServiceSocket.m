//
//  GHUdpServiceSocket.m
//  GHSmartKit
//
//  Created by Qincc on 2021/7/1.
//  Copyright © 2021 Cuco Inc. All rights reserved.
//

#import "GHUdpServiceSocket.h"
#import <CocoaAsyncSocket/GCDAsyncUdpSocket.h>
#import "GHSocket.h"

@interface GHUdpServiceSocket ()<GCDAsyncUdpSocketDelegate>

@property (nonatomic, strong) GCDAsyncUdpSocket *udpServiceSocket;
@property (nonatomic, strong) dispatch_queue_t queue;

@end

@implementation GHUdpServiceSocket

+ (instancetype)share {
    static dispatch_once_t onceToken;
    static GHUdpServiceSocket *socket;
    dispatch_once(&onceToken, ^{
        socket = GHUdpServiceSocket.alloc.init;
    });
    return socket;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.queue = dispatch_queue_create("com.socket.service.queeu", DISPATCH_QUEUE_CONCURRENT);
    }
    return self;
}

- (void)startUDPServiceSocketWithPort:(NSInteger)port {
    self.udpServiceSocket = [[GCDAsyncUdpSocket alloc] initWithDelegate:self delegateQueue:self.queue];
    [self.udpServiceSocket setIPv6Enabled:NO]; //过滤IPV6的消息
    NSError *error;
    //绑定端口
    [self.udpServiceSocket bindToPort:port error:&error];
    if (error) {
        NSLog(@"error = %@", error);
    }
    //开始接收UDP消息
    [self.udpServiceSocket beginReceiving:&error];
    if (error) {
        NSLog(@"error = %@", error);
    }
}

/// 发送消息
/// @param ipAddress 目标IP地址
/// @param port 目标端口
- (void)sendDataWithIPAddress:(NSString *)ipAddress port:(NSInteger)port data:(NSData *)data {
    [self.udpServiceSocket sendData:data toHost:ipAddress port:port withTimeout:-1 tag:port];
}

#pragma mark- GCDAsyncUdpSocketDelegate
- (void)udpSocket:(GCDAsyncUdpSocket *)sock didReceiveData:(NSData *)data fromAddress:(NSData *)address withFilterContext:(id)filterContext {
    NSString *host = nil;
    uint16_t port = 0;
    [GCDAsyncUdpSocket getHost:&host port:&port fromAddress:address];
    //UDP数据解析  数据部分不加密
    
    //包头
    NSUInteger headDataLenth = sizeof(GHHeaderData);
    GHHeaderData headData;
    [data getBytes:&headData range:NSMakeRange(0, headDataLenth)];
    UInt8 protocolVersion = headData.protocol;   //协议版本
    UInt8 serviceType = headData.serviceType;   //业务类型
    UInt16 sequenceId = OSSwapHostToBigInt32(headData.sequenceld);    //序列号
    UInt32 dataLenth = OSSwapHostToBigInt32(headData.dataLenth);      //数据包长度
   
    //获取设备端有效的数据 消息头
    NSData *deviceData = [data subdataWithRange:NSMakeRange(headDataLenth, dataLenth)];
    //获取消息的头4个字节的内容，用来处理消息信息
    GHDataInfo dataInfo;
    [deviceData getBytes:&dataInfo range:NSMakeRange(0, sizeof(GHDataInfo))];
    UInt8 version = dataInfo.version;   // 业务版本号
    UInt8 security = dataInfo.security; // 是否加密 1加密。0不加密
    UInt8 reserved = dataInfo.reserved; // 保留字段，默认值0
    GHStatusCode statusCode = dataInfo.statusCode; //状态码，标识业务处理的状态
    GHOpCode opcode = OSSwapHostToBigInt16(dataInfo.opcode);       //操作码（采用网络字节序), 如下表所示
    
    //设备端发送的实际数据 从第12个字节开始， 长度是dataLen - 消息头长度（sizeof(GHDataInfo)）
    NSData *deviceSmartData = [data subdataWithRange:NSMakeRange(headDataLenth + sizeof(GHDataInfo), data.length - headDataLenth - sizeof(GHDataInfo))];
    NSMutableDictionary *json = [[NSJSONSerialization JSONObjectWithData:deviceSmartData options:kNilOptions error:nil] mutableCopy];
    if (opcode == GHOpCodeUDPReport) {  //
        if ([json objectForKey:@"ip"] && [json objectForKey:@"model"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [json setObject:@(statusCode) forKey:@"statusCode"];
                !self.recieveUdpServiceSocketData ?: self.recieveUdpServiceSocketData(self, json);
                if ([self.delegate respondsToSelector:@selector(recieveWithSocket:data:)]) {
                    [self.delegate recieveWithSocket:self data:json];
                }
            });
        }
    }
}

- (void)udpSocketDidClose:(GCDAsyncUdpSocket *)sock withError:(NSError *)error {
    
}

- (void)closetUDPServiceSocket {
    [self.udpServiceSocket pauseReceiving];
    self.udpServiceSocket.delegate = nil;
    [self.udpServiceSocket close];
}


@end
