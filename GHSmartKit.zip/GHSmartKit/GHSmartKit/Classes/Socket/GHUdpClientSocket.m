//
//  GHUdpClientSocket.m
//  GHSmartKit
//
//  Created by Qincc on 2021/7/1.
//

#import "GHUdpClientSocket.h"
#import "GHSocket.h"
#import <CocoaAsyncSocket/GCDAsyncUdpSocket.h>

@interface GHUdpClientSocket ()<GCDAsyncUdpSocketDelegate>

@property (nonatomic, strong) GCDAsyncUdpSocket *udpSocket;

@end

@implementation GHUdpClientSocket

+ (instancetype)share {
    static dispatch_once_t onceToken;
    static GHUdpClientSocket *udpClientSocket;
    dispatch_once(&onceToken, ^{
        udpClientSocket = [[GHUdpClientSocket alloc] init];
    });
    return udpClientSocket;
}

- (void)postData:(NSDictionary *)postDict withIpaddr:(NSString *)ipaddr port:(NSInteger)port {
    NSError *error = nil;
    if(self.udpSocket == nil) {
        NSLog(@"UDP Client Socket init");
        self.udpSocket = [[GCDAsyncUdpSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
        [self.udpSocket setIPv6Enabled:NO];
        if (![self.udpSocket bindToPort:port error:&error]) {
            return;
        }
    }
    [self.udpSocket enableBroadcast:YES error:&error];
    if (![self.udpSocket beginReceiving:&error]) {
        self.udpSocket = [[GCDAsyncUdpSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
        if (![self.udpSocket bindToPort:port error:&error]) {
            return;
        }
        [self.udpSocket beginReceiving:&error];
        [self.udpSocket enableBroadcast:YES error:&error];
    }
    
    NSData *postData = [self encodeProtocalPub:GHOpCodeUDPSearch status:postDict];
    // 10秒  如果超时不接受消息
    [self.udpSocket sendData:postData toHost:ipaddr.length > 0 ? ipaddr : @"255.255.255.255" port:port withTimeout:10 tag:0];
}

- (NSData *)encodeProtocalPub:(GHOpCode)opCode status:(NSDictionary *)status {
    static UInt16 sequenceld = 0x0001;
    NSMutableData *postData = NSMutableData.data;
    NSData *jsonData = nil;
    if (status.count > 0) {
        jsonData = [NSJSONSerialization dataWithJSONObject:status options:NSJSONWritingPrettyPrinted error:nil];
    }
    GHHeaderData data;
    data.protocol = 0x01;
    data.serviceType = 0x01;
    data.sequenceld = OSSwapHostToBigInt16(sequenceld);
    UInt32 result = OSSwapHostToBigInt32((UInt32)(sizeof(GHDataInfo) + (UInt32)jsonData.length));
    data.dataLenth = result;
    [postData appendData:[NSData dataWithBytes:&data length:sizeof(GHHeaderData)]];
    
    //数据部分的协议
    GHDataInfo dataInfo;
    dataInfo.version = 0x01;
    dataInfo.security = 0x00;   //表示不加密
    dataInfo.reserved = 0x00;
    dataInfo.statusCode = 0;
    dataInfo.opcode = OSSwapHostToBigInt16(opCode);
    [postData appendData:[NSData dataWithBytes:&dataInfo length:sizeof(GHDataInfo)]];
    if (jsonData.length > 0) {
        [postData appendData:jsonData];
    }
    sequenceld++;
    
#if 0   //验证数据的正确性
    GHHeaderData currHeadData;
    [postData getBytes:&currHeadData range:NSMakeRange(0, sizeof(GHHeaderData))];
    NSLog(@"protocol = %d, serviceType = %d sequenceld = %d dataLenth = %d", currHeadData.protocol, currHeadData.serviceType, OSSwapHostToBigInt16(currHeadData.sequenceld), OSSwapHostToBigInt32(currHeadData.dataLenth));

    GHDataInfo currDataInfo;
    [postData getBytes:&currDataInfo range:NSMakeRange(sizeof(GHHeaderData), sizeof(GHDataInfo))];
    NSLog(@"version = %d, security = %d reserved = %d statusCode = %d opcode = %d", currDataInfo.version, currDataInfo.security, currDataInfo.reserved, currDataInfo.statusCode, OSSwapHostToBigInt16(currDataInfo.opcode));
    
    NSData *currJsonData = [postData subdataWithRange:NSMakeRange(sizeof(GHHeaderData) + sizeof(GHDataInfo), postData.length - sizeof(GHHeaderData) - sizeof(GHDataInfo))];
//    NSData *base64Decode = [GHEncryption base64Dencode:currJsonData];
//    NSData *decryptData = [GHEncryption AES128DecryptDataWithData:base64Decode secretKey:self.secretKey];  //解密
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:currJsonData
                                                         options:kNilOptions
                                                           error:nil];
    NSLog(@"json = %@", json.description);
#endif
    return postData;
}

#pragma mark- GCDAsyncUdpSocketDelegate
- (void)udpSocket:(GCDAsyncUdpSocket *)sock didSendDataWithTag:(long)tag {
    NSLog(@"udpSocket send success");
}

- (void)udpSocket:(GCDAsyncUdpSocket *)sock didNotSendDataWithTag:(long)tag dueToError:(NSError *)error {
    NSLog(@"didNotSendDataWithTag = %@",error);
}

- (void)udpSocket:(GCDAsyncUdpSocket *)sock didReceiveData:(NSData *)data fromAddress:(NSData *)address withFilterContext:(id)filterContext {
    NSString *host = nil;
    uint16_t port = 0;
    [GCDAsyncUdpSocket getHost:&host port:&port fromAddress:address];
    
    //UDP数据解析  数据部分不加密
    //包头
    NSUInteger headDataLenth = sizeof(GHHeaderData);
    GHHeaderData headData;
    [data getBytes:&headData range:NSMakeRange(0, headDataLenth)];
    UInt8 protocolVersion = headData.protocol;   //协议版本
    UInt8 serviceType = headData.serviceType;   //业务类型
    UInt16 sequenceId = OSSwapHostToBigInt32(headData.sequenceld);    //序列号
    UInt32 dataLenth = OSSwapHostToBigInt32(headData.dataLenth);      //数据包长度
   
    //获取设备端有效的数据 消息头
    NSData *deviceData = [data subdataWithRange:NSMakeRange(headDataLenth, dataLenth)];
    //获取消息的头4个字节的内容，用来处理消息信息
    GHDataInfo dataInfo;
    [deviceData getBytes:&dataInfo range:NSMakeRange(0, sizeof(GHDataInfo))];
    UInt8 version = dataInfo.version;   // 业务版本号
    UInt8 security = dataInfo.security; // 是否加密 1加密。0不加密
    UInt8 reserved = dataInfo.reserved; // 保留字段，默认值0
    GHStatusCode statusCode = dataInfo.statusCode; //状态码，标识业务处理的状态
    GHOpCode opcode = OSSwapHostToBigInt16(dataInfo.opcode);       //操作码（采用网络字节序), 如下表所示
    //设备端发送的实际数据 从第12个字节开始， 长度是dataLen - 消息头长度（sizeof(GHDataInfo)）
    //消息内容
//    NSData *deviceSmartData = [data subdataWithRange:NSMakeRange(headDataLenth + sizeof(GHDataInfo), dataLenth - sizeof(GHDataInfo))];
    NSData *deviceSmartData = [data subdataWithRange:NSMakeRange(headDataLenth + sizeof(GHDataInfo), data.length - headDataLenth - sizeof(GHDataInfo))];
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:deviceSmartData options:kNilOptions error:nil];
    if (statusCode == GHStatusNotLogin) {  //不允许链接MQTT
        dispatch_async(dispatch_get_main_queue(), ^{
            !self.recieveUdpServiceData ?: self.recieveUdpServiceData(self, json);
            self.recieveUdpServiceData = nil;
        });
        return;
    }
    
    if ([json objectForKey:@"ip"] && [json objectForKey:@"model"]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            !self.recieveUdpServiceData ?: self.recieveUdpServiceData(self, json);
            self.recieveUdpServiceData = nil;
        });
        return;
    }
}

- (void)udpSocketDidClose:(GCDAsyncUdpSocket *)sock withError:(NSError *)error {
    NSLog(@"withError = %@", error.userInfo.description);
}

- (void)closeSocket {
    !self.smartDeviceUDPClose ?: self.smartDeviceUDPClose();
    self.smartDeviceUDPClose = nil;
    self.recieveUdpServiceData = nil;
    [self.udpSocket pauseReceiving];
    self.udpSocket.delegate = nil;
    [self.udpSocket close];
    self.udpSocket = nil;
}

@end
