//
//  GHCancelRequest.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/23.
//

#import <Foundation/Foundation.h>


@protocol GHCancelRequest <NSObject>

+ (void)cancelRequest:(NSString *)reqeustId;

@end

