//
//  GHRegionModel.m
//  GHSmartKit
//
//  Created by Qincc on 2021/7/1.
//

#import "GHRegionModel.h"

@implementation GHRegionModel

@end
