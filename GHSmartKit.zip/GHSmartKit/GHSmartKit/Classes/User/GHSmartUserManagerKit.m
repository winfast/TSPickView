//
//  GHSmartUserManagerKit.m
//  GHSmartKit
//
//  Created by Qincc on 2021/6/23.
//

#import "GHSmartUserManagerKit.h"
#import <MJExtension/MJExtension.h>

@interface GHSmartUserManagerKit ()

/// Session ID.
@property (nonatomic, copy) NSString *sid;

/// User ID.
@property (nonatomic, copy) NSString *uid;

/// Head icon.
@property (nonatomic, copy) NSString *headIconUrl;

/// Nick name.
@property (nonatomic, copy) NSString *nickname;

/// Username. If account is mobile phone, this is mobile phone. If account is email, this is email.
@property (nonatomic, copy) NSString *userName;

/// Mobile phone.
@property (nonatomic, copy) NSString *phoneNumber;

/// Email.
@property (nonatomic, copy) NSString *email;

/// Country code. `86` for China, `1` for America.
@property (nonatomic, copy) NSString *countryCode;

/// The region code of current account. `AY` for China, `AZ` for America, `EU` for Europe.
@property (nonatomic, copy) NSString *regionCode;

/// The api domains of current account region.
@property (nonatomic, copy) NSDictionary *domain;

/// Timezone ID. e.g. `Asia/Shanghai`.
@property (nonatomic, copy) NSString *timezoneId;

@property (nonatomic, copy) NSString *partnerIdentity;

/// MQTT host.
@property (nonatomic, copy) NSString *mbHost;

@property (nonatomic, copy) NSString *gwHost;

/// MQTT port.
@property (nonatomic) NSInteger port;

/// Whether to enable SSL.
@property (nonatomic) BOOL useSSL;

/// QUIC host.
@property (nonatomic, copy) NSString *quicHost;

/// QUIC port.
@property (nonatomic) NSInteger quicPort;

/// Whether to enable QUIC.
@property (nonatomic) BOOL useQUIC;

/// Temperature unit. 1 for `°C`, 2 for `°F`.
@property (nonatomic) NSInteger tempUnit;

/// User register type.
//@property (nonatomic) TYRegType regFrom;

/// Nickname of SNS account.
@property (nonatomic, copy) NSString *snsNickname;

@property (nonatomic, copy) NSString *ecode;

/// User type.
@property (nonatomic) NSInteger userType;

/// Extra parameters.
@property (nonatomic, copy) NSDictionary *extras;

@end

@implementation GHSmartUserManagerKit

+ (instancetype)share {
    static dispatch_once_t onceToken;
    static GHSmartUserManagerKit *userManager;
    dispatch_once(&onceToken, ^{
        NSDictionary *infoDic = [NSUserDefaults.standardUserDefaults dictionaryForKey:@"GHUserInfo"];
        if (infoDic && infoDic[@"token"]) {
            userManager = [GHSmartUserManagerKit mj_objectWithKeyValues:infoDic];
            userManager.isLogin = YES;
        } else {
            userManager.isLogin = NO;
            if (infoDic) {
                userManager = [GHSmartUserManagerKit mj_objectWithKeyValues:infoDic];
            } else {
                userManager = GHSmartUserManagerKit.alloc.init;
            }
        }
    });
    return userManager;
}

- (void)updateSmartUserInfo:(NSDictionary *)userInfo {
    //跟新用户信息
}

#pragma mark - GHCancelRequest
+ (void)cancelRequest:(NSString *)reqeustId {
    [GHNetworkModule.share cancelRequestWithRequestID:reqeustId];
}


@end

