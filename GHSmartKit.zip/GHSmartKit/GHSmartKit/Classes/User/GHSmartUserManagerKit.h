//
//  GHSmartUserManagerKit.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/23.
//

#import <Foundation/Foundation.h>
#import <GHNetworkModule/GHNetwork.h>
#import "GHCancelRequest.h"

@interface GHSmartUserManagerKit : NSObject<GHCancelRequest>

/// Session ID.
@property (nonatomic, copy, readonly) NSString *sid;

/// User ID.
@property (nonatomic, copy, readonly) NSString *uid;

/// Head icon.
@property (nonatomic, copy, readonly) NSString *headIconUrl;

/// Nick name.
@property (nonatomic, copy, readonly) NSString *nickname;

/// Username. If account is mobile phone, this is mobile phone. If account is email, this is email.
@property (nonatomic, copy, readonly) NSString *userName;

/// Mobile phone.
@property (nonatomic, copy, readonly) NSString *phoneNumber;

/// Email.
@property (nonatomic, copy, readonly) NSString *email;

/// Country code. `86` for China, `1` for America.
@property (nonatomic, copy, readonly) NSString *countryCode;

/// Login status.
@property (nonatomic) BOOL isLogin;

/// The region code of current account. `AY` for China, `AZ` for America, `EU` for Europe.
@property (nonatomic, copy, readonly) NSString *regionCode;

/// The api domains of current account region.
@property (nonatomic, copy, readonly) NSDictionary *domain;

/// Timezone ID. e.g. `Asia/Shanghai`.
@property (nonatomic, copy, readonly) NSString *timezoneId;

@property (nonatomic, copy, readonly) NSString *partnerIdentity;

/// MQTT host.
@property (nonatomic, copy, readonly) NSString *mbHost;

@property (nonatomic, copy, readonly) NSString *gwHost;

/// MQTT port.
@property (nonatomic, readonly) NSInteger port;

/// Whether to enable SSL.
@property (nonatomic, readonly) BOOL useSSL;

/// QUIC host.
@property (nonatomic, copy, readonly) NSString *quicHost;

/// QUIC port.
@property (nonatomic, readonly) NSInteger quicPort;

/// Whether to enable QUIC.
@property (nonatomic, readonly) BOOL useQUIC;

/// Temperature unit. 1 for `°C`, 2 for `°F`.
@property (nonatomic, readonly) NSInteger tempUnit;

/// User register type.
//@property (nonatomic) TYRegType regFrom;

/// Nickname of SNS account.
@property (nonatomic, copy, readonly) NSString *snsNickname;

@property (nonatomic, copy, readonly) NSString *ecode;

/// User type.
@property (nonatomic, readonly) NSInteger userType;

/// Extra parameters.
@property (nonatomic, copy, readonly) NSDictionary *extras;

- (instancetype)init NS_UNAVAILABLE;

+ (instancetype)share;

/// Send verification code, used for register/login/reset password.
/// @param userName Mobile phone number or Email address.
/// @param region For register is required, use [TuyaSmartUser regionListWithCountryCode:success:failure:] or [TuyaSmartUser getDefaultRegionWithCountryCode:] to get region.
/// @param countryCode Country code.
/// @param type 1: Mobile phone verification code register,2: Mobile phone verification code login,3: Mobile phone password reset. 5: Improve account information (in experience mode); 7: Account change; 8: Cancel account
/// @param complete Called when the task finishes.
- (NSString *)sendVerifyCodeWithUserName:(NSString *)userName
                                  region:(NSString *)region
                             countryCode:(NSString *)countryCode
                                    type:(NSInteger)type
                                complete:(void(^)(id data, NSError *error))complete;


/// Mobile phone verification code login.
/// @param mobile Mobile phone number.
/// @param countryCode Country code.
/// @param code Verification code.
/// @param complete Called when the task finishes.
- (NSString *)loginWithMobile:(NSString *)mobile
                  countryCode:(NSString *)countryCode
                         code:(NSString *)code
                     complete:(void(^)(id data, NSError *error))complete;
//
//
//#pragma mark - Mobile phone binding
//
///// Send verification code. Used for mobile phone bind, mobile phone change.
///// @param countryCode Country code.
///// @param phoneNumber Mobile phone number.
///// @param success Called when the task finishes successfully.
///// @param failure Called when the task is interrupted by an error.
//- (void)sendBindVerifyCode:(NSString *)countryCode
//               phoneNumber:(NSString *)phoneNumber
//                   success:(nullable TYSuccessHandler)success
//                   failure:(nullable TYFailureError)failure;
//
//
///// Send verification code. Used for mobile phone bind for more service.
///// @param countryCode Country code.
///// @param phoneNumber Mobile phone number.
///// @param success Called when the task finishes successfully.
///// @param failure Called when the task is interrupted by an error.
//- (void)sendBindVasVerifyCode:(NSString *)countryCode
//                  phoneNumber:(NSString *)phoneNumber
//                      success:(nullable TYSuccessHandler)success
//                      failure:(nullable TYFailureError)failure;
//
///// Mobile phone bind.
///// @param countryCode Country code.
///// @param phoneNumber Mobile phone number.
///// @param code Verification code.
///// @param success Called when the task finishes successfully.
///// @param failure Called when the task is interrupted by an error.
//- (void)mobileBinding:(NSString *)countryCode
//          phoneNumber:(NSString *)phoneNumber
//                 code:(NSString *)code
//              success:(nullable TYSuccessHandler)success
//              failure:(nullable TYFailureError)failure;
//
#pragma mark - Mobile phone password login

/// Mobile phone register.
/// @param countryCode Country code.
/// @param phoneNumber Mobile phone number.
/// @param password Password.
/// @param code Verification code.
/// @param complete Called when the task finishes.
- (NSString *)registerByPhone:(NSString *)countryCode
                  phoneNumber:(NSString *)phoneNumber
                     password:(NSString *)password
                         code:(NSString *)code
                     complete:(void(^)(id data, NSError *error))complete;

/// Mobile phone password login.
/// @param countryCode Country code.
/// @param phoneNumber Mobile phone number.
/// @param password Password.
/// @param complete Called when the task finishes.
- (NSString *)loginByPhone:(NSString *)countryCode
               phoneNumber:(NSString *)phoneNumber
                  password:(NSString *)password
                  complete:(void(^)(id data, NSError *error))complete;

/// Mobile phone password reset.
/// @param countryCode  Country code.
/// @param phoneNumber Mobile phone number.
/// @param newPassword New password.
/// @param code Verification code.
/// @param complete Called when the task finishes.
- (NSString *)resetPasswordByPhone:(NSString *)countryCode
                       phoneNumber:(NSString *)phoneNumber
                       newPassword:(NSString *)newPassword
                              code:(NSString *)code
                          complete:(void(^)(id data, NSError *error))complete;

#pragma mark - Email login

/// Email login.
/// @param countryCode Country code.
/// @param email Email.
/// @param password Password.
/// @param complete Called when the task finishes.
- (NSString *)loginByEmail:(NSString *)countryCode
                     email:(NSString *)email
                  password:(NSString *)password
                  complete:(void(^)(id data, NSError *error))complete;


/// Email password reset.
/// @param countryCode Country code.
/// @param email Email.
/// @param newPassword New password.
/// @param code Verification code.
/// @param complete Called when the task finishes.
- (NSString *)resetPasswordByEmail:(NSString *)countryCode
                             email:(NSString *)email
                       newPassword:(NSString *)newPassword
                              code:(NSString *)code
                          complete:(void(^)(id data, NSError *error))complete;
//
//
#pragma mark - Email register 2.0

/// Email register 2.0.
/// @param countryCode Country code.
/// @param email Email.
/// @param password Password.
/// @param code Verification code.
/// @param complete Called when the task finishes.
- (NSString *)registerByEmail:(NSString *)countryCode
                        email:(NSString *)email
                     password:(NSString *)password
                         code:(NSString *)code
                     complete:(void(^)(id data, NSError *error))complete;

#pragma mark - Email verification code login

/// Email verification code login.
/// @param email Email.
/// @param countryCode Country code.
/// @param code Verification code.
/// @param complete Called when the task finishes.
- (NSString *)loginWithEmail:(NSString *)email countryCode:(NSString *)countryCode code:(NSString *)code complete:(void(^)(id data, NSError *error))complete;

#pragma mark - Email bind

/// Get email binding verification code.
/// @param email E-mail.
/// @param countryCode Country Code.
/// @param complete Called when the task finishes.
- (NSString *)sendBindingVerificationCodeWithEmail:(NSString *)email
                                       countryCode:(NSString *)countryCode
                                          complete:(void(^)(id data, NSError *error))complete;

/// Binding email.
/// @param email E-mail.
/// @param countryCode Country Code.
/// @param code Verification Code.
/// @param sId User session ID.
/// @param complete Called when the task finishes.
- (NSString *)bindEmail:(NSString *)email
        withCountryCode:(NSString *)countryCode
                   code:(NSString *)code
                    sId:(NSString *)sId
               complete:(void(^)(id data, NSError *error))complete;
//
//#pragma mark - uid login
//
///// User ID. login/register. The account will be registered at first login.
///// @param countryCode Country code.
///// @param uid User ID.
///// @param password Password.
///// @param createHome Create default home.
///// @param success Called when the task finishes successfully.
///// @param failure Called when the task is interrupted by an error.
//- (void)loginOrRegisterWithCountryCode:(NSString *)countryCode
//                                   uid:(NSString *)uid
//                              password:(NSString *)password
//                            createHome:(BOOL)createHome
//                               success:(nullable TYSuccessID)success
//                               failure:(nullable TYFailureError)failure;
//
//#pragma mark - Social login
//
///// QQ login.
///// @param countryCode Country code.
///// @param userId UserId from QQ authorization login.
///// @param accessToken AccessToken from QQ authorization login.
///// @param success Called when the task finishes successfully.
///// @param failure Called when the task is interrupted by an error.
//- (void)loginByQQ:(NSString *)countryCode
//           userId:(NSString *)userId
//      accessToken:(NSString *)accessToken
//          success:(nullable TYSuccessHandler)success
//          failure:(nullable TYFailureError)failure;
//
///// WeChat login.
///// @param countryCode Country code.
///// @param code Code from WeChat authorization login.
///// @param success Called when the task finishes successfully.
///// @param failure Called when the task is interrupted by an error.
//- (void)loginByWechat:(NSString *)countryCode
//                 code:(NSString *)code
//              success:(nullable TYSuccessHandler)success
//              failure:(nullable TYFailureError)failure;
//
///// Facebook Login.
///// @param countryCode Country code.
///// @param token Token from Facebook authorization login
///// @param success Called when the task finishes successfully.
///// @param failure Called when the task is interrupted by an error.
//- (void)loginByFacebook:(NSString *)countryCode
//                  token:(NSString *)token
//                success:(nullable TYSuccessHandler)success
//                failure:(nullable TYFailureError)failure;
//
///// Twitter login.
///// @param countryCode Country code.
///// @param key Key from Twitter authorization login.
///// @param secret Secret from Twitter authorization login.
///// @param success Called when the task finishes successfully.
///// @param failure Called when the task is interrupted by an error.
//- (void)loginByTwitter:(NSString *)countryCode
//                   key:(NSString *)key
//                secret:(NSString *)secret
//               success:(nullable TYSuccessHandler)success
//               failure:(nullable TYFailureError)failure;
//
///// Third login.
///// @param type Login type(ap for "login with apple").
///// @param countryCode Country code.
///// @param accessToken  Token from third authorization login.
///// @param extraInfo Extra params.
///// @param success Called when the task finishes successfully.
///// @param failure Called when the task is interrupted by an error.
//- (void)loginByAuth2WithType:(NSString *)type
//                 countryCode:(NSString *)countryCode
//                 accessToken:(NSString *)accessToken
//                   extraInfo:(NSDictionary *)extraInfo
//                     success:(nullable TYSuccessHandler)success
//                     failure:(nullable TYFailureError)failure;
//
#pragma mark -

///// Logout.
///// @param complete Called when the task finishes.
- (void)loginOutWithComplete:(void(^)(id data, NSError *error))complete;
//
/// Edit nick name.
/// @param nickName Nick name.
/// @param complete Called when the task finishes.
- (NSString *)updateNickname:(NSString *)nickName
              complete:(void(^)(id data, NSError *error))complete;

/// Edit head icon.
/// @param headIcon Head icon.
/// @param complete Called when the task finishes.
- (NSString *)updateHeadIcon:(UIImage *)headIcon
              complete:(void(^)(id data, NSError *error))complete;

/// Update user information.
/// @param complete Called when the task finishes.
- (NSString *)updateUserInfoWithComplete:(void(^)(id data, NSError *error))complete;

/// Edit user timezone information.
/// @param timeZoneId TimeZone ID. e.g. `Asia/Shanghai`.
/// @param complete Called when the task finishes.
- (NSString *)updateTimeZoneWithTimeZoneId:(NSString *)timeZoneId
                            complete:(void(^)(id data, NSError *error))complete;

/// Edit user temperature unit.
/// @param tempUnit Temperature unit. 1 for `°C`, 2 for `°F`.
/// @param complete Called when the task finishes.
- (NSString *)updateTempUnitWithTempUnit:(NSInteger)tempUnit
                          complete:(void(^)(id data, NSError *error))complete;

/// Destroy account. One week after, all of the account information will be removed from server forever. If you login before removed, the destroy request will be canceled.
/// @param complete Called when the task finishes.
- (NSString *)cancelAccountWithComplete:(void(^)(id data, NSError *error))complete;


/**
 * Check password format by password regular type
 *
 * @param password  Inputed password
 * @param regularType Password regular type
 * @return Result of check password format
 */
//- (BOOL)checkPasswordFormat:(NSString *)password withPasswordRegularType:(TYPasswordRegularType)regularType;


//#pragma mark - Ticket from third cloud login
//
///// Login with ticket.
///// Ticket is created from a third-party cloud platform, for more information, please refer to the tuya cloud-to-cloud solution.
/////
///// @param ticket User ticket from service.
///// @param success Called when the task finishes successfully.
///// @param failure Called when the task is interrupted by an error.
//- (void)loginWithTicket:(NSString *)ticket
//                success:(TYSuccessHandler)success
//                failure:(TYFailureError)failure;

#pragma mark -

/// Cancel network request.
+ (void)cancelRequest:(NSString *)reqeustId;

@end

