//
//  GHRegionModel.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/1.
//

#import <Foundation/Foundation.h>

@interface GHRegionModel : NSObject

/// Region name.
@property (nonatomic, strong) NSString *name;

/// Region code.
@property (nonatomic, strong) NSString *region;

/// Default or not.
@property (nonatomic, assign) BOOL isDefault;

@end

