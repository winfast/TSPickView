//
//  GHSmartDeviceCategoryManagerKit+Home.m
//  GHSmartKit
//
//  Created by Qincc on 2021/7/3.
//

#import "GHSmartDeviceCategoryManagerKit+Home.h"
#import "GHSmartKitNetworkRequest.h"
#import "GHSmartConstValue.h"
#import <MJExtension/MJExtension.h>
#import "GHSmartKitStringDefine.h"

@implementation GHSmartDeviceCategoryManagerKit (Home)

- (NSString *)getDeviceConfigureNetworkTokenWithHomeId:(NSString *)homeId
                                              complete:(void(^)(id data, NSError *error))complete {
    GHSmartKitNetworkRequest *request = [GHSmartKitNetworkRequest.alloc initWithSmartKitRequestType:GHSmartKitRequestTypeConfigureNetworkTokenHomeId];
    request.methodPath = [NSString stringWithFormat:GHSmartKit_Configure_Network_Token_HomeId, homeId];
    return [GHNetworkModule.share sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        if (response.status == GHNetworkResponseStatusSuccess) {
            !complete ?: complete(response.data, nil);
        } else {
            !complete ?: complete(nil, response.error);
        }
    }];
}

@end
