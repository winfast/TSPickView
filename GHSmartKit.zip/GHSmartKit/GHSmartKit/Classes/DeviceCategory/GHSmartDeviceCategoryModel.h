//
//  GHSmartDeviceCategoryModel.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/3.
//

#import <Foundation/Foundation.h>

@interface GHSmartLevel3ItemsModel : NSObject

@property (nonatomic, copy) NSString *capability;
@property (nonatomic, copy) NSString *sale;
@property (nonatomic, copy) NSString *icon;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *pid;
@property (nonatomic, copy) NSString *sort;
@property (nonatomic, copy) NSString *attribute;
@property (nonatomic, copy) NSString *category;
@property (nonatomic, copy) NSString *activatorDes;

@end

@interface GHSmartDefaultLevel2ListModel : NSObject

@property (nonatomic, copy) NSString *tagCode;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSArray<GHSmartLevel3ItemsModel *> *level3Items;

@end

@interface GHSmartLevel1ListModel : NSObject

@property (nonatomic, copy) NSString *level1Code;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *type;

@end

@interface GHSmartDisplayModel : NSObject

@property (nonatomic, copy) NSString *wcAddBtText;
@property (nonatomic, copy) NSString *wcTip;
@property (nonatomic, copy) NSString *wifiIconUrl;
@property (nonatomic, copy) NSString *wcHelpUrl;
@property (nonatomic, copy) NSString *wifiTitle;
@property (nonatomic, copy) NSString *wifiContent;
@property (nonatomic, copy) NSString *wcTipIconUrl;

@end

@interface GHSmartLeadListModel : NSObject

@property (nonatomic, copy) NSString *iconUrl;
@property (nonatomic, copy) NSString *title;

@end

@interface GHSmartLinkMode : NSObject

@property (nonatomic, copy) NSArray<GHSmartLeadListModel *> *leadList;
@property (nonatomic, copy) NSString *linkMode;
@property (nonatomic, copy) NSString *title;

@end

@interface GHDefaultWglistModel : NSObject

@property (nonatomic, copy) NSString *capability;
@property (nonatomic, copy) NSString *sale;
@property (nonatomic, strong) GHSmartDisplayModel *display;
@property (nonatomic, copy) NSString *icon;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSArray<GHSmartLinkMode *> *linkModes;
@property (nonatomic, copy) NSString *enableLead;
@property (nonatomic, copy) NSString *attribute;
@property (nonatomic, copy) NSString *category;

@end


@interface GHSmartDeviceCategoryModel : NSObject

@property (nonatomic, copy) NSArray<GHSmartDefaultLevel2ListModel *> *defaultLevel2List;
@property (nonatomic, copy) NSArray<GHSmartLevel1ListModel *> *level1List;
@property (nonatomic, copy) NSArray<GHDefaultWglistModel *> *defaultWglist;

@end

