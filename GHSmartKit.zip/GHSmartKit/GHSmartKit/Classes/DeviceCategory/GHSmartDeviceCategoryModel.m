//
//  GHSmartDeviceCategoryModel.m
//  GHSmartKit
//
//  Created by Qincc on 2021/7/3.
//

#import "GHSmartDeviceCategoryModel.h"
#import <MJExtension/MJExtension.h>

@implementation GHSmartLevel3ItemsModel

@end

@implementation GHSmartDefaultLevel2ListModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{
        @"level3Items":GHSmartLevel3ItemsModel.class,
    };
}

@end

@implementation GHSmartLevel1ListModel

@end

@implementation GHSmartDisplayModel


@end

@implementation GHSmartLeadListModel


@end

@implementation GHDefaultWglistModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{
        @"linkModes":GHSmartLinkMode.class,
    };
}


@end

@implementation GHSmartLinkMode

+ (NSDictionary *)mj_objectClassInArray {
    return @{
        @"leadList":GHSmartLeadListModel.class,
    };
}

@end


@implementation GHSmartDeviceCategoryModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{
        @"defaultLevel2List":GHSmartDefaultLevel2ListModel.class,
        @"level1List":GHSmartLevel1ListModel.class,
        @"defaultWglist":GHDefaultWglistModel.class
    };
}

@end
