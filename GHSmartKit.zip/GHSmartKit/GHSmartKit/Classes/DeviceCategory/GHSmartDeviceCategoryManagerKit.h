//
//  GHSmartDeviceCategoryManagerKit.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/3.
//

#import <Foundation/Foundation.h>
#import "GHSmartDeviceCategoryModel.h"

@interface GHSmartDeviceCategoryManagerKit : NSObject

/// get device category.
///
/// @param complete     Called when the task finishes.
- (NSString *)getDeviceCategoryWithComplete:(void(^)(id data, NSError *error))complete;

/// Get configure network token
/// @param complete Called when the task finishes.
- (NSString *)getDeviceConfigureNetworkCommonWithComplete:(void(^)(id data, NSError *error))complete;

- (NSString *)getDeviceConfigureNetworkDeviceWithToken:(NSString *)token complete:(void(^)(id data, NSError *error))complete;

/// Get configure network guide
/// @param complete Called when the task finishes.
- (NSString *)getDeviceConfigureNetworkGuideWithComplete:(void(^)(id data, NSError *error))complete;

- (NSString *)getDeviceConfigureNetworkTestWithComplete:(void(^)(id data, NSError *error))complete;

@end

