//
//  GHSmartDeviceCategoryManagerKit.m
//  GHSmartKit
//
//  Created by Qincc on 2021/7/3.
//

#import "GHSmartDeviceCategoryManagerKit.h"
#import "GHSmartKitNetworkRequest.h"
#import "GHSmartConstValue.h"
#import <MJExtension/MJExtension.h>


@implementation GHSmartDeviceCategoryManagerKit

/// Get device category.
///
/// @param complete     Called when the task finishes.
- (NSString *)getDeviceCategoryWithComplete:(void(^)(id data, NSError *error))complete {
    GHSmartKitNetworkRequest *request = [GHSmartKitNetworkRequest.alloc initWithSmartKitRequestType:GHSmartKitRequestTypeConfigureNetworkCategory];
    return [GHNetworkModule.share sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        if (response.status == GHNetworkResponseStatusSuccess) {
            GHSmartDeviceCategoryModel *model = [GHSmartDeviceCategoryModel mj_objectWithKeyValues:response.data];
            !complete ?: complete(model, nil);
        } else {
            !complete ?: complete(nil, response.error);
        }
    }];
}

/// Get configure network token
/// @param complete Called when the task finishes.
- (NSString *)getDeviceConfigureNetworkCommonWithComplete:(void(^)(id data, NSError *error))complete {
    GHSmartKitNetworkRequest *request = [GHSmartKitNetworkRequest.alloc initWithSmartKitRequestType:GHSmartKitRequestTypeConfigureNetworkCommon];
    return [GHNetworkModule.share sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        if (response.status == GHNetworkResponseStatusSuccess) {
            GHSmartDeviceCategoryModel *model = [GHSmartDeviceCategoryModel mj_objectWithKeyValues:response.data];
            !complete ?: complete(model, nil);
        } else {
            !complete ?: complete(nil, response.error);
        }
    }];
}

- (NSString *)getDeviceConfigureNetworkDeviceWithToken:(NSString *)token complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)getDeviceConfigureNetworkGuideWithComplete:(void(^)(id data, NSError *error))complete {
    GHSmartKitNetworkRequest *request = [GHSmartKitNetworkRequest.alloc initWithSmartKitRequestType:GHSmartKitRequestTypeConfigureNetworkGuide];
    return [GHNetworkModule.share sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        if (response.status == GHNetworkResponseStatusSuccess) {
            GHSmartDeviceCategoryModel *model = [GHSmartDeviceCategoryModel mj_objectWithKeyValues:response.data];
            !complete ?: complete(model, nil);
        } else {
            !complete ?: complete(nil, response.error);
        }
    }];
    return nil;
}


- (NSString *)getDeviceConfigureNetworkTestWithComplete:(void(^)(id data, NSError *error))complete {
    return nil;
}

@end
