//
//  GHSmartConfigureNetworkCommonModel.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/3.
//

#import <Foundation/Foundation.h>

@interface GHSmartConfigureNetworkCommonModel : NSObject

@property (nonatomic, copy) NSString *migration_help_url;
@property (nonatomic, copy) NSString *siri_help_url;
@property (nonatomic, copy) NSString *Router_help;
@property (nonatomic, copy) NSString *Network_failure;
@property (nonatomic, copy) NSString *not_receive_email_url;
@property (nonatomic, copy) NSString *privacy;
@property (nonatomic, copy) NSString *judge_url;
@property (nonatomic, copy) NSString *not_receive_message_url;
@property (nonatomic, copy) NSString *wifi_device_url;
@property (nonatomic, copy) NSString *service_url;
@property (nonatomic, copy) NSString *watch_url;
@property (nonatomic, copy) NSString *faq;
@property (nonatomic, copy) NSString *search_failure_url;
@property (nonatomic, copy) NSString *ty_activator_custom_service_url;
@property (nonatomic, copy) NSString *galaxy_info_url;
@property (nonatomic, copy) NSString *method_url;
@property (nonatomic, copy) NSString *ble_help;
@property (nonatomic, copy) NSString *toco_transfer_guide;

@end
