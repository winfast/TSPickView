//
//  GHSmartDeviceCategoryManagerKit+Home.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/3.
//

#import <GHSmartKit/GHSmartKit.h>


@interface GHSmartDeviceCategoryManagerKit (Home)

/// Get configure Token
/// @param homeId current homeId
/// @param complete Called when the task finishes.
- (NSString *)getDeviceConfigureNetworkTokenWithHomeId:(NSString *)homeId
                                              complete:(void(^)(id data, NSError *error))complete;

@end

