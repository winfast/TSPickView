//
//  CucoUDPSocketClient.h
//  Runner
//
//  Created by wenzerong on 2020/9/2.
//  Copyright © 2020 The Chromium Authors. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CocoaAsyncSocket/GCDAsyncUdpSocket.h>

NS_ASSUME_NONNULL_BEGIN

@interface CucoUDPSocketClient : NSObject

@property (nonatomic, copy) void (^recieveUDPServiceData)(CucoUDPSocketClient *udpClientSocket, NSDictionary *data);

//@property(strong,nonatomic) NSMutableArray *clientSockets;  //客户端缓存s
- (void)initUDPSocktWithIP:(NSString*)ip withToken:(NSDictionary *)tokenDict;

- (void)closeUDPSocket;

@end

NS_ASSUME_NONNULL_END
