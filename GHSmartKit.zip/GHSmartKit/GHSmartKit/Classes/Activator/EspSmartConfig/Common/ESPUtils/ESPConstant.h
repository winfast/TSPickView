//
//  ESPConstant.h
//  EspTouchDemo
//
//  Created by houcheng on 2020/6/10.
//  Copyright © 2020 Espressif. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/**
    配网状态对应码
 */
//设备连接到路由器
static NSString * const SmartConfig_State_connected = @"0";
//设备正在连接路由器
static NSString * const SmartConfig_State_connecting = @"1";
//设备断开连接
static NSString * const SmartConfig_State_disconnected = @"2";
//设备连接路由器失败
static NSString * const SmartConfig_State_connectionFailed = @"3";
//设备连接到服务器，并配网成功
static NSString * const SmartConfig_State_serverConnected = @"4";
//设备正在连接服务器
static NSString * const SmartConfig_State_serverConnecting = @"5";
//设备连接服务器失败
static NSString * const SmartConfig_State_serverConnectFailed = @"6";
//设备认证iot成功
static NSString * const SmartConfig_State_iotConnected = @"7";
//设备正在连接iot服务器
static NSString * const SmartConfig_State_iotConnecting = @"8";
//设备连接iot服务器失败
static NSString * const SmartConfig_State_iotConnectFailed = @"9";
//设备返回设备信息数据
static NSString * const SmartConfig_State_resp_Deviceinfo = @"10";
/**
   通知名称
*/
//NSString * const SmartConfig_State_Notification = @"smartConfigStateNotification";

typedef NS_ENUM(NSInteger, SmartConfigState) {
    connected  = 0,     //设备连接到路由器
    connecting  = 1,    //设备正在连接路由器
    disconnected  = 2,     //设备断开连接
    connectionFailed  = 3,     //设备连接路由器失败
    serverConnected  = 4,    //设备连接到服务器，并配网成功
    serverConnecting  =5,    //设备正在连接服务器
    serverConnectFailed  = 6,     //设备连接服务器失败
    iotConnected  = 7,    //设备认证iot成功
    iotConnecting  = 8,    //设备正在连接iot服务器
    iotConnectFailed  = 9,   //设备连接iot服务器失败
    resp_Deviceinfo = 10,     //设备返回设备信息数据
};

//typedef NS_ENUM(NSInteger,BleState) {
//    ble_scaned_device = -2,
//    ble_scan_device_fail = -1,   //扫描设备失败
//    //是否连接到 设备蓝牙
//    ble_connected_device = 0,     //已经连接到设备
//    ble_connect_device_fail = 1,   //连接设备失败
//
//       //发送 会话握手
//    ble_sendSession_success = 2,
//    ble_sendSession_fail = 3,
//
//       //发送配置数据
//    ble_sendConfigData_success = 4,
//    ble_sendConfigData_fail = 5,
//
//       //发送配网请求
//    ble_sendConfigRequest_success = 6,
//    ble_sendConfigRequest_fail = 7,
//
//       //获取对应的 设备配网状态
//    device_configState_fail = 8,    //获取配网状态失败
//
//    device_configState_connecting = 9,
//    device_configState_connected = 10,
//    device_configState_connectFail = 11,
//
//    device_configState_serverConnecting = 12,
//    device_configState_serverConnected = 13,
//    device_configState_serverConnectFail = 14,
//
//    device_configState_iotConnecting = 15,
//    device_configState_iotConnected = 16,
//    device_configState_iotConnectFail = 17,
//
//    device_configState_unRecepted = 98, //发送到设备的数据，还未接到返回
//
//    unFound_config_device = 100, //找不到 配网设备
//
//    ble_device_unKnown = 99,
//};



NS_ASSUME_NONNULL_END
