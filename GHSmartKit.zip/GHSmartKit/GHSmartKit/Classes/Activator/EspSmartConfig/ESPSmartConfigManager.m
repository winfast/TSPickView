//
//  ESPSmartConfigManager.m
//  EspTouchDemo
//
//  Created by houcheng on 2020/6/10.
//  Copyright © 2020 Espressif. All rights reserved.
//

#import "ESPSmartConfigManager.h"

//#import "ESPTCPSocketServer.h"
#import "ESPTools.h"
#import "ESPTouchTask.h"
#import "ESPConstant.h"
//#import "GHome-Swift.h"
#import "GCDAsyncUdpSocket.h"
#import "CucoUDPSocketClient.h"


#define MaxDevices 1



@interface EspTouchDelegateResult : NSObject<GCDAsyncUdpSocketDelegate,ESPProvisionerDelegate>

@end

@implementation EspTouchDelegateResult

-(void) onEsptouchResultAddedWithResult: (ESPTouchResult *) result
{
    NSLog(@"EspTouchDelegateImpl onEsptouchResultAddedWithResult bssid: %@", result.bssid);
    dispatch_async(dispatch_get_main_queue(), ^{
      //  [self showAlertWithResult:result];
    });
}

@end


@interface ESPSmartConfigManager()

@property (nonatomic, strong) EspTouchDelegateResult *_esptouchDelegate;

@property (nonatomic,copy)NSDictionary *tokenDic;

@property (nonatomic, strong) CucoUDPSocketClient * client;


@end

@implementation ESPSmartConfigManager

+ (instancetype)sharedInstance{
    static dispatch_once_t onceToken;
    static ESPSmartConfigManager *_sharedSingleton = nil;
    dispatch_once(&onceToken, ^{
          // 要使用self来调用
        _sharedSingleton = [[self alloc] init];
    });
    return _sharedSingleton;
}

- (instancetype)init {
    self = [super init];
    if (self) {
    }
    return self;
}


#pragma mark - public method

/**
   开始通过广播扫描设备
 */
- (void)startScanDeviceWithSSID:(NSString *)ssid password:(NSString *)pwd withToken:(NSDictionary *)tokenDict{
    if (ssid == nil || [ssid isEqualToString:@""] || self.isScaning == YES) {
        return;
    }
    
    NSString *bssid = ESPTools.getCurrentBSSID;
    if ([[ESPProvisioner share] isProvisioning]) {
        return;
    }
    self.tokenDic = tokenDict;
    ESPProvisioningRequest *request = [[ESPProvisioningRequest alloc] init];
    request.ssid = [ESP_ByteUtil getBytesByNSString:ssid];
    request.password = [ESP_ByteUtil getBytesByNSString:pwd];
    request.bssid = [ESP_NetUtil parseBssid2bytes:bssid];
    [[ESPProvisioner share] startProvisioning:request withDelegate:self];
}

/**
  结束扫描广播包的发送（停止扫描 推出配网起始页时调用）
*/
- (void)endScanDevice{
    //终止扫描
	if ([[ESPProvisioner share] isProvisioning]) {
		[[ESPProvisioner share] stopProvisioning];
	}
	
	[self.client closeUDPSocket];
}

- (void)scanedDeviceNotification:(NSNotification *)notification{
    NSDictionary *info = notification.userInfo;
    if (info == nil) {
        return;
    }
    NSArray *scanedDeviceIDs = [[NSArray alloc] initWithObjects:[info objectForKey:@"device_id"], nil];
    if (scanedDeviceIDs != nil && scanedDeviceIDs.count != 0) {
        void (^block)(NSArray *str) = self.scanedDeviceBlock;
        if (block) {
            self.scanedDeviceBlock(scanedDeviceIDs);
        }
    }
}
- (void)stopProvisioning:(NSException *)exception {
    [[ESPProvisioner share] stopProvisioning];
}
- (void)onProvisioningStart {
    NSLog(@"onProvisionStart");
}

- (void)onProvisioningStop {
    NSLog(@"onProvisionStop");
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        [self stopProvisioning:nil];
    }];
}

- (void)onProvisioningError:(NSException *)exception {
    NSLog(@"onProvisionError: %@", exception);
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        [self stopProvisioning:exception];
    }];
}

- (void)onProvisoningScanResult:(ESPProvisioningResult *)result {
	if (self.client) {
		[self.client closeUDPSocket];
	}
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.client = [[CucoUDPSocketClient alloc] init];
        [self.client initUDPSocktWithIP:result.address withToken:self.tokenDic];
        __weak typeof(self) weakSelf = self;
        self.client.recieveUDPServiceData = ^(CucoUDPSocketClient * _Nonnull udpClientSocket, NSDictionary * _Nonnull data) {
            NSArray *scanedDeviceIDs = [[NSArray alloc] initWithObjects:[data objectForKey:@"device_id"], nil];
            if (scanedDeviceIDs != nil && scanedDeviceIDs.count != 0) {
                !weakSelf.scanedDeviceBlock ?: weakSelf.scanedDeviceBlock(scanedDeviceIDs);
            }
        };
    });
}

@end
