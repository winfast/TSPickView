//
//  CucoUDPSocketClient.m
//  Runner
//
//  Created by wenzerong on 2020/9/2.
//  Copyright © 2020 The Chromium Authors. All rights reserved.
//

#import "CucoUDPSocketClient.h"
#import <MJExtension/MJExtension.h>

#define socketPort   8266
#define smartConfigScanedDeviceNotification
@interface CucoUDPSocketClient()<GCDAsyncUdpSocketDelegate>

@property (strong, nonatomic) GCDAsyncUdpSocket * udpSocket;
@property (nonatomic, strong) dispatch_queue_t delegateQueue;
@property (nonatomic, strong) NSTimer * sendTimer;

@property (nonatomic, copy) NSData *reciveData;
@property (nonatomic, copy) NSString *ipStr;
@property (nonatomic, copy) NSDictionary *tokenDict;
@property (nonatomic) NSInteger sendCount;

@end


@implementation CucoUDPSocketClient

- (void)closeUDPSocket {
	[self.udpSocket pauseReceiving];
	self.udpSocket.delegate = nil;
	[self.udpSocket close];
	self.udpSocket = nil;
}

- (void)initUDPSocktWithIP:(NSString*)ip withToken:(NSDictionary *)tokenDict{
    self.ipStr = ip;
    self.tokenDict = tokenDict;
    
    if(self.udpSocket){ //如果当前udp为连接状态，则先断开并销毁
		[self closeUDPSocket];
    }
    NSError *error = nil;
    NSError *dataRError = nil;
    self.udpSocket = [[GCDAsyncUdpSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_main_queue()];
    BOOL isSuccess = [self.udpSocket bindToPort:socketPort error:&error];
    if (isSuccess) {
        BOOL isSuccess = [self.udpSocket beginReceiving:&dataRError];
        if (isSuccess) {
            [self sendDataToIP:ip withToken:tokenDict];
        } else {
            //异常处理
        }
    }
    
    if (self.sendTimer == nil) {
        __weak typeof(self) weakSelf = self;
        self.sendTimer = [NSTimer scheduledTimerWithTimeInterval:1 repeats:YES block:^(NSTimer * _Nonnull timer) {
            weakSelf.sendCount += 1;
            //1S发送一次，如果设备端没有回复成功，则连续发送10次。至到超时或者发满10次
            if ((!weakSelf.reciveData) && (weakSelf.sendCount <= 10)){
                [weakSelf sendDataToIP:weakSelf.ipStr withToken:tokenDict];
            } else {
                [weakSelf udpSendStop];
            }
        }];
    }
}

- (void)udpSendStop {
    if (self.sendTimer != nil) {
        self.sendCount = 0;
        [self.sendTimer invalidate];
        self.sendTimer = nil;
    }
}

- (void)sendDataToIP:(NSString *)ipStr withToken:(NSDictionary *)tokenDict{
    NSString *configToken = [tokenDict mj_JSONString];
    [self.udpSocket sendData:[configToken dataUsingEncoding:NSUTF8StringEncoding] toHost:ipStr port:socketPort withTimeout:-1 tag:1001];
}

#pragma mark GCDAsyncUdpSocketDelegate

- (void)udpSocket:(GCDAsyncUdpSocket *)sock didReceiveData:(NSData *)data fromAddress:(NSData *)address withFilterContext:(id)filterContext{
    self.reciveData = data;
    NSString *reciveStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    NSArray *dataArray = [reciveStr componentsSeparatedByString:@"&"];
    if ([[dataArray objectAtIndex:1] containsString:@"true"]) {
		[self closeUDPSocket];
    }
    
    NSArray *deviceArray = [[dataArray objectAtIndex:0] componentsSeparatedByString:@"="];
    NSString *deviceidStr = [deviceArray objectAtIndex:1];
    NSDictionary *deviceidData = @{@"device_id":deviceidStr};
    !self.recieveUDPServiceData ?: self.recieveUDPServiceData(self, deviceidData);
}


- (void)udpSocket:(GCDAsyncUdpSocket *)sock didSendDataWithTag:(long)tag {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(7.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (self.udpSocket) {
			[self closeUDPSocket];
        }
    });
}

- (void)udpSocketDidClose:(GCDAsyncUdpSocket *)sock withError:(NSError *)error {
}

@end
