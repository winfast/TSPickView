//
//  ESPSmartConfigManager.h
//  EspTouchDemo
//
//  Created by houcheng on 2020/6/10.
//  Copyright © 2020 Espressif. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ESPConstant.h"

#import "ESPProvisioner.h"
#import <AFNetworking/AFNetworking.h>
#import "ESP_ByteUtil.h"
#import "ESP_NetUtil.h"

#import "ESPProvisioner.h"
#import "ESPProvisioningRequest.h"
#import "ESPProvisioningResult.h"
NS_ASSUME_NONNULL_BEGIN

@interface ESPSmartConfigManager : NSObject<ESPProvisionerDelegate>

@property (nonatomic, assign) BOOL isScaning;

@property (nonatomic, copy) void(^deviceConfigProcessBlock) (NSString * stateStr);

@property (nonatomic, copy) void(^scanedDeviceBlock) (NSArray *scanedDeviceIDs);

+ (instancetype)sharedInstance;

/**
   开始通过广播扫描设备
 */
- (void)startScanDeviceWithSSID:(NSString *)ssid password:(NSString *)pwd withToken:(NSDictionary *)tokenDict;

/**
  结束广播包的发送
*/
- (void)endScanDevice;

/**
//  获取当前扫描到，并且已经获取到设备名称，以及已经建立了socket连接 并当前保持着连接的广播配网设备
// */
//- (NSArray *)fetchFoundDevices;
//
///**
//   发送数据到某个设备
//*/
//- (void)sendDataToDevice:(NSString *)deviceName data:(NSString *)data;
//
//
///**
//   发送数据到所有设备
//*/
//- (void)sendDataToAllDevice:(NSString *)data;


/**
   开始发送数据进行配网
*/
//-(void)startSmartConfigWithData:(NSDictionary *)dataDic;

/**
    发送配网终止指令
*/
//-(void)abortConfigWithCmd:(int )abortToModelInt;

@end

NS_ASSUME_NONNULL_END
