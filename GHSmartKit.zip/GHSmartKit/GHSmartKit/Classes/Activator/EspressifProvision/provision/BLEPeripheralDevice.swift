//
//  BLEPeripheralDevice.swift
//  EspressifProvision
//
//  Created by houcheng on 2020/3/28.
//  Copyright © 2020 Espressif. All rights reserved.
//

import CoreBluetooth
import UIKit

enum BleState : Int{
    
    case ble_scaned_device = -2     //扫描到设备
    case ble_scan_device_fail = -1   //扫描设备失败
    
    //是否连接到 设备蓝牙
    case ble_connected_device = 0     //已经连接到设备
    case ble_connect_device_fail = 1   //连接设备失败
    
    //发送 会话握手
    case ble_sendSession_success = 2
    case ble_sendSession_fail = 3
    
    //发送配置数据
    case ble_sendConfigData_success = 4
    case ble_sendConfigData_fail = 5
    
    //发送配网请求
    case ble_sendConfigRequest_success = 6
    case ble_sendConfigRequest_fail = 7
    
    //获取对应的 设备配网状态
    case device_configState_fail = 8    //获取配网状态失败
    
    case device_configState_connecting = 9
    case device_configState_connected = 10
    case device_configState_connectFail = 11
    
    case device_configState_serverConnecting = 12
    case device_configState_serverConnected = 13
    case device_configState_serverConnectFail = 14
    
    case device_configState_iotConnecting = 15
    case device_configState_iotConnected = 16
    case device_configState_iotConnectFail = 17
    
    case device_configState_unRecepted = 98 //发送到设备的数据，还未接到返回
    
    case unFound_config_device = 100 //找不到 配网设备
    
    case ble_device_unKnown = 99
}

class BLEPeripheralDevice: NSObject{
    
    var  peripheralCanRead = false
    var  peripheralCanWrite = false
    
    var  currentService : CBService?
    
    var  sessionCharacteristicId : String?    //传输会话特征
    var  configCharacteristicId : String?    //配置会话特征
    
    var  sessionCharacteristic : CBCharacteristic?    //传输会话特征
    var  configCharacteristic : CBCharacteristic?    //配置会话特征
    var  characteristics : [CBCharacteristic] = []
    
    var currentRequestCompletionHandler: ((Data?, Error?) -> Void)? //回调参数
    
    var  peripheral : CBPeripheral?
    
    var timer: Timer? //超时监控器
    var sendDataState : Int = 0  //0为已经发送，1为已经接受到 回复
    
    var _state : BleState = BleState.ble_device_unKnown
    var abortConfigProcess: Bool = false
    
    var sendData = ""
    
    public var resultDelegate: BLETransportDelegate?
    
    var state: BleState?{
        set{
            _state = newValue!
            //配网状态 发送改变的时候，发送广播通知
            peripheral?.state;
            NotificationCenter.default.post(name: NSNotification.Name("ConfigNetworkStateChanged"), object: self, userInfo: ["identifier":self.peripheral?.identifier.uuidString ?? "","state":_state,"data":self.sendData]);
        }
        get{
            return _state
        }
    }
    
    
    func fetchBleConnectedState() -> Bool {
        var isConneted = false
        if self.peripheral?.state == CBPeripheralState.connected || self.peripheral?.state == CBPeripheralState.connecting {
            isConneted = true
        }
        return isConneted
    }
    
    //var sendSeries
    
    init(_ peripheral : CBPeripheral?,sessionCharacteristicId : String,configCharacteristicId : String ){
        self.peripheral = peripheral
        self.sessionCharacteristicId = sessionCharacteristicId;
        self.configCharacteristicId = configCharacteristicId;
       // self.currentService = "021A9004-0382-4AEA-BFF4-6B3F1C5ADFB4"
    }
    
    //发送会话数据额
    func SendSessionData(data: Data,
                         completionHandler: @escaping (Data?, Error?) -> Void) {
        //判读啊是否可以 进行数据传输
        
        
        
        if sessionCharacteristic == nil {
            completionHandler(nil, TransportError.deviceUnreachableError("传输特征为空"))
            return
        }

    //    self.timeoutListennign()
        self.peripheral?.writeValue(data, for: sessionCharacteristic!, type: .withResponse)
        currentRequestCompletionHandler = completionHandler
    }

    //发送配网数据
    func SendConfigData(path: String,
                        data: Data,
                        completionHandler: @escaping (Data?, Error?) -> Void) {
        print("准备通过蓝牙发送配网账号密码数据")

        if let characteristic = configCharacteristic {
            print("蓝牙配网账号密码发送完成");
          //  self.timeoutListennign()
            self.peripheral?.writeValue(data, for: characteristic, type: .withResponse)
            currentRequestCompletionHandler = completionHandler
        }
    }
    
    
    func timeoutListennign(){
        
        print("蓝牙发送定时器监控开启");
        //蓝牙请求定时器
        self.sendDataState = 0;
        
        self.timer?.invalidate()
        self.timer = nil;
        
        self.timer = Timer.scheduledTimer(timeInterval: 10,
        target: self,
        selector: #selector(cmdTimeountistennig),
        userInfo: nil,
        repeats: false)
    }
    
    @objc func cmdTimeountistennig(){
        
        print("蓝牙发送定时器方法结束");
        if self.sendDataState == 0 {
            NotificationCenter.default.post(name: NSNotification.Name("ConfigNetworkStateChanged"), object: self, userInfo: ["identifier":self.peripheral?.identifier.uuidString ?? "","state":BleState.device_configState_unRecepted ]);
        }
    }
}


extension BLEPeripheralDevice: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices _: Error?) {
        NSLog("找到services:%@", peripheral)
        guard let services = peripheral.services else { return }
        currentService = services.first

        if let currentService = currentService {
            self.peripheral?.discoverCharacteristics(nil, for: currentService)
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error _: Error?) {
        guard let characteristics = service.characteristics else { return }

        peripheralCanWrite = true
        self.characteristics = characteristics;
        for characteristic in characteristics {
            print("当前service的character:", characteristic as Any)
            
            if characteristic.uuid.uuidString == self.sessionCharacteristicId {
                self.sessionCharacteristic = characteristic
            }
            
            if characteristic.uuid.uuidString == self.configCharacteristicId {
                self.configCharacteristic = characteristic
            }
        }
        
       NotificationCenter.default.post(name: NSNotification.Name("bleConnectedDevice"), object: self, userInfo: ["identifier":peripheral.identifier.uuidString])
    }

    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        print("did write data");
        guard error == nil else {
            print("设备接受s失败");
            currentRequestCompletionHandler?(nil, error)
            return
        }
        
        self.sendDataState = 1 //标示收到设备回复消息
        print("设备接收到成功");
        peripheral.readValue(for: characteristic)
    }
    

    func peripheral(_: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard error == nil else {
            currentRequestCompletionHandler?(nil, error)
            return
        }
        
        if let currentRequestCompletionHandler = currentRequestCompletionHandler {
            DispatchQueue.global().async {
                currentRequestCompletionHandler(characteristic.value, nil)
            }
            self.currentRequestCompletionHandler = nil
        }
    }
    
    func  peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
         print("从蓝牙设备收到通知:");
        if (characteristic.isNotifying) {
            print("有新通知消息 读取数据");
            peripheral.readValue(for: characteristic)
        } else {
            
        }

    }
}
