// Copyright 2018 Espressif Systems (Shanghai) PTE LTD
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//  Provision.swift
//  EspressifProvision
//

import Foundation
import UIKit

/// Provision class which exposes the main API for provisioning
/// the device with Wifi credentials.

@objcMembers class Provision:NSObject {
    private let session: Session
    private let transport: Transport
    private let security: Security
    private var getResultTimes:Int //获取配网结果的次数（最多获取三次）
    
    public static let CONFIG_TRANSPORT_KEY = "transport"
    public static let CONFIG_SECURITY_KEY = "security"
    public static let CONFIG_PROOF_OF_POSSESSION_KEY = "proofOfPossession"
    public static let CONFIG_BASE_URL_KEY = "baseUrl"
    public static let CONFIG_WIFI_AP_KEY = "wifiAPPrefix"
    
    public static let CONFIG_TRANSPORT_WIFI = "wifi"
    public static let CONFIG_TRANSPORT_BLE = "ble"
    public static let CONFIG_SECURITY_SECURITY0 = "security0"
    public static let CONFIG_SECURITY_SECURITY1 = "security1"
    
    public static let CONFIG_BLE_SERVICE_UUID = "serviceUUID"
    public static let CONFIG_BLE_SESSION_UUID = "sessionUUID"
    public static let CONFIG_BLE_CONFIG_UUID = "configUUID"
    public static let CONFIG_BLE_DEVICE_NAME_PREFIX = "deviceNamePrefix"
    public static let PROVISIONING_CONFIG_PATH = "prov-config"
    public static let PROVISIONING_CUSTOM_PATH = "custom-config"
    
    private var wifiFailNum = 0
    
    var configProcessAbort : Bool = false
    
    
    /// Create Provision object with a Session object
    /// Here the Provision class will require a session
    /// which has been successfully initialised by calling Session.initialize
    ///
    /// - Parameter session: Initialised session object
    init(session: Session) {
        self.session = session
        transport = session.transport
        security = session.security
        getResultTimes = 0
        //        transport = session.transport
        //        security = session.security
    }
    
    /// Send Configuration information relating to the Home
    /// Wifi network which the device should use for Internet access
    
    ///
    //AP配网
    func configureWifi(data: String,
                       completionHandler: @escaping (Espressif_Status, Error?) -> Swift.Void) {
        
        if self.configProcessAbort {
            return
        }
        
        if session.isEstablished {
            do {
                let message = try createSetWifiConfigRequest(data: data)
                if let message = message {
                    transport.SendConfigData(path: Provision.PROVISIONING_CONFIG_PATH, data: message) { response, error in
                        guard error == nil, response != nil else {
                            print("ap配网http请求失败");
                            completionHandler(Espressif_Status.internalError, error)
                            return
                        }
                        let status = self.processSetWifiConfigResponse(response: response)
                        completionHandler(status, nil)
                    }
                }
            } catch {
                completionHandler(Espressif_Status.internalError, error)
            }
        }
    }
    
    //蓝牙配网
    func bleConfigureWifi(data: String,per:BLEPeripheralDevice,
                       completionHandler: @escaping (Espressif_Status, Error?) -> Swift.Void) {
        
        if per.abortConfigProcess {
            return
        }
        
        if session.isEstablished {
            do {
                print("蓝牙配网准备发送自定义数据:",per.peripheral?.identifier.uuidString);
                let message = try createSetWifiConfigRequest(data: data)
                if let message = message {
                    per.SendConfigData(path: Provision.PROVISIONING_CONFIG_PATH, data: message) { response, error in
                        guard error == nil, response != nil else {
                            completionHandler(Espressif_Status.internalError, error)
                            return
                        }
                        let status = self.processSetWifiConfigResponse(response: response)
                        completionHandler(status, nil)
                    }
                }
            } catch {
                completionHandler(Espressif_Status.internalError, error)
            }
        }
    }
    
    
    //AP 配网 申请
    func applyConfigurations(completionHandler: @escaping (Espressif_Status, Error?) -> Void,
                             wifiStatusUpdatedHandler: @escaping (Espressif_WifiStationState, Espressif_WifiConnectFailedReason, Error?) -> Void) {
        if self.configProcessAbort {
            return
        }
        
        if session.isEstablished {
            do {
                let message = try createApplyConfigRequest()
                if let message = message {
                    transport.SendConfigData(path: Provision.PROVISIONING_CONFIG_PATH, data: message) { response, error in
                        guard error == nil, response != nil else {
                            print("ap配网http请求失败");
                            completionHandler(Espressif_Status.internalError, error)
                            return
                        }
                        
                        let status = self.processApplyConfigResponse(response: response)
                        completionHandler(status, nil)
                        self.getResultTimes = 0
                        self.pollForWifiConnectionStatus { wifiStatus, failReason, error in
                            wifiStatusUpdatedHandler(wifiStatus, failReason, error)
                        }
                    }
                }
            } catch {
                completionHandler(Espressif_Status.internalError, error)
            }
        }
    }
    
    //蓝牙 配网 申请
    func bleApplyConfigurations(_ per:BLEPeripheralDevice,completionHandler: @escaping (Espressif_Status, Error?) -> Void,
                             wifiStatusUpdatedHandler: @escaping (Espressif_WifiStationState, Espressif_WifiConnectFailedReason, Error?) -> Void) {
        
        if per.abortConfigProcess {
            return
        }
        
        if session.isEstablished {
            do {
                let message = try createApplyConfigRequest()
                if let message = message {
                        per.SendConfigData(path: Provision.PROVISIONING_CONFIG_PATH, data: message) { response, error in
                        guard error == nil, response != nil else {
                            completionHandler(Espressif_Status.internalError, error)
                            return
                        }
                        
                        let status = self.processApplyConfigResponse(response: response)
                        completionHandler(status, nil)
                        self.blePollForWifiConnectionStatus(per){ wifiStatus, failReason, error in
                            wifiStatusUpdatedHandler(wifiStatus, failReason, error)
                        }
                    }
                }
            } catch {
                completionHandler(Espressif_Status.internalError, error)
            }
        }
    }
    
    
    
    //ap配网
    private func pollForWifiConnectionStatus(completionHandler: @escaping (Espressif_WifiStationState, Espressif_WifiConnectFailedReason, Error?) -> Swift.Void) {
        if self.configProcessAbort {
            return
        }
        print("准备获取配网状态");
        do {
            let message = try createGetWifiConfigRequest()
            if let message = message {
                transport.SendConfigData(path: Provision.PROVISIONING_CONFIG_PATH,
                                         data: message) { response, error in
                                            guard error == nil, response != nil else {
                                                print("获取配网状态失败");
                                                //获取配网状态失败
                                                NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.device_configState_fail]);
                                        completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                                                return
                                            }
                                            do {
                                                let (result,responseStatus, deviceID,_) = try self.processGetWifiConfigStatusResponse(response: response)
                                                //如果超过三次还未获取到result =true，则flutter端走超时处理，这边不做处理
                                                print("ap-self.getResultTimes===",self.getResultTimes)
                                                print("ap-self.results===",result)
                                                if(deviceID.count == 0 && self.getResultTimes <= 3){
													print("ap-responseStatus== 未能获取到设备ID")
                                                    sleep(1)
                                                    self.pollForWifiConnectionStatus(completionHandler: completionHandler)
                                                    self.getResultTimes += 1
                                                }else if(deviceID.count != 0){
                                                    print("ap-responseStatus==连接成功")
                                                    print("result==",result)
                                                    NotificationCenter.default.post(name: NSNotification.Name("ApOrBleConfigScanedDevice"), object: self, userInfo: ["deviceID":deviceID]);
                                                }
//                                                if(result == false && self.getResultTimes < 4){
//                                                    sleep(1)
//                                                    self.pollForWifiConnectionStatus(completionHandler: completionHandler)
//                                                }
//                                                if stationState == .iotConnected {
//                                                   NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.device_configState_iotConnected]);
//                                                    sleep(2)
//                                                    self.pollForWifiConnectionStatus(completionHandler: completionHandler)
//                                                } else if stationState == .connecting {
//                                                  NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.device_configState_connecting]);
//                                                    sleep(2)
//                                                    self.pollForWifiConnectionStatus(completionHandler: completionHandler)
//                                                } else if stationState == .connected {
//                                                    NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.device_configState_connected]);
//                                                    sleep(2)
//                                                   self.pollForWifiConnectionStatus(completionHandler: completionHandler)
//                                                }else if stationState == .connectionFailed {
//                                                      NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.device_configState_connectFail]);
////                                                    completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
//                                                    sleep(2)
//                                                    self.pollForWifiConnectionStatus(completionHandler: completionHandler)
//                                                }else if stationState == .serverConnecting {
//                                                    NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.device_configState_serverConnecting]);
//                                                    sleep(2)
//                                                    self.pollForWifiConnectionStatus(completionHandler: completionHandler)
//                                                }else if stationState == .serverConnected {
//                                                    NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.device_configState_serverConnected]);
//                                                    completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
//                                                }else if stationState == .serverConnectFailed {
//                                                    NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.device_configState_serverConnectFail,"data":data]);
////                                                    completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
//                                                    sleep(2)
//                                                    self.pollForWifiConnectionStatus(completionHandler: completionHandler)
//                                                }else if stationState == .iotConnecting {
//                                                   NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.device_configState_iotConnecting]);
//                                                    sleep(2)
//                                                    self.pollForWifiConnectionStatus(completionHandler: completionHandler)
//                                                }else if stationState == .iotConnectFailed {
//                                                    NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.device_configState_iotConnectFail,"data":data]);
////                                                    completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
//                                                    sleep(2)
//                                                    self.pollForWifiConnectionStatus(completionHandler: completionHandler)
//                                                }else {
//                                                    NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.ble_device_unKnown]);
//                                                    completionHandler(stationState, failReason, nil)
//                                                }
                                            } catch {
                                                //捕获异常
												print("HTTP 请求失败");
                                                completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                                            }
                }
            }
        } catch {
            completionHandler(Espressif_WifiStationState.connectionFailed, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
        }
    }
    
    //蓝牙配网，获取设备配网状态
    private func blePollForWifiConnectionStatus(_ per:BLEPeripheralDevice,completionHandler: @escaping (Espressif_WifiStationState, Espressif_WifiConnectFailedReason, Error?) -> Swift.Void) {
        if per.abortConfigProcess {
            return
        }
        print("准备获取配网状态");
        sleep(1)
        do {
            let message = try createGetWifiConfigRequest()
            if let message = message {
                per.SendConfigData(path: Provision.PROVISIONING_CONFIG_PATH,
                                         data: message) { response, error in
                                            guard error == nil, response != nil else {
                                                if(self.getResultTimes <= 3){
                                                    sleep(1)
                                                    self.pollForWifiConnectionStatus(completionHandler: completionHandler)
                                                    self.getResultTimes += 1
                                                }
                                                per.state = BleState.device_configState_fail
                                                completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                                                return
                                            }
                                            
                                            do {
                                                let (result,responseStatus, deviceID,_) = try self.processGetWifiConfigStatusResponse(response: response)
//                                                per.sendData = data
                                                print("ble-self.getResultTimes===",self.getResultTimes)
                                                print("ble-self.results===",result)
                                                //如果超过三次还未获取到result =true，则flutter端走超时处理，这边不做处理
                                                if(deviceID.count == 0 && self.getResultTimes <= 3){
                                                    sleep(1)
                                                    self.pollForWifiConnectionStatus(completionHandler: completionHandler)
                                                    self.getResultTimes += 1
                                                }else if(deviceID.count != 0){
                                                    print("ble-responseStatus==连接成功")
                                                    print("ble-result==",result)
                                                    NotificationCenter.default.post(name: NSNotification.Name("ApOrBleConfigScanedDevice"), object: self, userInfo: ["deviceID":deviceID]);
                                                }
//                                                if stationState == .iotConnected {
//                                                    per.state = BleState.device_configState_iotConnected
//                                                    sleep(2)
//                                                    self.blePollForWifiConnectionStatus(per,completionHandler: completionHandler)
//
//                                                } else if stationState == .connecting {
//                                                    per.state = BleState.device_configState_connecting
//                                                    sleep(2)
//                                                    self.blePollForWifiConnectionStatus(per,completionHandler: completionHandler)
//                                                } else if stationState == .connected {
//                                                    per.state = BleState.device_configState_connected
//                                                    sleep(2)
//                                                    self.blePollForWifiConnectionStatus(per,completionHandler: completionHandler)
//                                                }else if stationState == .connectionFailed {
//                                                    per.state = BleState.device_configState_connectFail
////                                                    completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
//                                                    sleep(2)
//                                                    self.blePollForWifiConnectionStatus(per,completionHandler: completionHandler)
//                                                }else if stationState == .serverConnecting {
//                                                    per.state = BleState.device_configState_serverConnecting
//                                                    sleep(2)
//                                                    self.blePollForWifiConnectionStatus(per,completionHandler: completionHandler)
//                                                }else if stationState == .serverConnected {
//                                                    per.state = BleState.device_configState_serverConnected
//                                                    completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
//                                                }else if stationState == .serverConnectFailed {
//                                                    per.state = BleState.device_configState_serverConnected
////                                                    completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
//                                                    sleep(2)
//                                                    self.blePollForWifiConnectionStatus(per,completionHandler: completionHandler)
//                                                }else if stationState == .iotConnecting {
//                                                    per.state = BleState.device_configState_iotConnecting
//                                                    sleep(2)
//                                                    self.blePollForWifiConnectionStatus(per,completionHandler: completionHandler)
//                                                }else if stationState == .iotConnectFailed {
//                                                    per.state = BleState.device_configState_iotConnectFail
////                                                    completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
//                                                    sleep(2)
//                                                    self.blePollForWifiConnectionStatus(per,completionHandler: completionHandler)
//                                                }else {
//                                                    per.state = BleState.ble_device_unKnown
//                                                    completionHandler(stationState, failReason, nil)
//                                                }
                                            } catch {
                                                completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                                            }
                }
            }
        } catch {
            completionHandler(Espressif_WifiStationState.connectionFailed, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
        }
    }
    
    //ap获取设备信息
    func fetchDeviceInfo(completionHandler: @escaping (Espressif_WifiStationState, Espressif_WifiConnectFailedReason, Error?) -> Swift.Void) {
        if self.configProcessAbort {
            return
        }
            do {
                let message1 = try createFetchConfigRequest1()
                let message2 = try createFetchConfigRequest2()
                if let message = message1 {
                    transport.SendConfigData(path: Provision.PROVISIONING_CONFIG_PATH,
                                             data: message) { response, error in
                        guard error == nil && response != nil else {
                            print("获取设备信息失败失败");
                            completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                            return
                        }
                                                
                        print("获取设备信息成功");
                        do {
                            let (_,stationState, _,_) = try self.processGetWifiConfigStatusResponse(response: response)
                            completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
                        } catch {
                            completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                        }
                    }
                }
                if let message = message2 {
                    transport.SendConfigData(path: Provision.PROVISIONING_CONFIG_PATH,
                                             data: message) { response, error in
                        guard error == nil && response != nil else {
                            print("获取设备信息失败失败");
                            completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                            return
                        }
                                                
                        print("获取设备信息成功");
                        do {
                            let (_,stationState, _,_) = try self.processGetWifiConfigStatusResponse(response: response)
                            completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
                        } catch {
                            completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                        }
                    }
                }
            } catch {
                completionHandler(Espressif_WifiStationState.connectionFailed, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
            }
        }
    
    //蓝牙获取设备信息
    func bleFetchDeviceInfo( per:BLEPeripheralDevice,completionHandler: @escaping (Espressif_WifiStationState, Espressif_WifiConnectFailedReason, Error?) -> Swift.Void) {
        if per.abortConfigProcess {
            return
        }
            do {
                let message1 = try createFetchConfigRequest1()
                let message2 = try createFetchConfigRequest2()
                print("蓝牙获取设备信息message=== ",message1!)
                if let message = message1 {
                    per.SendConfigData(path: Provision.PROVISIONING_CONFIG_PATH,
                                             data: message) { response, error in
                        guard error == nil && response != nil else {
                            print("获取设备信息失败失败");
                            completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                            return
                        }
                     
    
                        do {
                            let (_,stationState, _,_) = try self.processGetWifiConfigStatusResponse(response: response)
                            completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
                        } catch {
                            completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                        }
                    }
                 }
                if let message = message2 {
                                per.SendConfigData(path: Provision.PROVISIONING_CONFIG_PATH,
                                                         data: message) { response, error in
//                                 let newStr = String(data: response!, encoding: String.Encoding.utf8)
//                                 print("reieceData",newStr!);
                                    guard error == nil && response != nil else {
                                        print("获取设备信息失败失败");
                                        completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                                        return
                                    }
                                 
                
                                    do {
                                        let (_,stationState, _,_) = try self.processGetWifiConfigStatusResponse(response: response)
                                        completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
                                    } catch {
                                        completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                                    }
                                }
                            }
            } catch {
                completionHandler(Espressif_WifiStationState.connectionFailed, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
            }
        }
    
    // 蓝牙 中断配网指令
    func bleSendCustomCmd(cmd:Int, per:BLEPeripheralDevice,completionHandler: @escaping (Espressif_WifiStationState, Espressif_WifiConnectFailedReason, Error?) -> Swift.Void) {
               do {
                   let message = try createCustomCmdRequest(cmd: cmd)
                   if let message = message {
                       per.SendConfigData(path: Provision.PROVISIONING_CONFIG_PATH,
                                                data: message) { response, error in
                           guard error == nil && response != nil else {
                               completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                               return
                           }
       
                           do {
                            let (_,stationState, _,_) = try self.processGetWifiConfigStatusResponse(response: response)
                               completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
                           } catch {
                               completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                           }
                       }
                   }
               } catch {
                   completionHandler(Espressif_WifiStationState.connectionFailed, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
               }
           }
    
    // ap 中断配网指令
    func apSendCustomCmd(cmd:Int,completionHandler: @escaping (Espressif_WifiStationState, Espressif_WifiConnectFailedReason, Error?) -> Swift.Void) {
               do {
                   let message = try createCustomCmdRequest(cmd: cmd)
                   if let message = message {
                       transport.SendConfigData(path: Provision.PROVISIONING_CONFIG_PATH,
                                                data: message) { response, error in
                           guard error == nil && response != nil else {
                               completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                               return
                           }
                           do {
                            let (_,stationState, _,_) = try self.processGetWifiConfigStatusResponse(response: response)
                               completionHandler(stationState, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), nil)
                           } catch {
                               completionHandler(Espressif_WifiStationState.disconnected, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
                           }
                       }
                   }
               } catch {
                   completionHandler(Espressif_WifiStationState.connectionFailed, Espressif_WifiConnectFailedReason.UNRECOGNIZED(0), error)
               }
           }
    
    private func createSetWifiConfigRequest(data: String) throws -> Data? {
        print("将发给用户的配网数据是:",data);
        var configData = Espressif_WiFiConfigPayload()
        configData.msg = Espressif_WiFiConfigMsgType.typeCmdSetConfig
        configData.cmdSetConfig.ssid = Data(data.bytes)
       // configData.cmdSetConfig.passphrase = Data(passphrase.bytes)
        return try security.encrypt(data: configData.serializedData())
    }
    
    
    private func createSetCustomConfigRequest(json: String) throws -> Data? {
        var configData = CustomConfigRequest()
        configData.paramter = Data(json.bytes)
        let binaryData: Data = try configData.serializedData()
        return security.encrypt(data: binaryData)
        
        //          configData.paramter = json
        //        let binaryData: Data = try configData.jsonUTF8Data()
        //        return try security.encrypt(data: binaryData)
    }
    
    private func createFetchConfigRequest1() throws -> Data? {
           let dic : [String : Any] = ["req_dev_info":1]
           let data : String = self.getJSONStringFromDictionary(dictionary: dic as NSDictionary);

           var configData = Espressif_WiFiConfigPayload()
           configData.msg = Espressif_WiFiConfigMsgType.typeCmdSetConfig
           configData.cmdSetConfig.ssid = Data(bytes: data.bytes)
       
           return try security.encrypt(data: configData.serializedData())
    }
    
    //获取设备信息 数据
    private func createFetchConfigRequest2() throws -> Data? {
        let dic : [String : Any] = ["req_dev_info":1]
        let data : String = self.getJSONStringFromDictionary(dictionary: dic as NSDictionary);

        var configData = Espressif_WiFiConfigPayload()
        configData.msg = Espressif_WiFiConfigMsgType.typeCmdGetStatus
        configData.cmdSetConfig.ssid = Data(bytes: data.bytes)
        print("configData.msg = \(configData.msg),configData.cmdSetConfig.ssid = \(configData.cmdSetConfig.ssid) ")
        return try security.encrypt(data: configData.serializedData())
    }
    
    //创建发送自定义指令
    private func createCustomCmdRequest(cmd : Int) throws -> Data? {
           let dic : [String : Any] = ["req_dev_info":cmd]
           let data : String = self.getJSONStringFromDictionary(dictionary: dic as NSDictionary)
            print("data ====\(data)")
           var configData = Espressif_WiFiConfigPayload()
           configData.msg = Espressif_WiFiConfigMsgType.typeCmdSetConfig
           configData.cmdSetConfig.ssid = Data(bytes: data.bytes)
           print("configData.msg = \(configData.msg),configData.cmdSetConfig.ssid = \(configData.cmdSetConfig.ssid) ")
           return try security.encrypt(data: configData.serializedData())
       }
    //创建申请配网指令
    private func createApplyConfigRequest() throws -> Data? {
        var configData = Espressif_WiFiConfigPayload()
        configData.cmdApplyConfig = Espressif_CmdApplyConfig()
        configData.msg = Espressif_WiFiConfigMsgType.typeCmdApplyConfig
        
        return try security.encrypt(data: configData.serializedData())
    }
    //创建获取配网状态数据
    private func createGetWifiConfigRequest() throws -> Data? {
        var configData = Espressif_WiFiConfigPayload()
        configData.cmdGetStatus = Espressif_CmdGetStatus()
        configData.msg = Espressif_WiFiConfigMsgType.typeCmdGetStatus
        
        return try security.encrypt(data: configData.serializedData())
    }
    //解析配网状态返回的数据
    private func processSetWifiConfigResponse(response: Data?) -> Espressif_Status {
        guard let response = response else {
            return Espressif_Status.invalidArgument
        }
        
        let decryptedResponse = security.decrypt(data: response)!
        var responseStatus: Espressif_Status = .invalidArgument
        do {
            let configResponse = try Espressif_WiFiConfigPayload(serializedData: decryptedResponse)
            responseStatus = configResponse.respGetStatus.status
        } catch {
            print(error)
        }
        return responseStatus
    }
    //解析申请配网返回的数据1
    private func processApplyConfigResponse(response: Data?) -> Espressif_Status {
        guard let response = response else {
            return Espressif_Status.invalidArgument
        }
        
        let decryptedResponse = security.decrypt(data: response)!
        var responseStatus: Espressif_Status = .invalidArgument
        do {
            let configResponse = try Espressif_WiFiConfigPayload(serializedData: decryptedResponse)
            responseStatus = configResponse.respApplyConfig.status
        } catch {
            print(error)
        }
        return responseStatus
    }
    //解析配网进度返回的数据2
    private func processGetWifiConfigStatusResponse(response: Data?) throws -> (Bool, Espressif_WifiStationState, String,String) {
        guard let response = response else {
            return (false,Espressif_WifiStationState.disconnected, "","")
        }
        
        let decryptedResponse = security.decrypt(data: response)!
        var responseStatus = Espressif_WifiStationState.disconnected
//        var failReason = Espressif_WifiConnectFailedReason.UNRECOGNIZED(-1)
        let configResponse = try Espressif_WiFiConfigPayload(serializedData: decryptedResponse)
        responseStatus = configResponse.respGetStatus.staState
//        failReason = configResponse.respGetStatus.failReason
        let deviceid = configResponse.respGetStatus.connected.deviceID
        let isResult = configResponse.respGetStatus.connected.result
        let deviceIDStr = String(data: deviceid, encoding: String.Encoding.utf8)!
        print("查询状态请求:",responseStatus)
        print("收到返回结果:",configResponse)
        print("收到返回结果isResult:",isResult)
        print("收到返回结果deviceid:",deviceIDStr)
        
       
        var data = ""
        if(configResponse.respGetStatus.staState == .iotConnectFailed || configResponse.respGetStatus.staState == .serverConnectFailed){
            
            let result = configResponse.respGetStatus.connected.ssid;
            
            let resultU8 : [UInt8] = [UInt8](result)
            let resultStr = String(bytes: resultU8, encoding: .utf8)!
                   
            let arr = resultStr.split(separator: ":")
            
            var errorCode = "xxx"
            if arr.count > 1 {
                let strt = arr[1]
                errorCode = String(strt.prefix(strt.count - 1))
            }
            data = errorCode
        }
        
 //       if configResponse.respGetStatus.connected.bssid != nil{
//            let result = configResponse.respGetStatus.connected.bssid;
//            let resultU8 : [UInt8] = [UInt8](result)
//            let resultStr = String(bytes: resultU8, encoding: .utf8)!
//            print("bssid:\(resultStr)");
 //       }
        print("configResponse.respGetStatus.staState ==",configResponse.respGetStatus.staState)
        return (isResult,responseStatus, deviceIDStr,data)
    }
    
    
    //字典 转换成 json 字符串
    func getJSONStringFromDictionary(dictionary:NSDictionary) -> String {
           if (!JSONSerialization.isValidJSONObject(dictionary)) {
               print("无法解析出JSONString")
               return ""
           }
        let data : NSData! = try! JSONSerialization.data(withJSONObject: dictionary, options: []) as NSData?
           let JSONString = NSString(data:data as Data,encoding: String.Encoding.utf8.rawValue)
           let str : String = JSONString! as String
           let result : String = str.replacingOccurrences(of: "\\", with: "")
           return result
    
    }
}
