// Copyright 2018 Espressif Systems (Shanghai) PTE LTD
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//  BLETransport.swift
//  EspressifProvision
//
                                //创建蓝牙对象，并进行会话建立，以及数据交互
import CoreBluetooth
import Foundation

class BLETransport: NSObject, Transport {
    private var serviceUUID: UUID?
    private var deviceNamePrefix: String?
    private var transportToken = DispatchSemaphore(value: 1)
    private var isBLEEnabled = false
    private var scanTimeout = 3.0
    private var bleSessionCharacteristicUUID: String
    
    var timer: Timer?

    var centralManager: CBCentralManager!
    var espressifPeripherals: [CBPeripheral] = []
    var currentPeripheral: CBPeripheral?
    var currentService: CBService?
    var sessionCharacteristic: CBCharacteristic!
    var configUUIDMap: [String: String]?

    var peripheralCanRead: Bool = true
    var peripheralCanWrite: Bool = false

    var currentRequestCompletionHandler: ((Data?, Error?) -> Void)?
    
    
    var sendingPeripherals: [BLEPeripheralDevice]?

    public var delegate: BLETransportDelegate?

    /// Create BLETransport implementation
    ///
    /// - Parameters:
    ///   - serviceUUIDString: string representation of the BLE Service UUID
    ///   - sessionUUIDString: string representation of the BLE Session characteristic UUID
    ///   - configUUIDMap: map of config paths and string representations of the BLE characteristic UUID
    ///   - deviceNamePrefix: device name prefix
    ///   - scanTimeout: timeout in seconds for which BLE scan should happen
    init(serviceUUIDString: String?,
         sessionUUIDString: String,
         configUUIDMap: [String: String],
         deviceNamePrefix: String,
         scanTimeout: TimeInterval)
    {
        if let serviceUUIDString = serviceUUIDString {
            serviceUUID = UUID(uuidString: serviceUUIDString)
        }
        self.deviceNamePrefix = deviceNamePrefix
        self.scanTimeout = scanTimeout
        bleSessionCharacteristicUUID = sessionUUIDString
        self.configUUIDMap = configUUIDMap
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: nil)
    }

    /// BLE implementation of Transport protocol
    ///
    /// - Parameters:
    ///   - data: data to be sent
    ///   - completionHandler: handler called when data is sent
    func SendSessionData(data: Data,
                         completionHandler: @escaping (Data?, Error?) -> Void) {
        guard peripheralCanWrite, peripheralCanRead,
            let espressifPeripheral = currentPeripheral else {
            completionHandler(nil, TransportError.deviceUnreachableError("BLE device unreachable"))
            return
        }
        centralManager.state;
        transportToken.wait()
        espressifPeripheral.writeValue(data, for: sessionCharacteristic, type: .withResponse)
        currentRequestCompletionHandler = completionHandler
    }

    /// BLE implemenation of the Transport protocol
    ///
    /// - Parameters:
    ///   - path: path of the config endpoint
    ///   - data: config data to be sent
    ///   - completionHandler: handler called when data is sent
    func SendConfigData(path: String,
                        data: Data,
                        completionHandler: @escaping (Data?, Error?) -> Void) {
        guard peripheralCanWrite, peripheralCanRead,
            let espressifPeripheral = currentPeripheral else {
            completionHandler(nil, TransportError.deviceUnreachableError("BLE device unreachable"))
            return
        }

        transportToken.wait()
        var characteristic: CBCharacteristic?
        if let characteristics = self.currentService?.characteristics {
            for c in characteristics {
                if c.uuid.uuidString.lowercased() == configUUIDMap![path]?.lowercased() {
                    characteristic = c
                    break
                }
            }
        }
        if let characteristic = characteristic {
            espressifPeripheral.writeValue(data, for: characteristic, type: .withResponse)
            currentRequestCompletionHandler = completionHandler
        } else {
            transportToken.signal()
        }
    }

    /// Connect to a BLE peripheral device.
    ///
    /// - Parameters:
    ///   - peripheral: The peripheral device
    ///   - options: An optional dictionary specifying connection behavior options.
    ///              Sent as is to the CBCentralManager.connect function
    func connect(peripherals: [BLEPeripheralDevice]?, withOptions options: [String: Any]?) {
        if let currentPeripheral = currentPeripheral {
            centralManager.cancelPeripheralConnection(currentPeripheral)
        }
      //  currentPeripheral = peripheral
        self.sendingPeripherals = peripherals
        for ble in peripherals ?? []{
            centralManager.connect(ble.peripheral!, options: options)
            ble.peripheral?.delegate = ble
        }
        
      //  currentPeripheral?.delegate = self
    }

    /// Disconnect from the current connected peripheral
    func disconnect() {
        if let currentPeripheral = currentPeripheral {
            centralManager.cancelPeripheralConnection(currentPeripheral)
        }
    }

    /// Scan for BLE devices
    ///
    /// - Parameter delegate: delegate which will receive resulting events
    func scan(delegate: BLETransportDelegate) {
        self.delegate = delegate

        if isBLEEnabled {
            
            if self.timer != nil {
                self.timer?.invalidate()
            }
            
            self.timer = Timer.scheduledTimer(timeInterval: scanTimeout,
                                     target: self,
                                     selector: #selector(stopScan),
                                     userInfo: nil,
                                     repeats: false)
            var uuids: [CBUUID]?
            if let serviceUUID = self.serviceUUID {
                uuids = [CBUUID(string: serviceUUID.uuidString)]
            }
            centralManager.scanForPeripherals(withServices: uuids)
        }
    }

    @objc func stopScan() {
        centralManager.stopScan()
        self.timer?.invalidate()
        self.timer = nil;
        delegate?.peripheralsFound(peripherals: espressifPeripherals)
        espressifPeripherals.removeAll()

    }
}

extension BLETransport: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .unknown:
            print("Bluetooth state unknown")
        case .resetting:
            print("Bluetooth state resetting")
        case .unsupported:
            print("Bluetooth state unsupported")
        case .unauthorized:
            print("Bluetooth state unauthorized")
        case .poweredOff:
            NotificationCenter.default.post(name: NSNotification.Name("BleConnectedStateTurnOff"      ), object: self, userInfo: nil);
            print("Bluetooth state off")
        case .poweredOn:
            print("Bluetooth state on")
            isBLEEnabled = true
            _ = Timer.scheduledTimer(timeInterval: scanTimeout,
                                     target: self,
                                     selector: #selector(stopScan),
                                     userInfo: nil,
                                     repeats: false)
            var uuids: [CBUUID]?
            if let serviceUUID = self.serviceUUID {
                uuids = [CBUUID(string: serviceUUID.uuidString)]
            }
            centralManager.scanForPeripherals(withServices: uuids)
        @unknown default: break
        }
    }

    func centralManager(_: CBCentralManager,
                        didDiscover peripheral: CBPeripheral,
                        advertisementData data: [String: Any],
                        rssi rssis: NSNumber) {
        print("发现蓝牙设备\(peripheral)---信号值\(rssis.intValue)")
        if rssis.intValue > -75 {//设置信号强度过滤，大于-75的才显示
            espressifPeripherals.append(peripheral)
        }
    }

    func centralManager(_: CBCentralManager, didConnect peripheral: CBPeripheral) {
        var uuids: [CBUUID]?
        print("蓝牙设备状态---连接成功",peripheral)
        if let serviceUUID = self.serviceUUID {
            uuids = [CBUUID(string: serviceUUID.uuidString)]
        }
        
        for per in self.sendingPeripherals ?? [] {
            if per.peripheral?.identifier.uuidString == peripheral.identifier.uuidString {
                per.state = BleState.ble_connected_device
                per.peripheral?.discoverServices(uuids)
            }
        }
    }

    func centralManager(_: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        //delegate?.peripheralDisconnected(peripheral: peripheral, error: error)
        for per in self.sendingPeripherals ?? [] {
            if per.peripheral?.identifier.uuidString == peripheral.identifier.uuidString {
                per.state = BleState.ble_connect_device_fail
            }
        }
    }

    func centralManager(_: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        print("蓝牙设备状态---断开连接:\(String(describing: peripheral.name)) id:\(peripheral.identifier.uuid)  ");
        delegate?.peripheralDisconnected(peripheral: peripheral, error: error)
    }
}

/// Delegate which will receive events relating to BLE device scanning
protocol BLETransportDelegate {
    /// Peripheral devices found with matching Service UUID
    /// Callers should call the BLETransport.connect method with
    /// one of the peripherals found here
    ///
    /// - Parameter peripherals: peripheral devices array
    func peripheralsFound(peripherals: [CBPeripheral])

    /// No peripherals found with matching Service UUID
    ///
    /// - Parameter serviceUUID: the service UUID provided at the time of creating the BLETransport object
    func peripheralsNotFound(serviceUUID: UUID?)

    /// Peripheral device configured.
    /// This tells the caller that the connected BLE device is now configured
    /// and can be provisioned
    ///
    /// - Parameter peripheral: peripheral that has been connected to
    func peripheralConfigured(peripheral: CBPeripheral)

    /// Peripheral device could not be configured.
    /// This tells the called that the connected device cannot be configured for provisioning
    /// - Parameter peripheral: peripheral that has been connected to
    func peripheralNotConfigured(peripheral: CBPeripheral)

    /// Peripheral device disconnected
    ///
    /// - Parameters:
    ///   - peripheral: peripheral device
    ///   - error: error
    func peripheralDisconnected(peripheral: CBPeripheral, error: Error?)
}
