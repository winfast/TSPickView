//
//  SmartConfigTransport.swift
//  Runner
//
//  Created by wenzerong on 2020/7/8.
//  Copyright © 2020 The Chromium Authors. All rights reserved.
//

import Foundation


@objc class SmartConfigTransport:NSObject{
    
    private let security: Security
    var pop = "abcd1234"
    override init() {
        self.security = Security0()
//        self.security = Security1(proofOfPossession: pop)
    }
    //创建发送自定义指令
     @objc public func createCustomCmdRequest(dic : NSDictionary) -> Data? {
        let string : String = self.getJSONStringFromDictionary(dictionary: dic as NSDictionary);
        print("data ====\(string)")
        var configData = Espressif_WiFiConfigPayload()
        configData.msg = Espressif_WiFiConfigMsgType.typeCmdSetConfig
        configData.cmdSetConfig.ssid = Data(bytes: string.bytes)
        print("configData.msg = \(configData.msg),configData.cmdSetConfig.ssid = \(configData.cmdSetConfig.ssid) ")
        var data :Data?
        do {
            try data = security.encrypt(data: configData.serializedData())
        } catch  {
            print(error)
        }
        return data
       }
//    解析申请配网返回的数据1
    @objc public func processApplyConfigResponse(response: Data?) -> Int {
           guard let response = response else {
            return Espressif_Status.invalidArgument.rawValue
           }

           let decryptedResponse = security.decrypt(data: response)!
           var responseStatus: Espressif_Status = .invalidArgument
           do {
               let configResponse = try Espressif_WiFiConfigPayload(serializedData: decryptedResponse)
               responseStatus = configResponse.respGetStatus.status
           } catch {
               print(error)
           }
        return responseStatus.rawValue
    }
    //解析配网进度返回的数据2
     @objc public func processGetWifiConfigStatusResponse(response: Data?)  -> (Int) {
            guard let response = response else {
                return (Espressif_WifiStationState.disconnected.rawValue)
            }
            
            let decryptedResponse = security.decrypt(data: response)!
            var responseStatus = Espressif_WifiStationState.disconnected
//            var failReason = Espressif_WifiConnectFailedReason.UNRECOGNIZED(-1)
//            let configResponse = try Espressif_WiFiConfigPayload(serializedData: decryptedResponse)
            do {
                let configResponse = try Espressif_WiFiConfigPayload(serializedData: decryptedResponse)
                print("收到返回结果:-smartconfig",configResponse)
                responseStatus = configResponse.respGetStatus.staState
            } catch {
                print(error)
            }
            print("查询状态请求:-smartconfig",responseStatus)
//            print("configResponse.respGetStatus.staState ==",configResponse.respGetStatus.staState)
            return (responseStatus.rawValue)
        }
    
    //字典 转换成 json 字符串
    public func getJSONStringFromDictionary(dictionary:NSDictionary) -> String {
           if (!JSONSerialization.isValidJSONObject(dictionary)) {
               print("无法解析出JSONString")
               return ""
           }
        let data : NSData! = try! JSONSerialization.data(withJSONObject: dictionary, options: []) as NSData?
           let JSONString = NSString(data:data as Data,encoding: String.Encoding.utf8.rawValue)
           let str : String = JSONString! as String
           let result : String = str.replacingOccurrences(of: "\\", with: "")
           return result
    
    }
}
