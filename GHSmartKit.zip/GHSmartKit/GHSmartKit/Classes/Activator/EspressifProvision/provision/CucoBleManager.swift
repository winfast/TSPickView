//
//  CucoBleManager.swift
//  Runner
//
//  Created by houcheng on 2020/4/1.
//  Copyright © 2020 The Chromium Authors. All rights reserved.
//

//蓝牙操作管理（控制蓝牙扫描/停止扫描/发送蓝牙配网请求/蓝牙申请开始配网请求）---  蓝牙回调方法代理

import UIKit
import CoreBluetooth
import CoreTelephony

let BleConnectedDevice = "bleConnectedDevice"

typealias  ScanResult = (_ devices: String ) -> ();

typealias  BleStateChanged = (_  state: BleState ,  _ identifier : String ,_ data:String) -> ();
typealias  ApStateChanged = (_  state: BleState,_ data:String) -> ();

@objcMembers //声明swift中的属性可以被oc调用
public class CucoBleManager :NSObject { //“NSObject”声明此swift类可以被oc引用 必须带有bublic属性
    let safeQueue = DispatchQueue(label: "SafeArrayQueue", attributes: .concurrent)    //安全队列
    
    @objc public static let `default` = CucoBleManager()
    
    var canNotification = false

     var configData : String?  //配网数据
    
    var provisionConfig: [String: String] = [:]
    var bleTransport: BLETransport?
    var peripherals: [CBPeripheral]?
    
    var sendingpPeripherals: [BLEPeripheralDevice]?    //正在发送 外接设备队列
    var sendingpProvision: [String:Provision]?    //正在发送 provision 队列
    var apProvision : Provision? //ap配网provision
    
    var pop = "abcd1234"/// Bundle.main.infoDictionary?["ProofOfPossession"] as! String
    private let ssid = "ESPIndia"
    private let passphrase = "5=ChotaCoke"
       // BLE
    var serviceUUIDString: String? = "021A9004-0382-4AEA-BFF4-6B3F1C5ADFB4"
    var sessionUUIDString: String? = "021AFF51-0382-4AEA-BFF4-6B3F1C5ADFB4"
    var configUUIDString: String? = "021AFF52-0382-4AEA-BFF4-6B3F1C5ADFB4"
    private let deviceNamePrefix: String?  = "PROV_"
       // WIFI
    var baseUrl = "192.168.4.1:80"//Bundle.main.infoDictionary?["WifiBaseUrl"] as! String
    var networkNamePrefix = ""//Bundle.main.infoDictionary?["WifiNetworkNamePrefix"] as! String

    var transport: Transport?
    var security: Security?
    
    var apTransport: Transport?   //ap配网transport
    
    var scanResult : ScanResult? //扫描结果回调
    var checkScanResult : ScanResult? //扫描结果回调
    
    var bleStateChanged : BleStateChanged? //蓝牙配网状态监控回调
    var apStateChanged : ApStateChanged? //ap配网状态监控回调
    
    var scanDevices : [String] = []
    var connectTimer: Timer?
    var sendDataState : Int = 0  //0为已经发送请求，1为已经连接到了

    
    public override init() {
        if let serviceUuid = serviceUUIDString,
            let deviceNamePrefix = deviceNamePrefix,
            let sessionUuid = sessionUUIDString,
            let configUuid = configUUIDString {
            let configUUIDMap: [String: String] = [Provision.PROVISIONING_CONFIG_PATH: configUuid]
            bleTransport = BLETransport(serviceUUIDString: serviceUuid,
                                        sessionUUIDString: sessionUuid,
                                        configUUIDMap: configUUIDMap,
                                        deviceNamePrefix: deviceNamePrefix,
                                        scanTimeout: 3.0)
            transport = bleTransport
            print("serviceUuid====",serviceUuid)
        }
                
        //蓝牙配网
//        NotificationCenter.default.addObserver(self, selector: #selector(bleConnectedDevice), name: NSNotification.Name(rawValue:"bleConnectedDevice"), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(bleConfigStateChanged), name: NSNotification.Name(rawValue:"ConfigNetworkStateChanged"), object: nil)
//        //ap配网
//        NotificationCenter.default.addObserver(self, selector: #selector(apConfigStateChanged), name: NSNotification.Name(rawValue:"ApConfigNetworkStateChanged"), object: nil)
    }
    
    //接收到设备连接到蓝牙的消息通知方法
    @objc func bleConnectedDevice(nofi : Notification){
        self.sendDataState = 1;
        print("收到设备 ",nofi.userInfo!["identifier"] as Any," 蓝牙连接成功通知");
        let str : String = nofi.userInfo!["identifier"] as! String
        for ble in self.sendingpPeripherals ?? []{
            if ble.peripheral?.identifier.uuidString == str {
                self.bleProvisionDevice(ble)
            }
        }
    }
    
    //蓝牙配网状态监控
    @objc func bleConfigStateChanged(nofi : Notification) {
        let uid : String = nofi.userInfo!["identifier"] as! String
        let state:BleState = nofi.userInfo!["state"] as! BleState
        let data:String = nofi.userInfo!["data"] as! String
        
        
        //断开连接时候，正常发送
        if state == BleState.ble_connect_device_fail {
            if let bleStateChanged = self.bleStateChanged {
                bleStateChanged(state,uid,data);
            }
            return;
        }
        
        
        var per : BLEPeripheralDevice?
        for ble in self.sendingpPeripherals ?? []{
            if ble.peripheral?.identifier.uuidString == uid {
                per = ble;
            }
        }
        
        if let _ = per ,let bleStateChanged = self.bleStateChanged {
            bleStateChanged(state,uid,data);
        }
    }
    
    //ap配网状态监控
    @objc func apConfigStateChanged(nofi : Notification){
        //获取ap配网状态
        let state:BleState = nofi.userInfo!["state"] as! BleState
        var data:String? = nofi.userInfo!["data"]  as? String
        if data == nil {
            data = ""
        }
        
        if let apStateChanged = self.apStateChanged {
            apStateChanged(state,data!);
        }
    }
    
    
    @available(iOS 10.0, *)
    func fetchPhoneBleState() -> CBManagerState{
        return self.bleTransport?.centralManager.state ?? CBManagerState.unknown;
    }
    
    
    func fetchPhoneBleAuthority() -> String {
        if #available(iOS 13.0, *) {
            let  data:  CBManagerAuthorization = (self.bleTransport?.centralManager.authorization)!
            var  value = 0;
            
            switch data {
            case .notDetermined : value = 1     //扫描到设备
            case .denied: value = 2   //扫描设备失败
                
            case .allowedAlways : value = 3
            case .restricted : value = 4
            
            }
            
            if value != 3 {
                return "0";
            }else{
                return "1";
            }
            
        } else {
            return "1";
            // Fallback on earlier versions
        }
    }
    
    func hw_openEventServiceWithBolck(action :@escaping ((String)->())) {
        let cellularData = CTCellularData()
        cellularData.cellularDataRestrictionDidUpdateNotifier = { (state) in
            var result = "0"
            switch state {
            case .notRestricted:result = "1"
            case .restricted:result = "0"
            case .restrictedStateUnknown:result = "0"
            }
            action(result)
        }
    }
    
     
    //开始扫描
    @objc func startScan() {
        bleTransport?.scan(delegate: self)
    }
    
    //结束扫描
    func endScan() {
        bleTransport?.stopScan();
    }
    
    //发起ap配网请求∂
    @objc public func sendApConfigRequest() {
        //发起对外接设备的配网连接
        self.provisionDevice()
    }
    
    //检查设备扫描
    @objc func checkBleDeviceScan(_ devices : Array<Dictionary<String, String>>) {
        if devices.count == 0 {
            return;
        }
        
        //寻找到 扫描到的外接设备 对象
        let hasDevices = self.peripherals
        
        
        var sendPeriphers : [BLEPeripheralDevice] = [];
        print("区分设备:\(devices)  has:\(hasDevices)")
        for data in devices {
            for per in hasDevices ?? []{
                if per.identifier.uuidString == data["identifier"] {
                    let  ble : BLEPeripheralDevice = BLEPeripheralDevice(per, sessionCharacteristicId: self.sessionUUIDString!, configCharacteristicId: self.configUUIDString!)
                    sendPeriphers.append(ble)
                }
            }
        }
        
        if sendPeriphers.count > 0{
            //扫描到蓝牙设备
            if let bleStateChanged = self.bleStateChanged {
                bleStateChanged(BleState.ble_scaned_device,"","");
            }
        }else{
            //扫描不到设备
            print("重新扫描")
            self.startScan()
            self.checkScanResult = {[weak self] scanedDevices in
              //蓝牙扫描结果
                if let bleStateChanged = self?.bleStateChanged {
                    
                    if scanedDevices.count > 0 {
                        print("没有找到设备，无限扫描");
                        self?.checkBleDeviceScan(devices);
                        
                      //  bleStateChanged(BleState.ble_scaned_device,"");
                    }else{
                        bleStateChanged(BleState.ble_scan_device_fail,"","");
                    }
                }
                self?.checkScanResult = nil;
            }
        }
    }
    
    //发送蓝牙配网请求
    func sendBleConfigRequest(_ devices : Array<Dictionary<String, String>>) {
        print("开始准备配网～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～")
        if devices.count == 0 {
            return;
        }
        
        //寻找到 扫描到的外接设备 对象
        var hasDevices = self.peripherals
        print("hasDevice===",hasDevices!);
        print("devices===",devices);
        var sendPeriphers : [BLEPeripheralDevice] = [];
        for data in devices {
            for per in hasDevices ?? []{
                print("per.identifier.uuidString==:",per.identifier.uuidString);
                if per.identifier.uuidString == data["identifier"] {
                    let  ble : BLEPeripheralDevice = BLEPeripheralDevice(per, sessionCharacteristicId: self.sessionUUIDString!, configCharacteristicId: self.configUUIDString!)
                    print("筛选设备成功id:",per.identifier.uuidString);
                    sendPeriphers.append(ble)
                }
            }
        }
        
        if sendPeriphers.count == 0{
            if let bleStateChanged = self.bleStateChanged {
                bleStateChanged(BleState.unFound_config_device,"","");
            }
            print("没有筛选到 需要配网的蓝牙设备");
            return;
        }
        self.sendingpPeripherals = sendPeriphers
        
        self.sendingpProvision = [:];
        
        //发起对外接设备的配网连接
        self.connectProcessListning()
        self.bleTransport?.connect(peripherals: sendPeriphers, withOptions: nil)
    }
    
    //蓝牙配网
    private func bleProvisionDevice(_ per : BLEPeripheralDevice) {
        
       // let pop = self.pop
        //security = Security1(proofOfPossession: pop)
        security = Security0()

        if let bleTransport = transport as? BLETransport {
            bleTransport.delegate = self
        }
        bleInitialiseSessionAndConfigure(transport: transport!,
                                      security: security!,per)

    }
    
    
    //蓝牙配网
    func bleInitialiseSessionAndConfigure(transport: Transport,
                                       security: Security, _ per : BLEPeripheralDevice) {
        let newSession = Session(transport: transport,
                                 security: security)
        print("开始蓝牙配网w会话",per.peripheral?.identifier.uuidString);
        newSession.bleInitialize(response: nil,per: per) { error in
            guard error == nil else {
                per.state = BleState.ble_sendSession_fail;
                print("Error in establishing session \(error.debugDescription)")
                return
            }
            per.state = BleState.ble_sendSession_success;
            
            print("通过了 session 数据测试，开始获取 设备信息",per.peripheral?.identifier.uuidString);
            let provision = Provision(session: newSession)
            
            self.sendingpProvision?[(per.peripheral?.identifier.uuidString)!] = provision;
            
            //获取配网 设备信息bleSendCustomCmd
//            provision.bleFetchDeviceInfo (per:per){(state, resaon, error) in
//                print("获取到设备信息:",per.peripheral?.identifier.uuidString);
            //获取完成
                provision.bleConfigureWifi(data:self.configData!,per: per) { status, error in
                    guard error == nil else {
                        per.state = BleState.ble_sendConfigData_fail;
                        print("Error in configuring wifi : \(error.debugDescription)")
                        return
                    }
                    if status == Espressif_Status.success {
                        print("准备发起开始配网指令:",per.peripheral?.identifier.uuidString);
                        per.state = BleState.ble_sendConfigData_success;
                        self.bleApplyConfigurations(provision: provision,per)
                    }else{
                        per.state = BleState.ble_sendConfigData_fail;
                    }
                        
//                }
            
            }
        }
    }
    
    //蓝牙申请开始配网请求
    private func bleApplyConfigurations(provision: Provision, _ per: BLEPeripheralDevice) {
        provision.bleApplyConfigurations(per,completionHandler: { status, error in
            guard error == nil else {
                per.state = BleState.ble_sendConfigRequest_fail;
                self.closePeripherConnect(per)
                return
            }
            per.state = BleState.ble_sendConfigRequest_success;
            print("Configurations applied ! \(status)")
        },
                                      wifiStatusUpdatedHandler: { wifiState, failReason, error in
            DispatchQueue.main.async {
                  //  self.closePeripherConnect(per)
                    if error != nil {
                       // successVC.statusText = "Error in getting wifi state : \(error.debugDescription)"
                    } else if wifiState == Espressif_WifiStationState.connected {
                       // successVC.statusText = "Device has been successfully provisioned!"
                    } else if wifiState == Espressif_WifiStationState.disconnected {
                       // successVC.statusText = "Please check the device indicators for Provisioning status."
                    } else {
                       // successVC.statusText = "Device provisioning failed.\nReason : \(failReason).\nPlease try again"
                    }


            }
        })
    }
    
    
    
    //ap配网
    public func provisionDevice() {
        
        security = Security0()
//        security = Security1(proofOfPossession: pop)
        
        apTransport = SoftAPTransport(baseUrl: self.baseUrl)
        initialiseSessionAndConfigure(transport: apTransport!,
                                      security: security!)
    }
    
    //ap配网
    func initialiseSessionAndConfigure(transport: Transport,
                                       security: Security) {
        let newSession = Session(transport: transport,
                                 security: security)
        let provision = Provision(session: newSession)
        self.apProvision = provision

        newSession.initialize(response: nil) { error in
            guard error == nil else {
                print("Error in establishing session \(error.debugDescription)")
                NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.ble_sendSession_fail]);
                return
            }
            NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.ble_sendSession_success]);
            print("通过了 session 数据测试");

            
            //获取设备信息 ///2020.9.3修改 新的配网方案不需要获取设备信息
//            provision.fetchDeviceInfo { (state, failresion, error) in
                
                //获取设备信息成功
                print("准备ap配网");
                provision.configureWifi(data:self.configData!) { status, error in
                    guard error == nil else {
                        NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.ble_sendConfigData_fail]);
                        print("Error in configuring wifi : \(error.debugDescription)")
                        return
                    }
                                            
                    if status == Espressif_Status.success {
                        NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.ble_sendConfigData_success]);
                        self.applyConfigurations(provision: provision)
                    }else{
                        NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.ble_sendConfigData_fail]);
                    }
                }
//            }
        }
    }
    
    //ap 配网
    private func applyConfigurations(provision: Provision) {
        provision.applyConfigurations(completionHandler: { status, error in
            guard error == nil else {
                NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.ble_sendConfigRequest_fail]);
                return
            }
            NotificationCenter.default.post(name: NSNotification.Name("ApConfigNetworkStateChanged"), object: self, userInfo: ["state":BleState.ble_sendConfigRequest_success]);
            print("Configurations applied ! \(status)")
        },
                                      wifiStatusUpdatedHandler: { wifiState, failReason, error in
            DispatchQueue.main.async {
                    if error != nil {
                       // successVC.statusText = "Error in getting wifi state : \(error.debugDescription)"
                    } else if wifiState == Espressif_WifiStationState.connected {
                       // successVC.statusText = "Device has been successfully provisioned!"
                    } else if wifiState == Espressif_WifiStationState.disconnected {
                       // successVC.statusText = "Please check the device indicators for Provisioning status."
                    } else {
                       // successVC.statusText = "Device provisioning failed.\nReason : \(failReason).\nPlease try again"
                    }


            }
        })
    }
    
    // 转 json 方法
    func getJSONStringFromData(data:Any) -> String {
        
        if (!JSONSerialization.isValidJSONObject(data)) {
            print("无法解析出JSONString")
            return ""
        }
        
        let data : NSData! = try! JSONSerialization.data(withJSONObject: data, options: []) as NSData?
        let JSONString = NSString(data:data as Data,encoding: String.Encoding.utf8.rawValue)
        let str : String = JSONString! as String
        let result : String = str.replacingOccurrences(of: "\\", with: "")
        return result
     }
    
    
    
    //关闭蓝牙连接
    func closePeripherConnect(_ per :BLEPeripheralDevice) {
        if self.transport is BLETransport {
            let trans : BLETransport = self.transport as! BLETransport
            trans.centralManager .cancelPeripheralConnection(per.peripheral!);
        }
    }
    
    
    //中断设备蓝牙配网过程,cmd 3 ： 正常模式，4:蓝牙模式，5:ap模式，4:smart 模式
    func abortDeviceBleConfigProcess(_ cmd : Int ,identifier : String) {
        
        //找到对应的 provision
        var provision : Provision?;
        for (key, value) in self.sendingpProvision ?? [:]{
            if key == identifier {
                provision = value;
            }
        }

        
        //找到对应的外接设备
        var per : BLEPeripheralDevice?
        for p in self.sendingpPeripherals ?? []{
            if p.peripheral?.identifier.uuidString == identifier {
                per = p;
            }
        }
        guard let sendPer = per else{
            return ;
        }
        sendPer.abortConfigProcess = true
        
        
        guard let prov = provision else {
            //prov 不存在，手机断 断开蓝牙连接
            if sendPer.fetchBleConnectedState() {
                print("中断和设备:\(sendPer.peripheral?.name)的连接");
                self.closePeripherConnect(sendPer)
            }
            return;
        }
        prov.configProcessAbort = true
        
        //发送中断指令
//        print("准备发送中断配网指令");
//        prov.bleSendCustomCmd(cmd:cmd,per:sendPer){(state, resaon, error) in
//            if(error != nil){
//                print("发送了中断配网指令失败:",sendPer.peripheral?.identifier.uuidString);
//                return;
//            }
//            print("发送了中断配网指令成功:",sendPer.peripheral?.identifier.uuidString);
//        }
        
    }
    
    
    //中断设备ap配网过程,cmd 3 ： 正常模式，4:蓝牙模式，5:ap模式，6:smart 模式
    func abortDeviceApConfigProcess(_ cmd : Int) {
        
        print("准备发送中断配网指令");
        self.apProvision?.configProcessAbort = true
        self.apProvision?.apSendCustomCmd(cmd:cmd){(state, resaon, error) in
            if(error != nil){
                print("发送了中断配网指令失败:");
                return;
            }
            print("发送了中断配网指令成功:");
        }
        
    }
    
    
    //
    func connectProcessListning(){
        
        print("发送设备连接请求");
        //蓝牙请求定时器
        self.sendDataState = 0;
        
        self.connectTimer?.invalidate()
        self.connectTimer = nil;
        
        self.connectTimer = Timer.scheduledTimer(timeInterval: 20,
        target: self,
        selector: #selector(connectProcessCheck),
        userInfo: nil,
        repeats: false)
    
    }
    
    @objc func connectProcessCheck() {
        print("设备连接结果：");
        if self.sendDataState == 0 {
            
            self.bleTransport?.connect(peripherals: self.sendingpPeripherals, withOptions: nil)
            print("设备连接结果：失败");
//            NotificationCenter.default.post(name: NSNotification.Name("ConfigNetworkStateChanged"), object: self, userInfo: ["identifier":"" ,"state":BleState.ble_connect_device_fail]);
        }
    }
    
    func clearScanedDevices(){
        safeQueue.sync {
            self.scanDevices.removeAll()
        }
    }

}


extension CucoBleManager : BLETransportDelegate {
    
    public func sendNotification(devNames : [Any] , num : Int) {
        
        
//        let title : String = "CUCO"
//        let subtitle : String = "发现新设备"
        let body : String = "Discoverd " + String(num) + " new device,click here to config";
        
        CucoLocalNotification.sendNotificationData(body: body);
    }
    
    
    
    //扫描到设备，并将扫描到的设备 返回回去
    func peripheralsFound(peripherals: [CBPeripheral]) {
        self.safeQueue.sync {
            print("收到几台蓝牙设备:\(peripherals.count)    \(self.scanDevices.count)");
            
            self.peripherals = peripherals
            
            var lists : [String] = [];
            var newScanDevices : [String] = []
            var devices:[Any] = []
            var deviceNames:[String] = []
            for per in peripherals {
                if per.name != nil{
                    //去除重名
                    if !deviceNames.contains(per.name!) {
                        
                        deviceNames.append(per.name!)
                        
                        var device : [String:String] = [:]
                        device["deviceName"] = per.name
                        device["identifier"] = per.identifier.uuidString
                        devices.append(device)
                        
                        //有关推送的逻辑
                        if !self.scanDevices.contains(per.name!){
                            print("推送1：\(per.name!)")
                            print("推送2：\(self.scanDevices)")
                            lists.append(per.name!)
                        }
                        newScanDevices.append(per.name!)
                    }
                    
                }
            }
            
            
            //最多取10个设备
            if devices.count > 10 {
                devices = devices.suffix(10)
            }
//            var smartConfigDevices:[Any] = []
//            let espSmartManager = ESPSmartConfigManager.sharedInstance()
//            smartConfigDevices = espSmartManager.fetchFoundDevices()
//            lists.append(contentsOf: smartConfigDevices)
//
            if lists.count > 0 && self.canNotification {
                print("准备推送消息条数为：\(devices.count)")
                self.sendNotification(devNames: lists, num: devices.count)
            }
            self.scanDevices = newScanDevices;
            
            let devicesStr : String = self.getJSONStringFromData(data: devices)
            if  let scanResult = self.scanResult {
                scanResult(devicesStr)
            }
            
            if let checkScan = self.checkScanResult {
                checkScan(devicesStr);
            }
        }
    }
    
    func peripheralsNotFound(serviceUUID _: UUID?) {
        
    }

    func peripheralConfigured(peripheral _: CBPeripheral) {
      //  bleDeviceConfigured()
    }

    func peripheralNotConfigured(peripheral _: CBPeripheral) {
      //  bleDeviceNotConfigured()
    }
  
    //某个设备断开连接
    func peripheralDisconnected(peripheral: CBPeripheral, error _: Error?) {
        
        //根据设备名称删除
        var i = 0
        var index = 999
        for userItem in self.peripherals ?? [] {
            if userItem.name == peripheral.name {
                index = i
            }
            i += 1
        }
        
        if index < self.peripherals!.count {
            self.peripherals?.remove(at: index)
        }
    }
}
