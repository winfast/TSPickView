//
//  CucoLocalNotification.swift
//  Runner
//
//  Created by houcheng on 2020/4/11.
//  Copyright © 2020 The Chromium Authors. All rights reserved.
//

import UIKit
import UserNotifications

class CucoLocalNotification: NSObject ,UNUserNotificationCenterDelegate {
    
   func registerNotifications() {
        //-- 注册推送
        if #available(iOS 10.0, *) {
             UNUserNotificationCenter.current().delegate = self;
             UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.sound,.badge]) { (accepted, error) in
                if !accepted{
                    print("用户不允许消息通知。")
                }else{
                    print("本地推送注册成功");
                    if error == nil {
                        print("无错误");
                    }
                }
             }
        }else{

         }
    }
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                       willPresent notification: UNNotification,
                       withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void)
    {
        completionHandler([.alert, .sound])
    }
    
    
    @objc static func sendNotificationData(body:String) {
        if #available(iOS 10.0, *) {
//            let content = UNMutableNotificationContent()
//            content.title = ""//title
//            content.subtitle = ""
//            content.body = body
//            content.sound = UNNotificationSound.default()
//            
//            content.userInfo = ["id":"1111111111","name":"123123123123123123"]
//
//            //设置通知触发器，30秒后发送通知
//            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
//
//            //设置请求标识符
//            let requestIdentifier = "com.houcheng.test"
//
//            //设置一个通知请求
//            let request = UNNotificationRequest(identifier: requestIdentifier,
//                                                content: content, trigger: trigger)
//            //将通知请求添加到发送中心
//            UNUserNotificationCenter.current().add(request) { error in
//                if error == nil {
//                    print("添加成功: \(requestIdentifier)")
//                }
//            }
        } else {
            // Fallback on earlier versions
        }
    }
    
}
