//
//  GHSmartActivator.m
//  GHSmartKit
//
//  Created by Qincc on 2021/7/2.
//

#import "GHSmartActivator.h"
#import "Curve25519-prefix.pch"
#import <GHSmartKit/GHSmartKit-Swift.h>
#import "ESPTools.h"
#import "ESP_WifiUtil.h"
#import "GHTcpClientSocket.h"
#import "GHSmartDeviceModel.h"
#import <GHNetworkModule/GHNetwork.h>
#import "GHSmartKitNetworkRequest.h"
#import "GHSmartConstValue.h"
#import <MJExtension/MJExtension.h>
#import "GHSmartKitStringDefine.h"
#import "ESPSmartConfigManager.h"

@interface GHSmartActivator ()

@property (nonatomic, strong) NSTimer *timeOut;
@property (nonatomic, strong) NSMutableArray *devicesId;
@property (nonatomic, copy) NSString *token;
@property (nonatomic, copy) NSString *ssid;
@property (nonatomic, copy) NSString *pwd;

@end

@implementation GHSmartActivator

/// Returns a singleton of the class.
+ (instancetype)sharedInstance {
    static dispatch_once_t onceToken;
    static GHSmartActivator *activator;
    dispatch_once(&onceToken, ^{
        activator = GHSmartActivator.alloc.init;
    });
    return activator;
}

#pragma mark - SSID

+ (NSString *)currentWifiSSID {
    return [ESPTools getCurrentWiFiSsid];
}

+ (NSString *)currentWifiBSSID {
    return [ESPTools getCurrentBSSID];
}

+ (NSString *)getIPAddress4 {
    return [ESP_WifiUtil getIPAddress4];
}

+ (NSString *)getIpAddress6 {
    return [ESP_WifiUtil getIPAddress4];
}

#pragma mark - active gateway

/// Start configuration (Wireless config).
/// @param mode Config mode, EZ or AP.
/// @param ssid Name of route.
/// @param password Password of route.
/// @param token Config Token.
/// @param timeout Timeout, default 100 seconds.
- (void)startConfigWiFi:(GHActivatorMode)mode
                   ssid:(NSString *)ssid
               password:(NSString *)password
                  token:(NSString *)token
                timeout:(NSTimeInterval)timeout {
    [self.devicesId removeAllObjects];
    self.ssid = ssid;
    self.pwd = password;
    self.token = token;
    if (GHActivatorModeEZ == mode) {   //闪连配网模式
         //
        CucoBleManager *manager = [CucoBleManager default];
//        [manager sendApConfigRequest];
        [manager sendApConfigRequest];
    } else if (GHActivatorModeAP == mode) {
        /*分为两种情况
        1:走自己TCP协议
        2:走以前的HTTP接口， 优先使用TCP协议
        */
        [self startAPConfigMode];
        __weak typeof(self) weakSelf = self;
        if (timeout < 100) {
            timeout = 100;
        }
        self.timeOut = [NSTimer scheduledTimerWithTimeInterval:timeout repeats:NO block:^(NSTimer * _Nonnull timer) {
           
            [timer invalidate];
            timer = nil;
            
            [weakSelf.devicesId removeAllObjects];
            //结束轮询
            [NSObject cancelPreviousPerformRequestsWithTarget:weakSelf selector:@selector(getConfigureNetworkDevicesWithToken:) object:weakSelf.token];
            [GHTcpClientSocket.share disConnectTcpService];
            
            //EZ模式停止
            [[ESPSmartConfigManager sharedInstance] endScanDevice];
            
            if ([weakSelf.delegate respondsToSelector:@selector(activator:didReceiveDevice:step:error:)]) {
                NSError *error = [[NSError alloc] initWithDomain:@"time out" code:10001 userInfo:nil];
                [weakSelf.delegate activator:weakSelf didReceiveDevice:nil step:GHActivatorStepTimeOut error:error];
            }
        }];
    }
//    else if (GHActivatorModeBLE == mode) {
//        [GHBLEClient share].delegate = self;
//        [[GHBLEClient share] connectPeripheral:self.peripheral];
//    }
}


- (void)stopConfigWiFi {
    self.delegate = nil;
    [self.devicesId removeAllObjects];
    
    if ([self.timeOut isValid]) {
        [self.timeOut invalidate];
        self.timeOut = nil;
    }
    //断开TCP
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(getConfigureNetworkDevicesWithToken:) object:self.token];
    [GHTcpClientSocket.share disConnectTcpService];
    
    //EZ模式停止
    [[ESPSmartConfigManager sharedInstance] endScanDevice];
}

#pragma mark - private

- (void)startAPConfigMode {
    if (self.token.length == 0) {
        return;
    }
    
    NSDictionary *tokenDict = @{
                               @"token":self.token,
                               @"ssid":self.ssid,
                               @"pwd":self.pwd,
                               @"url":GHNetworkConfigure.share.generalServer
    };
    __weak typeof(self) weakSelf = self;
    GHTcpClientSocket *socket = GHTcpClientSocket.share;
    [socket disConnectTcpService];
    socket.version = 0x01;
    socket.userData = nil; //配网模式
    socket.connectedSuccess = ^(GHTcpClientSocket *socket) {
        //TCP连接成功  发送配网数据
        [socket postDataWithOpCode:GHOpCodeConfigwiFiInfo security:NO status:tokenDict];
    };
    
    socket.connectedFailed = ^(GHTcpClientSocket *socket) {
        //TCP断开链接
        [socket disConnectTcpService];
        
        //如果超时，仍然没有连接上TCP
        if (![weakSelf.timeOut isValid]) {
            return;
        }
        
        if (weakSelf.devicesId.count == 0) {
            [weakSelf startAPConfigMode];
        }
    };
    
    socket.connectedDisConnect = ^(GHTcpClientSocket *socket) {
        //TCP断开链接 连接成功的断开不用任何处理
    };
    
    socket.recieveTcpSocket = ^(GHTcpClientSocket *socket, NSDictionary *smartDeviceData) {
        //TCP收到数据
        if ([smartDeviceData[@"opCode"] integerValue] == GHOpCodeConfigwiFiInfoRecieve) {
            NSLog(@"smartDeviceData = %@", smartDeviceData);
            NSString *deviceId = smartDeviceData[@"properties"][@"device_id"];
            if (![weakSelf.devicesId containsObject:deviceId]) {
                [weakSelf.devicesId addObject:deviceId];
            }
            
            if ([weakSelf.delegate respondsToSelector:@selector(activator:didReceiveDevice:step:error:)]) {
                GHSmartDeviceModel *deviceModel = GHSmartDeviceModel.alloc.init;
                deviceModel.deviceId = deviceId;
                [weakSelf.delegate activator:weakSelf didReceiveDevice:@[deviceModel] step:GHActivatorStepFound error:nil];
            }
            
            //关闭TCP
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [GHTcpClientSocket.share disConnectTcpService];
            });
            
            //发送轮训
            [weakSelf getConfigureNetworkDevicesWithToken:weakSelf.token];
            
        } else if ([smartDeviceData[@"opCode"] integerValue] == GHOpCodeConfigWiFiError) {
            [socket disConnectTcpService];
            //进入配网失败的UI
            NSError *error = [[NSError alloc] initWithDomain:@"wifi error" code:10000 userInfo:nil];
            [weakSelf.delegate activator:weakSelf didReceiveDevice:nil step:GHActivatorStepTimeOut error:error];
        } else {
            
        }
    };
    
    NSString *ipAddress = [GHSmartActivator getIPAddress4];
    NSMutableArray *ip = [ipAddress componentsSeparatedByString:@"."].mutableCopy;
    [ip replaceObjectAtIndex:3 withObject:@(1)];
    [socket connectTCPService:[ip componentsJoinedByString:@"."] port:10086];
}

- (NSString *)getConfigureNetworkDevicesWithToken:(NSString *)token {
    GHSmartKitNetworkRequest *request = [GHSmartKitNetworkRequest.alloc initWithSmartKitRequestType:GHSmartKitRequestTypeConfigureNetworkDevicesToken];
    request.methodPath = [NSString stringWithFormat:GHSmartKit_Configure_Network_Devices_Token, self.token];
    return [GHNetworkModule.share sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        //进入轮询
        NSLog(@"轮询中，请稍后。。。");
        if (response.status == GHNetworkResponseStatusSuccess) {
            NSArray<GHSmartDeviceModel *> *array = [GHSmartDeviceModel mj_objectArrayWithKeyValuesArray:response.data];
            if ([[array valueForKey:@"deviceId"] containsObject:self.devicesId.firstObject]) {
                GHSmartDeviceModel *deviceModel = array.firstObject;
                if ([deviceModel online].boolValue == YES) {
                    if ([self.delegate respondsToSelector:@selector(activator:didReceiveDevice:step:error:)]) {
                        [self.delegate activator:self didReceiveDevice:@[deviceModel] step:GHActivatorStepIntialized error:nil];
                    }
                } else {
                    if ([self.delegate respondsToSelector:@selector(activator:didReceiveDevice:step:error:)]) {
                        [self.delegate activator:self didReceiveDevice:@[deviceModel] step:GHActivatorStepRegisted error:nil];
                    }
                    if (self.timeOut) {
                        [self performSelector:@selector(getConfigureNetworkDevicesWithToken:) withObject:self.token afterDelay:1];
                    }
                }
            } else {
                if (self.timeOut) {
                    [self performSelector:@selector(getConfigureNetworkDevicesWithToken:) withObject:self.token afterDelay:1];
                }
            }
        } else {
            if (self.timeOut) {
                [self performSelector:@selector(getConfigureNetworkDevicesWithToken:) withObject:self.token afterDelay:1];
            }
        }
    }];
}

- (void)startEZConifg {
    NSDictionary *tokenDict = @{
                               @"token":self.token,
                               @"ssid":self.ssid,
                               @"pwd":self.pwd,
                               @"url":GHNetworkConfigure.share.generalServer
    };
    
    ESPSmartConfigManager *manage = [ESPSmartConfigManager sharedInstance];
    [manage startScanDeviceWithSSID:self.ssid password:self.pwd withToken:tokenDict];
    __weak typeof(self) weakSelf = self;
    manage.scanedDeviceBlock = ^(NSArray * _Nonnull scanedDeviceIDs) {
        [weakSelf.devicesId addObjectsFromArray:scanedDeviceIDs];
        if ([weakSelf.delegate respondsToSelector:@selector(activator:didReceiveDevice:step:error:)]) {
            GHSmartDeviceModel *deviceModel = GHSmartDeviceModel.alloc.init;
            deviceModel.deviceId = scanedDeviceIDs.firstObject;
            [weakSelf.delegate activator:weakSelf didReceiveDevice:@[deviceModel] step:GHActivatorStepFound error:nil];
        }
        
        //开始进入轮询
        [weakSelf getConfigureNetworkDevicesWithToken:weakSelf.token];
    };
}

- (NSMutableArray *)devicesId {
    if (!_devicesId) {
        _devicesId = NSMutableArray.alloc.init;
    }
    return _devicesId;
}

@end
