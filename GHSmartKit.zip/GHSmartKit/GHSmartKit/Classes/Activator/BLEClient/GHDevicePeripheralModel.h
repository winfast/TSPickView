//
//  GHDevicePeripheralModel.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/5.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface GHDevicePeripheralModel : NSObject

@property (nonatomic, copy) NSString *devicePid;
@property (nonatomic, strong) CBPeripheral * peripheral;
//@property (nonatomic, strong) GHDeviceTypeIconModel * deviceTypeModel;

@end

