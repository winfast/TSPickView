//
//  GHBLEClient.m
//  GHome
//
//  Created by Qincc on 2021/2/25.
//

#import "GHBLEClient.h"
#import <MJExtension/MJExtension.h>


#define Discover_ServiceUUID  		@"FAB0"
#define DeviceID_CharacteristicUUID @"FAB1"

@interface GHBLEClient ()<CBCentralManagerDelegate, CBPeripheralDelegate, CBPeripheralDelegate>
// 中心管理者(管理设备的扫描和连接)
@property (nonatomic, strong) CBCentralManager *centralManager;
///已经连接上的设备
@property (nonatomic, strong) CBPeripheral *connectedPeripheral;
// 扫描的设备
@property (nonatomic, strong) NSMutableArray *peripheralsArray;
// 外设状态
@property (nonatomic, assign) CBManagerState peripheralState;
//app给ble写数据锁
@property(strong, nonatomic) NSCondition * writeCondition;
//app给设备发送数据的特征值
@property (nonatomic, strong) CBCharacteristic  *deviceID_Characteristic;

@property (nonatomic, assign) BOOL vcIsScaning; //界面正在进行蓝牙扫描

//@property (nonatomic, strong) CBUUID 			*notifyUUID;
//@property (nonatomic, strong) CBCharacteristic  *notifyChar;
/// 读写队列
//@property(strong, nonatomic)NSOperationQueue *requestQueue;
//@property(strong, nonatomic)NSOperationQueue *callbackQueue;

@end

@implementation GHBLEClient

#pragma mark 单例初始化
/// 单例构造方法
+ (instancetype)share {
	static GHBLEClient *share = nil;
	static dispatch_once_t oneToken;
	dispatch_once(&oneToken, ^{
		share = [[GHBLEClient alloc] init];
	});
	return share;
}

- (instancetype)init {
	if (self = [super init]) {
		self.centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
	}
	return self;
}
#pragma mark CBCentralManagerDelegate
// 状态更新时调用
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
	switch (central.state) {
		case CBManagerStateUnknown:{
			NSLog(@"未知状态");
			self.peripheralState = central.state;
		}
			break;
		case CBManagerStateResetting:
		{
			NSLog(@"重置状态");
			self.peripheralState = central.state;
		}
			break;
		case CBManagerStateUnsupported:
		{
			NSLog(@"不支持的状态");
			self.peripheralState = central.state;
		}
			break;
		case CBManagerStateUnauthorized:
		{
			NSLog(@"未授权的状态");
			self.peripheralState = central.state;
		}
			break;
		case CBManagerStatePoweredOff:
		{
			NSLog(@"关闭状态");
			self.peripheralState = central.state;
		}
			break;
		case CBManagerStatePoweredOn:
		{
			NSLog(@"开启状态－可用状态");
			self.peripheralState = central.state;
			CBUUID* cbUUID = nil;
			cbUUID = [CBUUID UUIDWithString:Discover_ServiceUUID];
			if (self.vcIsScaning) {
//				[self.centralManager scanForPeripheralsWithServices:@[cbUUID] options:nil];
				[self.centralManager scanForPeripheralsWithServices:nil options:nil];
			}
		}
			break;
		default:
			break;
	}
}
#pragma mark 开始扫描设备
/// 开始扫描
- (void)startScanBlutooth{
	if (self.peripheralsArray.count != 0) {
		[self.peripheralsArray removeAllObjects];
	}
	CBUUID* cbUUID = nil;
	cbUUID = [CBUUID UUIDWithString:Discover_ServiceUUID];
//	[self.centralManager scanForPeripheralsWithServices:@[cbUUID]  options:nil];
	[self.centralManager scanForPeripheralsWithServices:nil options:nil];
	self.vcIsScaning = YES;
}

#pragma mark 停止扫描
///  停止扫描
- (void)stopScan {
	if ([self.centralManager isScanning]) {
		[self.centralManager stopScan];
	}
	self.vcIsScaning = NO;
}

#pragma mark 连接设备

//连接设备
- (void)connectPeripheral:(CBPeripheral *)peripheral {
	[self.centralManager stopScan];
	if ([self.connectedPeripheral isEqual: peripheral] || !peripheral) {
		return;
	}
    
	if (self.connectedPeripheral.state == CBPeripheralStateConnected) {
		[self.centralManager cancelPeripheralConnection:self.connectedPeripheral];
	}
    
	if (peripheral.state == CBPeripheralStateConnected) {
		[self.centralManager cancelPeripheralConnection:peripheral];
	}
    
	[self.centralManager connectPeripheral:peripheral options:nil];
}

#pragma mark 断开连接

//断开连接
- (void)disconnectPeripheral:(CBPeripheral *)peripheral {
	if (peripheral.state == CBPeripheralStateConnected) {
		[self.centralManager cancelPeripheralConnection:peripheral];
	}
}

#pragma mark - CBCentralManagerDelegate
/**
 扫描到设备
 @param central 中心管理者
 @param peripheral 扫描到的设备
 @param advertisementData 广告信息
 @param RSSI 信号强度
 */
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI {
	if (![advertisementData[CBAdvertisementDataLocalNameKey] containsString:@"cuco-"] || [RSSI intValue] <= -80) { // 因为peripheral.name在iOS端有缓存，因此使用kCBAdvDataLocalName
		return;
	}

	NSData *pidData = advertisementData[CBAdvertisementDataManufacturerDataKey];
	if (!pidData) return;
	NSString *pidStr = [[NSString alloc] initWithData:pidData encoding:NSUTF8StringEncoding];
	if (![self.peripheralsArray containsObject:peripheral]) {
		[self.peripheralsArray addObject:peripheral];
		GHDevicePeripheralModel * dpModel = [GHDevicePeripheralModel new];
		dpModel.devicePid = pidStr;
		dpModel.peripheral = peripheral;
		if ([self.delegate respondsToSelector:@selector(didDiscoverPeripheralwithPid:)]) {
			[self.delegate didDiscoverPeripheralwithPid:dpModel];
		}
	}
}

- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
	self.connectedPeripheral = peripheral;
	[peripheral setDelegate:self];
	[peripheral discoverServices:nil];
}

//连接外设失败
-(void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
	self.connectedPeripheral = nil;
	if ([self.delegate respondsToSelector:@selector(centralManager:didFailToConnectPeripheral:error:)]) {
		[self.delegate centralManager:central didFailToConnectPeripheral:peripheral error:error];
	}
}

-(void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
	self.connectedPeripheral = nil;
}

#pragma mark - CBPeripheralDelegate
//扫描到服务
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
	if (error) {
		NSLog(@"扫描外设服务出错：%@-> %@", peripheral.name, [error localizedDescription]);
		return;
	}
	
	for (CBService *service in peripheral.services) {
		[peripheral discoverCharacteristics:nil forService:service]; //订阅服务下面所有的特征
	}
    
	if ([self.delegate respondsToSelector:@selector(didConnectPeripheral:)]) {
		[self.delegate didConnectPeripheral:peripheral];
	}
}

//扫描到特征
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error {
	if (error) {
		NSLog(@"扫描外设的特征失败！%@->%@-> %@",peripheral.name,service.UUID, [error localizedDescription]);
		return;
	}
    
	//获取Characteristic的值
	for (CBCharacteristic *characteristic in service.characteristics){
		//这里外设需要订阅特征的通知，否则无法收到外设发送过来的数据
		[peripheral setNotifyValue:YES forCharacteristic:characteristic];
		if ([characteristic.UUID.UUIDString isEqualToString:DeviceID_CharacteristicUUID]) {
			self.deviceID_Characteristic = characteristic;
		}
	}
}

//扫描到具体的值->通讯主要的获取数据的方法
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(nullable NSError *)error {
	if (error) {
		NSLog(@"扫描外设的特征失败！%@-> %@",peripheral.name, [error localizedDescription]);
		return;
	}
    
	if ([characteristic.UUID.UUIDString isEqualToString:DeviceID_CharacteristicUUID]) {
		NSData *data = characteristic.value;
		if ([self.delegate respondsToSelector:@selector(peripheral:didUpdateValueForCharacteristicOfDeviceID:)]) {
            NSString * str  =[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSDictionary *dic = [str mj_JSONObject];
            NSString *deviceIDstr = [dic objectForKey:@"device_id"];
            GHSmartDeviceModel *deviceModel = GHSmartDeviceModel.alloc.init;
            deviceModel.deviceId = deviceIDstr;
			[self.delegate peripheral:peripheral didUpdateValueForCharacteristicOfDeviceID:deviceModel];
		}
	}
}

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
	[self.writeCondition lock];
	[self.writeCondition signal];
	[self.writeCondition unlock];
	if (self.delegate && [self.delegate respondsToSelector:@selector(peripheral:didWriteValueForCharacteristic:error:)]) {
		[self.delegate peripheral:peripheral didWriteValueForCharacteristic:characteristic];
	}
}

#pragma mark public method
//发送配网配置信息
-(void)sendConfigdataToPeripheral:(CBPeripheral *)peripheral withData:(NSData *)data{
	if (self.deviceID_Characteristic) {
		[self gattWrite:data withCharacteristic:self.deviceID_Characteristic];
	}
}

#pragma mark private method
- (void)gattWrite:(NSData *)data withCharacteristic:(CBCharacteristic *)characteristic {
	[self.writeCondition lock];
	if (!self.connectedPeripheral) {
		[self.writeCondition unlock];
		return;
	}
	[self.connectedPeripheral writeValue:data forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
	[self.writeCondition wait];
	[self.writeCondition unlock];
	return;
}

#pragma mark lazy load

-(NSMutableArray*)peripheralsArray{
	if (!_peripheralsArray) {
		_peripheralsArray = [[NSMutableArray alloc] init];
	}
	return _peripheralsArray;
}

@end
