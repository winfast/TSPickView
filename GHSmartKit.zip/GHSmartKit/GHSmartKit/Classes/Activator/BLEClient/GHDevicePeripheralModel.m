//
//  GHDevicePeripheralModel.m
//  GHSmartKit
//
//  Created by Qincc on 2021/7/5.
//

#import "GHDevicePeripheralModel.h"

@implementation GHDevicePeripheralModel

@end
