//
//  GHSmartActivator.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/2.
//

#import <Foundation/Foundation.h>
#import "GHSmartConstValue.h"
#import "GHSmartDeviceModel.h"

@class GHSmartActivator;

@protocol GHSmartActivatorDelegate <NSObject>

@optional
/// Callback for distribution status update, wifi single product, zigbee gateway, zigbee sub device.
/// @param activator instance
/// @param devicesId deviceId
/// @param error error
- (void)activator:(GHSmartActivator *)activator didReceiveDevice:(NSArray<GHSmartDeviceModel *> *)devicesId error:(NSError *)error;



/// Callback for distribution status update, wifi single product, zigbee gateway, zigbee sub device.
/// @param activator instance
/// @param devicesId devicesId
/// @param step activator step
/// @param error error
- (void)activator:(GHSmartActivator *)activator didReceiveDevice:(NSArray<GHSmartDeviceModel *> *)devicesId step:(GHActivatorStep)step error:(NSError *)error;


@end

@interface GHSmartActivator : NSObject

/// Returns a singleton of the class.
+ (instancetype)sharedInstance;

#pragma mark - SSID

/// Get the SSID of the current Wi-Fi.
///
/// Starting with iOS 12, calls to this function will return nil by default, and will only return the correct value if "Access WiFi Information" is enabled in the Xcode project. This function needs to be activated in the App IDs on the developer page in order to use it.
/// Starting with iOS 13, at least one of the following three conditions must also be met.
///   - An app that has been granted Location Services permissions.
///   - A VPN application that is currently enabled.
///   - Use of NEHotspotConfiguration (only Wi-Fi networks configured through the app are supported).
///
/// @see https://developer.apple.com/videos/play/wwdc2019/713/
///
/// @return Wi-Fi SSID
+ (NSString *)currentWifiSSID;

/// Get the BSSID of the current Wi-Fi.
/// @see TuyaSmartActivator::currentWifiSSID.
/// @return Wi-Fi BSSID
+ (NSString *)currentWifiBSSID;

///// Get the SSID of the current Wi-Fi asynchronously.
///// @see TuyaSmartActivator::currentWifiSSID
///// @param success Called when the task finishes successfully. TYSuccessString will be returned.
///// @param failure Called when the task is interrupted by an error.
//+ (void)getSSID:(TYSuccessString)success
//        failure:(TYFailureError)failure;
//
///// Asynchronously get the BSSID of the current Wi-Fi.
///// @param success Called when the task finishes successfully. TYSuccessString will be returned.
///// @param failure Called when the task is interrupted by an error.
//+ (void)getBSSID:(TYSuccessString)success
//         failure:(TYFailureError)failure;

/**
 * get local ip address by IPv4
 *
 * @return local ip address by IPv4(or nil when en0/ipv4 unaccessible)
 */
+ (NSString *)getIPAddress4;

/**
 * get local ip address by IPv6
 *
 * @return local ip address by IPv6(or nil when en0/ipv6 unaccessible)
 */
+ (NSString *)getIpAddress6;

#pragma mark - Delegate

@property (nonatomic, weak) id<GHSmartActivatorDelegate> delegate;

#pragma mark - active gateway

/// Start configuration (Wireless config).
/// @param mode Config mode, EZ or AP.
/// @param ssid Name of route.
/// @param password Password of route.
/// @param token Config Token.
/// @param timeout Timeout, default 100 seconds.
- (void)startConfigWiFi:(GHActivatorMode)mode
                   ssid:(NSString *)ssid
               password:(NSString *)password
                  token:(NSString *)token
                timeout:(NSTimeInterval)timeout;

///// Start configuration (Wired config).
///// @param token Token
///// @param timeout Timeout, default 100 seconds.
//- (void)startConfigWiFiWithToken:(NSString *)token
//                         timeout:(NSTimeInterval)timeout;
//
///// Start configuring the network to activate only one category of devices (Wired config).
///// @param token Config Token.
///// @param productId ProductId of device.
///// @param timeout Timeout, default 100 seconds.
//- (void)startConfigWiFiWithToken:(NSString *)token
//                       productId:(NSString *)productId
//                         timeout:(NSTimeInterval)timeout;
//
///// Start EZ mode multi-device configuration network
///// @param ssid Name of route.
///// @param password Password of route.
///// @param token Config Token.
///// @param timeout Timeout, default 100 seconds.
//- (void)startEZMultiConfigWiFiWithSsid:(NSString *)ssid
//                              password:(NSString *)password
//                                 token:(NSString *)token
//                               timeout:(NSTimeInterval)timeout;

/// Stop configuring the network.
- (void)stopConfigWiFi;

#pragma mark - active sub device

///// Activate sub-devices e.g. zigbee, Wi-Fi sub-devices.
///// @param gwId     Gateway Id
///// @param timeout  Timeout, default 100 seconds
//- (void)activeSubDeviceWithGwId:(NSString *)gwId timeout:(NSTimeInterval)timeout;
//
///// Stop activate sub device with gateway ID.
///// @param gwId Gateway Id
//- (void)stopActiveSubDeviceWithGwId:(NSString *)gwId;

@end
