//
//  GHSmartHomeKitActivator.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/2.
// Success:(TYSuccessString)success failure:(TYFailureError)failure

#import <Foundation/Foundation.h>


@interface GHSmartHomeKitActivator : NSObject

@end


@interface GHSmartHomeKitActivator (Home)

/// Returns the pairing token for Home.
/// @param homeID The home ID.
/// @param complete Called when the task is finished. The token is returned.
- (NSString *)getTokenWithHomeID:(NSString *)homeID
                        complete:(void(^)(id data, NSError *error))complete;


@end
