//
//  GHSmartHomeKitActivator.m
//  GHSmartKit
//
//  Created by Qincc on 2021/7/2.
//

#import "GHSmartHomeKitActivator.h"
#import "GHSmartKitNetworkRequest.h"
#import "GHSmartConstValue.h"
#import <MJExtension/MJExtension.h>
#import "GHSmartKitStringDefine.h"

@implementation GHSmartHomeKitActivator

@end


@implementation GHSmartHomeKitActivator (Home)

- (NSString *)getTokenWithHomeID:(NSString *)homeID
                        complete:(void(^)(id data, NSError *error))complete {
    
    GHSmartKitNetworkRequest *request = [GHSmartKitNetworkRequest.alloc initWithSmartKitRequestType:GHSmartKitRequestTypeConfigureNetworkTokenHomeId];
    request.methodPath = [NSString stringWithFormat:GHSmartKit_Configure_Network_Token_HomeId];

    return [GHNetworkModule.share sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        if (response.status == GHNetworkResponseStatusSuccess) {
            !complete ?: complete(response.data, nil);
        } else {
            !complete ?: complete(nil, response.error);
        }
    }];
}



@end
