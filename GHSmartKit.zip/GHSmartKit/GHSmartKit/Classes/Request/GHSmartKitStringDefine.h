//
//  GHSmartKitStringDefine.h
//  GHSmartKit
//
//  Created by Qincc on 2021/7/2.
//

#import <Foundation/Foundation.h>


extern NSString *const GHSmartKit_Home_List;

extern NSString *const GHSmartKit_Home_Create;

extern NSString *const GHSmartKit_Home_Info;

extern NSString *const GHSmartKit_Configure_Network_Category;

/// 配网公共数据
extern NSString *const GHSmartKit_Configure_Network_Common;

/// 获取最近配网成功的设备列表
extern NSString *const GHSmartKit_Configure_Network_Devices_Token;

/// 配网引导
extern NSString *const GHSmartKit_Configure_Network_Guide;

/// 设备test
extern NSString *const GHSmartKit_Configure_Network_Registration_Token_Crc;

/// 设备测试
extern NSString *const GHSmartKit_Configure_Network_Test;

/// 获取配网token
extern NSString *const GHSmartKit_Configure_Network_Token_HomeId;

/// 查询房间详情
extern NSString *const GHSmartKit_Room_HomeId_RoomId_Info;

/// 查询房间详情
extern NSString *const GHSmartKit_Room_HomeId_RoomId_Remove;

/// 查询房间详情
extern NSString *const GHSmartKit_Room_Add;

/// 查询房间详情
extern NSString *const GHSmartKit_Room_Update;

/// 房间添加设备
extern NSString *const GHSmartKit_Device_HomeId_RoomId_DeviceId_Add;

/// 设备详情
extern NSString *const GHSmartKit_Device_Detial_DeviceId;
