//
//  GHSmartKitNetworkRequest.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/23.
//

#import <GHNetworkModule/GHNetwork.h>
#import "GHSmartConstValue.h"

//基于字典的请求方式
@interface GHSmartKitNetworkRequest : GHNetworkRequest

- (instancetype)initWithSmartKitRequestType:(GHSmartKitRequestType)reqeustType;

@end


//基于模型的请求方式, 其它的请求必须继承这个类
@interface GHSmartKitBaseReqeust : GHNetworkRequest

@end

#pragma mark - Message
/// Message center message list request model.
@interface GHSmartMessageListRequestModel : GHSmartKitBaseReqeust

/// Message type.
@property (nonatomic) GHMessageType msgType;

/// Limit count.
@property (nonatomic) NSInteger limit;

/// Total number of messages requested
@property (nonatomic) NSInteger offset;

@end


/// Message center message detail list request model.
@interface GHSmartMessageDetailListRequestModel : GHSmartKitBaseReqeust

/// Message type (Currently only supported TYMessageTypeAlarm).
@property (nonatomic, assign) GHMessageType msgType;

/// Limit count.
@property (nonatomic, assign) NSInteger limit;

/// Total number of messages requested.
@property (nonatomic, assign) NSInteger offset;

/// Message device ID.
@property (nonatomic, copy) NSString *msgSrcId;

@end

@interface GHSmartMessageListDeleteRequestModel : GHSmartKitBaseReqeust
/// Message type.
@property (nonatomic, assign) GHMessageType msgType;

/// Message ID.
@property (nonatomic, copy) NSArray<NSString *> *msgIds;

/// Message device ID.
@property (nonatomic, copy) NSArray<NSString *> *msgSrcIds;

@end

@interface GHSmartMessageListReadRequestModel : GHSmartKitBaseReqeust

/// Message type (Currently only supported TYMessageTypeAlarm).
@property (nonatomic, assign) GHMessageType msgType;

/// Message ID.
@property (nonatomic, copy) NSArray<NSString *> *msgIds;

@end

#pragma mark - setting
/// Device Do Not Disturb request model.
@interface GHSmartMessageSettingDNDRequestModel : GHSmartKitBaseReqeust

/// Start time.
@property (nonatomic, copy) NSString *startTime;

/// End time.
@property (nonatomic, copy) NSString *endTime;

/// The device ID list.
@property (nonatomic, copy) NSArray<NSString *> *devIDs;

/// Repeat days per week.
///
/// 0 means close that day, 1 means open on the day. @"0000111" means Friday to Sunday open.
///
@property (nonatomic, copy) NSString *loops;

/// Do all devices support DND.
///
/// 'devIDs' is not required when 'isAllDevIDs' is Ture.
@property (nonatomic, assign) BOOL isAllDevIDs;

@end

#pragma mark - Home

@interface GHSmartHomeAddMemberRequestModel : GHSmartKitBaseReqeust

/// Nicknames for invitees.
@property (nonatomic, copy) NSString *name;

/// Invited accounts.
@property (nonatomic, copy) NSString *account;

/// Invitee account corresponding to the country code.
@property (nonatomic, copy) NSString *countryCode;

/// Member role, please set the correct role type you want to set.
@property (nonatomic, assign) GHHomeRoleType role;

/// The avatar set for the invitee, if set to nil, the invitee's personal avatar will be used.
@property (nonatomic, strong) UIImage *headPic;

/// Whether the invitee needs to agree to accept the invitation. YES - the invited account automatically accepts the family invitation without the invitee's confirmation; NO - the invitee's consent is required to join the family.
@property (nonatomic, assign) BOOL autoAccept;

@end
