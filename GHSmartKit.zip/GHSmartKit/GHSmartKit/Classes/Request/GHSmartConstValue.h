//
//  GHSmartConstString.m
//  GHSmartKit
//
//  Created by Qincc on 2021/6/23.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
    GHSmartKitRequestTypeHomeList,
    GHSmartKitRequestTypeHomeCreate,
    GHSmartKitRequestTypeHomeDetail,
    GHSmartKitRequestTypeUpdateHome,
    GHSmartKitRequestTypeRemoveHome,
    
    //设备配网
    GHSmartKitRequestTypeConfigureNetworkCategory,   //获取配网设备类别
    GHSmartKitRequestTypeConfigureNetworkCommon,    //配网公共数据
    GHSmartKitRequestTypeConfigureNetworkDevicesToken,//获取最近配网成功的设备列表
    GHSmartKitRequestTypeConfigureNetworkGuide,         //配网引导
    GHSmartKitRequestTypeConfigureNetworkRegistrationTokenCrc,//设备激活
    GHSmartKitRequestTypeConfigureNetworkTest,          //设备测试
    GHSmartKitRequestTypeConfigureNetworkTokenHomeId,   //获取配网token
    
    //房间管理
    GHSmartKitRequestTypeRoomInfo,
    GHSmartKitRequestTypeRoomRemove,
    GHSmartKitRequestTypeRoomAdd,
    GHSmartKitRequestTypeRoomUpdate,
    //设备管理
    GHSmartKitRequestTypeDeviceAdd,
    GHSmartKitRequestTypeDeviceDetail,
    GHSmartKitRequestTypeDeviceRemove,
    GHSmartKitRequestTypeDeviceUpdateName
    
} GHSmartKitRequestType;


typedef enum : NSInteger {
    GHHomeRoleType_UnKnow = -999,
    GHHomeRoleTYpe_Custom = -1,
    GHHomeRoleType_Member = 0,
    GHHomeRoleType_Admin,
    GHHomeRoleType_Owner
} GHHomeRoleType;


typedef enum : NSUInteger {
    GHomeStatusPending,
    GHomeStatusAccept,
    GHomeStatusReject,
} GHomeStatus;

typedef enum : NSUInteger {
    GHMessageTypeAlarm = 1,
    GHMessageTypeFamily,
    GHMessageTypeNotice,
} GHMessageType;

typedef enum : NSUInteger {
    GHActivatorModeEZ = 1,  ///  smart config mode
    GHActivatorModeAP = 2,  /// access point mode
    GHActivatorModeBLE = 3, /// 蓝牙配网
    GHActivatorModeQRCode,  ///< QR Code mode  //目前没有
    GHActivatorModeWired,   ///< wired mode   //目前没有
} GHActivatorMode;

typedef enum : NSUInteger {
    GHActivatorStepFound = 1,///< device found
    GHActivatorStepRegisted = 2,///< device registered
    GHActivatorStepIntialized = 3,///< device initialized
    GHActivatorStepTimeOut = 4, ///< device config timeout
} GHActivatorStep;
