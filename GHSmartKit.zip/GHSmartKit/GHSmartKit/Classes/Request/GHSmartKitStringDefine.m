//
//  GHSmartKitStringDefine.m
//  GHSmartKit
//
//  Created by Qincc on 2021/7/2.
//

#import "GHSmartKitStringDefine.h"

/// 家庭列表
NSString *const GHSmartKit_Home_List = @"/home/list";

/// 添加家庭
NSString *const GHSmartKit_Home_Create = @"/home/create";

/// 家庭详情
NSString *const GHSmartKit_Home_Info = @"/home/%@/info";

/*
 设备配网
 */
/// 获取配网设备类别
NSString *const GHSmartKit_Configure_Network_Category = @"/configure/network/category";

/// 配网公共数据
NSString *const GHSmartKit_Configure_Network_Common = @"/configure/network/common";

/// 获取最近配网成功的设备列表
NSString *const GHSmartKit_Configure_Network_Devices_Token = @"/configure/network/devices/%@";

/// 配网引导
NSString *const GHSmartKit_Configure_Network_Guide = @"/configure/network/guide";

/// 设备test
NSString *const GHSmartKit_Configure_Network_Registration_Token_Crc = @"/configure/network/registration/%@/%@";

/// 设备测试
NSString *const GHSmartKit_Configure_Network_Test = @"/configure/network/test";

/// 获取配网token
NSString *const GHSmartKit_Configure_Network_Token_HomeId = @"/configure/network/token/%@";


#pragma mark - Room Controller
/// 查询房间详情
NSString *const GHSmartKit_Room_HomeId_RoomId_Info = @"/room/%@/%@/info";

/// 查询房间详情
NSString *const GHSmartKit_Room_HomeId_RoomId_Remove = @"/room/%@/%@/remove";

/// 查询房间详情
NSString *const GHSmartKit_Room_Add = @"/room/add";

/// 查询房间详情
NSString *const GHSmartKit_Room_Update = @"/room/update";

/// 房间添加设备
NSString *const GHSmartKit_Device_HomeId_RoomId_DeviceId_Add = @"/device/%@/%@/%@/add";

#pragma mark - 设备管理
/// 设备详情
NSString *const GHSmartKit_Device_Detial_DeviceId = @"/device/detail/%@";

///// 设备详情
//NSString *const GHSmartKit_Device_Detial_DeviceId = @"/device/detail/%@";
//
///// 设备详情
//NSString *const GHSmartKit_Device_Detial_DeviceId = @"/device/detail/%@";
