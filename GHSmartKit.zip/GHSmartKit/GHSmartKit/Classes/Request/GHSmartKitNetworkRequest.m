//
//  GHSmartKitNetworkRequest.m
//  GHSmartKit
//
//  Created by Qincc on 2021/6/23.
//

#import "GHSmartKitNetworkRequest.h"
#import <MJExtension/MJExtension.h>
#import "GHSmartUserManagerKit.h"
#import "GHSmartKitStringDefine.h"

@implementation GHSmartKitNetworkRequest

- (instancetype)initWithSmartKitRequestType:(GHSmartKitRequestType)reqeustType {
    if (self = [super init]) {
        if (GHSmartUserManagerKit.share.userName) {
            self.baseURL = GHSmartUserManagerKit.share.userName;
        }
        self.requestMethod = GHNetworkRequestMethodGET;
        self.contenType = GHNetworkContenTypeJSON;
        self.serializerType = GHNetworkSerializerTypeJSON;
        [self configRequestParam:reqeustType];
    }
    return self;
}

/*
 GHSmartKitRequestTypeConfigureNetworkCategory,   //获取配网设备类别
 GHSmartKitRequestTypeConfigureNetworkCommon,    //配网公共数据
 GHSmartKitRequestTypeConfigureNetworkDevicesToken,//获取最近配网成功的设备列表
 GHSmartKitRequestTypeConfigureNetworkGuide,         //配网引导
 GHSmartKitRequestTypeConfigureNetworkRegistrationTokenCrc,//设备激活
 GHSmartKitRequestTypeConfigureNetworkTest,          //设备测试
 GHSmartKitRequestTypeConfigureNetworkTokenHomeId    //获取配网token
 */

- (void)configRequestParam:(GHSmartKitRequestType)reqeustType {
    switch (reqeustType) {
        case GHSmartKitRequestTypeHomeList:
            self.methodPath = GHSmartKit_Home_List;
            break;
        case GHSmartKitRequestTypeHomeCreate:
            self.methodPath = GHSmartKit_Home_Create;
            self.requestMethod = GHNetworkRequestMethodPOST;
            self.contenType = GHNetworkContenTypeJSON;
            self.serializerType = GHNetworkSerializerTypeJSON;
            break;
        case GHSmartKitRequestTypeHomeDetail:
            break;
        case GHSmartKitRequestTypeConfigureNetworkCategory:
            self.methodPath = GHSmartKit_Configure_Network_Category;
            break;
        case GHSmartKitRequestTypeConfigureNetworkCommon:
            self.methodPath = GHSmartKit_Configure_Network_Common;
            break;
        case GHSmartKitRequestTypeConfigureNetworkTokenHomeId:
            break;
        case GHSmartKitRequestTypeConfigureNetworkDevicesToken:
            break;
        case GHSmartKitRequestTypeConfigureNetworkGuide:
            break;
        case GHSmartKitRequestTypeRoomInfo:
            break;
        case GHSmartKitRequestTypeRoomAdd:
            self.requestMethod = GHNetworkRequestMethodPOST;
            self.contenType = GHNetworkContenTypeJSON;
            self.methodPath = GHSmartKit_Room_Add;
            self.serializerType = GHNetworkSerializerTypeJSON;
            break;
        case GHSmartKitRequestTypeRoomRemove:
            self.requestMethod = GHNetworkRequestMethodPOST;
            self.contenType = GHNetworkContenTypeJSON;
            self.serializerType = GHNetworkSerializerTypeJSON;
            break;
        case GHSmartKitRequestTypeRoomUpdate:
            self.requestMethod = GHNetworkRequestMethodPOST;
            self.contenType = GHNetworkContenTypeJSON;
            self.serializerType = GHNetworkSerializerTypeJSON;
            self.methodPath = GHSmartKit_Room_Update;
            break;
        case GHSmartKitRequestTypeDeviceAdd:
            self.requestMethod = GHNetworkRequestMethodPOST;
            self.contenType = GHNetworkContenTypeJSON;
            self.serializerType = GHNetworkSerializerTypeJSON;
            break;
        default:
            break;
    }
}

@end


@implementation GHSmartKitBaseReqeust

- (instancetype)init {
    self = [super init];
    if (self) {
        self.requestMethod = GHNetworkRequestMethodGET;
        self.contenType = GHNetworkContenTypeJSON;
        self.serializerType = GHNetworkSerializerTypeJSON;
        if (GHSmartUserManagerKit.share.userName) {
            self.baseURL = GHSmartUserManagerKit.share.userName;
        }
    }
    return self;
}

static NSArray *_ignores; // 忽略基类所有属性
+ (NSArray *)mj_ignoredPropertyNames {
    if (_ignores == nil) {
        unsigned int count;
        objc_property_t *properties = class_copyPropertyList(GHNetworkRequest.class, &count);
        NSMutableArray *temp = [NSMutableArray array];
        for (int i = 0; i < count; i++) {
            objc_property_t property = properties[i];
            const char *cName = property_getName(property);
            NSString *name = [NSString stringWithCString:cName encoding:NSUTF8StringEncoding];
            [temp addObject:name];
        }
        _ignores = temp.copy;
        free(properties);
    }
    return _ignores;
}

- (NSDictionary *)normalParams {
    return self.mj_keyValues;
}

@end


@implementation GHSmartMessageListRequestModel

- (instancetype)init {
    self = [super init];
    if (self) {
        self.requestMethod = GHNetworkRequestMethodGET;
        self.contenType = GHNetworkContenTypeJSON;
        self.serializerType = GHNetworkSerializerTypeJSON;
        self.methodPath = @"";
    }
    return self;
}

@end


@implementation GHSmartMessageDetailListRequestModel

- (instancetype)init {
    self = [super init];
    if (self) {
        self.requestMethod = GHNetworkRequestMethodGET;
        self.contenType = GHNetworkContenTypeJSON;
        self.serializerType = GHNetworkSerializerTypeJSON;
        self.methodPath = @"";
    }
    return self;
}

@end


@implementation GHSmartMessageListDeleteRequestModel

- (instancetype)init {
    self = [super init];
    if (self) {
        self.requestMethod = GHNetworkRequestMethodGET;
        self.contenType = GHNetworkContenTypeJSON;
        self.serializerType = GHNetworkSerializerTypeJSON;
        self.methodPath = @"";
    }
    return self;
}

@end

@implementation GHSmartMessageListReadRequestModel

- (instancetype)init {
    self = [super init];
    if (self) {
        self.requestMethod = GHNetworkRequestMethodGET;
        self.contenType = GHNetworkContenTypeJSON;
        self.serializerType = GHNetworkSerializerTypeJSON;
        self.methodPath = @"";
    }
    return self;
}

@end


@implementation GHSmartMessageSettingDNDRequestModel

- (instancetype)init {
    self = [super init];
    if (self) {
        self.requestMethod = GHNetworkRequestMethodGET;
        self.contenType = GHNetworkContenTypeJSON;
        self.serializerType = GHNetworkSerializerTypeJSON;
        self.methodPath = @"";
    }
    return self;
}

@end

@implementation GHSmartHomeAddMemberRequestModel

- (instancetype)init {
    self = [super init];
    if (self) {
        self.requestMethod = GHNetworkRequestMethodGET;
        self.contenType = GHNetworkContenTypeJSON;
        self.serializerType = GHNetworkSerializerTypeJSON;
        self.methodPath = @"";
    }
    return self;
}

@end
