//
//  GHSmartDeviceModel.m
//  GHSmartKit
//
//  Created by Qincc on 2021/6/24.
//

#import "GHSmartDeviceModel.h"
#import <MJExtension/MJExtension.h>

@implementation GHSmartDeviceModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{
        @"ID":@[@"id"]
    };
}

@end
