//
//  GHSmartDeviceManagerKit.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/24.
//

#import <Foundation/Foundation.h>
#import "GHCancelRequest.h"
#import "GHSmartDeviceModel.h"


NS_ASSUME_NONNULL_BEGIN

@interface GHSmartDeviceManagerKit : NSObject<GHCancelRequest>

/// Get the basic device information model
@property (nonatomic, strong, readonly) GHSmartDeviceModel *deviceModel;

+ (instancetype)deviceWithDeviceId:(NSString *)deviceId;

- (instancetype)init NS_UNAVAILABLE;

/// Get device infomaiton.
/// @param complete Called when the task finishes.
- (NSString *)getDeviceDetalWithComplete:(void(^)(GHSmartDeviceModel *deviceModel, NSError *error))complete;

/// Edit device name.
/// @param name The device name.
/// @param complete Called when the task finishes.
- (NSString *)updateName:(NSString *)name
                complete:(void(^)(id data, NSError *error))complete;

/// Edit device icon.
/// @param icon The device icon.
/// @param complete Called when the task finishes.
- (NSString *)updateIcon:(UIImage *)icon
                complete:(void(^)(id data, NSError *error))complete;

/// Remove device. Unbind the device with current user.
/// @param complete Called when the task finishes.
- (NSString *)removeDeviceWithComplete:(void(^)(id data, NSError *error))complete;

@end

NS_ASSUME_NONNULL_END
