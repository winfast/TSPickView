//
//  GHSmartDeviceModel.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/24.
//

#import <Foundation/Foundation.h>


@interface GHSmartDeviceModel : NSObject

@property (nonatomic, copy) NSString *deviceId;
@property (nonatomic, copy) NSString *productId;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *ID;
@property (nonatomic, copy) NSString *icon;
@property (nonatomic, copy) NSString *ownerId;
@property (nonatomic, copy) NSString *online;

//设备状态

@end

