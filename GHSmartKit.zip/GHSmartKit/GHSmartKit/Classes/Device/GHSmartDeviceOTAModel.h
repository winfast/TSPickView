//
//  GHSmartDeviceOTAModel.h
//  GHSmartKit
//
//  Created by Qincc on 2021/6/29.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GHSmartDeviceOTAModel : NSObject

@end

NS_ASSUME_NONNULL_END
