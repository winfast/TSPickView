//
//  GHSmartDeviceOTAModel.m
//  GHSmartKit
//
//  Created by Qincc on 2021/6/29.
//

#import "GHSmartDeviceOTAModel.h"

@implementation GHSmartDeviceOTAModel

@end
