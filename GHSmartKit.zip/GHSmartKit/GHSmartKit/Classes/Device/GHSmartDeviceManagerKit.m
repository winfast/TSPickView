//
//  GHSmartDeviceManagerKit.m
//  GHSmartKit
//
//  Created by Qincc on 2021/6/24.
//

#import "GHSmartDeviceManagerKit.h"
#import <GHNetworkModule/GHNetwork.h>
#import "GHSmartKitNetworkRequest.h"
#import "GHSmartConstValue.h"
#import <MJExtension/MJExtension.h>
#import "GHSmartKitStringDefine.h"

@interface GHSmartDeviceManagerKit ()

@property (nonatomic, copy) NSString *deviceId;

@end

@implementation GHSmartDeviceManagerKit

+ (instancetype)deviceWithDeviceId:(NSString *)deviceId {
    GHSmartDeviceManagerKit *deviceManagerKit = GHSmartDeviceManagerKit.alloc.init;
    deviceManagerKit.deviceId = deviceId;
    return deviceManagerKit;
}

- (NSString *)getDeviceDetalWithComplete:(void(^)(GHSmartDeviceModel *deviceModel, NSError *error))complete {
    GHSmartKitNetworkRequest *request = [GHSmartKitNetworkRequest.alloc initWithSmartKitRequestType:GHSmartKitRequestTypeDeviceDetail];
    request.methodPath = [NSString stringWithFormat:GHSmartKit_Device_Detial_DeviceId, self.deviceId];
    return [GHNetworkModule.share sendRequest:request cacheComplete:nil networkComplete:^(GHNetworkResponse *response) {
        if (response.status == GHNetworkResponseStatusSuccess) {
            !complete ?: complete(response.data, nil);
        } else {
            !complete ?: complete(nil, response.error);
        }
    }];
}

- (NSString *)updateName:(NSString *)name
                complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)updateIcon:(UIImage *)icon
                complete:(void(^)(id data, NSError *error))complete {
    return nil;
}

- (NSString *)removeDeviceWithComplete:(void(^)(id data, NSError *error))complete {
    return nil;
}


+ (void)cancelRequest:(NSString *)reqeustId {
    [GHNetworkModule.share cancelRequestWithRequestID:reqeustId];
}

@end
