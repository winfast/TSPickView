//
//  GHHomeDetailViewController.h
//  GHSmartKit_Example
//
//  Created by Qincc on 2021/7/2.
//  Copyright © 2021 Cuco Inc. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GHHomeDetailViewController : UIViewController

@property (nonatomic, copy) NSString *homeId;

@end

