//
//  GHAppDelegate.h
//  GHSmartKit
//
//  Created by Qincc on 06/23/2021.
//  Copyright (c) 2021 Qincc. All rights reserved.
//

@import UIKit;

@interface GHAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
