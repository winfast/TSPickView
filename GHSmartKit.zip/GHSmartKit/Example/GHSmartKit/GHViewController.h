//
//  GHViewController.h
//  GHSmartKit
//
//  Created by Qincc on 06/23/2021.
//  Copyright (c) 2021 Qincc. All rights reserved.
//

@import UIKit;

@interface GHViewController : UIViewController

@end
