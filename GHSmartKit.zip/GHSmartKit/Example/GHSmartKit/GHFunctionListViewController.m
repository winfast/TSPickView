//
//  GHFunctionListViewController.m
//  GHSmartKit_Example
//
//  Created by Qincc on 2021/7/3.
//  Copyright © 2021 Cuco Inc. All rights reserved.
//

#import "GHFunctionListViewController.h"
#import <GHSmartKit/GHSmartKit.h>
#import <Masonry/Masonry.h>
#import <ReactiveObjC/ReactiveObjC.h>
#import "GHHomeDetailViewController.h"

@interface GHFunctionListViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, copy) NSArray *functionsArray;
@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) UIImageView *imageView;

@end

@implementation GHFunctionListViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationItem.title = @"功能列表";
    
    self.functionsArray = @[
        @"家庭",
        @"配网",
        @"test",
    ];
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    
    
    [RACObserve(self.imageView, image) subscribeNext:^(id  _Nullable x) {
        
    }];
}

#pragma mark - UITableViewDelegate, UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.functionsArray.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
    cell.textLabel.text = self.functionsArray[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        [self.navigationController pushViewController:[[NSClassFromString(@"GHViewController") alloc] init] animated:YES];
    } else if (1 == indexPath.row){
        [self.navigationController pushViewController:[[NSClassFromString(@"GHDeviceCategoryViewController") alloc] init] animated:YES];
    } else {
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [UITableView.alloc initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorColor = [[UIColor blackColor] colorWithAlphaComponent:0.1];
        [_tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"UITableViewCell"];
        _tableView.rowHeight = 44;
        _tableView.estimatedRowHeight = 44;
    }
    return _tableView;
}

@end
