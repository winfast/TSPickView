//
//  NetworkModuleLaunch.m
//  GHome
//
//  Created by Qincc on 2020/12/14.
//

#import "NetworkModuleLaunch.h"
#import <GHNetworkModule/GHNetwork.h>

@implementation NetworkModuleLaunch

+ (instancetype)shareLaunch {
    static NetworkModuleLaunch *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
        [instance executeCommand];
    });
    return instance;
}


// MARK: Protocol
- (void)executeCommand {
    // MARK: ⚙ 网络请求组件基础配置
#ifdef DEBUG
    GHNetworkConfigure.share.generalServer = @"http://192.168.10.201:9400/webapi";
#else
	GHNetworkConfigure.share.generalServer = @"https://openiot.gosund.com";
#endif
    GHNetworkConfigure.share.enableDebug = YES;
    GHNetworkConfigure.share.useCache = NO;
	
    GHNetworkConfigure.share.respondeSuccessKeys = @[@"code"];   /** 与后端约定的请求结果状态字段, 默认 code, status */
    GHNetworkConfigure.share.respondeHttpCodeKeys = @[@"errcode"];
    GHNetworkConfigure.share.respondeMsgKeys = @[@"errmsg"];       /** 与后端约定的请求结果消息字段集合, 默认 message, msg */
    GHNetworkConfigure.share.respondeDataKeys = @[@"result"];      /** 与后端约定的请求结果数据字段集合, 默认 data */
    GHNetworkConfigure.share.respondeSuccessCode = @"200";                  /** 与后端约定的请求成功code，默认为 200 */
    GHNetworkConfigure.share.respondeHttpCode = @"0";
	GHNetworkConfigure.share.startReachability = NO;
    GHNetworkConfigure.share.generalHeaders = @{
        @"platform":@"iphone",
		@"appVersion":[NSBundle.mainBundle objectForInfoDictionaryKey:@"CFBundleShortVersionString"],
		@"os":@"iOS",
		@"osSystem":[[UIDevice currentDevice] systemVersion],
		@"requestType":@"app",
		@"timezone":[[NSTimeZone localTimeZone] name],
    };
//    // 全局静态请求头参数设置
//    GPNetworkConfigure.shareInstance.generalHeaders = ({
//        NSMutableDictionary *temp = [[NSMutableDictionary alloc] init];
//        [temp setValue:@"iOS" forKey:@"platform"];
//        [temp setValue:[NSBundle.mainBundle.infoDictionary objectForKey:@"CFBundleShortVersionString"] forKey:@"version"];
//        [temp setValue:@"App Store" forKey:@"channel"];
//        temp;
//    });
//
//
//    // 全局动态请求头参数设置，token，sign等 head里面的内容是字符串
	GHNetworkConfigure.share.generalDynamicHeaders = ^NSDictionary<NSString *,NSString *> * _Nonnull(NSDictionary *parameters, BOOL requireToken) {
        NSMutableDictionary *temp = [NSMutableDictionary dictionaryWithCapacity:1];
		[temp setValue:@"eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJjb20uY3Vjby5zc28iLCJzdWIiOiJhY2Nlc3MtdG9rZW4iLCJhdWQiOiLljKHnjonpup8iLCJqdGkiOiI3MTcyNjU5ODAxNDQ3NDY0OTYiLCJpYXQiOjE2MjUwMzE4MTgsImV4cCI6MTYyNTYzNjYxOH0.yOVCEH4Ko-EiRS-waBXm8F69hew6Hoog8Uifg-ISGQ4" forKey:@"token"];
        return temp;
    };
	
	//监测手机网络 4G/WIFI/NOIntnet
//	[ZYNetworkAccessibility setAlertEnable:NO];
//	[ZYNetworkAccessibility setStateDidUpdateNotifier:^(ZYNetworkAccessibleState state) {
//		NSLog(@"setStateDidUpdateNotifier > %zd", state);
//		if (state == ZYNetworkRestricted || state == ZYNetworkUnknown) {
//			[GHConfigDeviceManager share].isNetPermissOk = NO;
//		}else{
//			[GHConfigDeviceManager share].isNetPermissOk = YES;
//		}
//	}];
//	[ZYNetworkAccessibility start];
//
//    // 全局动态公参
////    GPNetworkConfigure.shareInstance.generalDynamicParameters = ^NSDictionary<NSString *,id> * _Nonnull{
////        NSMutableDictionary *temp = [NSMutableDictionary dictionaryWithCapacity:2];
////        [temp setValue:@"506878" forKey:@"userId"];
////        [temp setValue:@"44bd15964b49474c94a6c5979c8e3318" forKey:@"userTypeId"];
////        return temp;
////    };
//
    // 请求结果统一回调处理
//	GHNetworkConfigure.share.responseUnifiedCallBack = ^(id _Nonnull response) {
//        // MARK: 用户模块 token 过期 code为 230；单点登录code为231
//		if ([response isKindOfClass:NSClassFromString(@"NSError")]) {
//			if ([(NSError *)response code] == 401){ //登录过期
//				[[GHUserInfo share] clearInfoCompletion:nil];
//			}
//		} else { //请求成功
//		}
//    };
}

- (void)stopMonitoring {
	[GHNetworkReachabilityManager stopMonitoring];
}

- (void)startMonitoring {
	[GHNetworkReachabilityManager startMonitoring];
}

- (void)logout {
	//推出登录要不要清楚缓存， 产品定义
	[GHNetworkModule.share clearCache:NO];
}

- (void)initSystemNotify {
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidEnterBackgroundNotification) name:UIApplicationDidEnterBackgroundNotification object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActiveNotification) name:UIApplicationDidBecomeActiveNotification object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillResignActiveNotification) name:UIApplicationWillResignActiveNotification object:nil];
	});
}

- (void)applicationDidEnterBackgroundNotification {
	[self stopMonitoring];
}

- (void)applicationDidBecomeActiveNotification {
	[self startMonitoring];
}

- (void)applicationWillResignActiveNotification {
	[self stopMonitoring];
}

@end
