//
//  main.m
//  GHSmartKit
//
//  Created by Qincc on 06/23/2021.
//  Copyright (c) 2021 Qincc. All rights reserved.
//

@import UIKit;
#import "GHAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([GHAppDelegate class]));
    }
}
