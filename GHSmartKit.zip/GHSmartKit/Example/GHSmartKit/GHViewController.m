//
//  GHViewController.m
//  GHSmartKit
//
//  Created by Qincc on 06/23/2021.
//  Copyright (c) 2021 Qincc. All rights reserved.
//

#import "GHViewController.h"
#import <GHSmartKit/GHSmartKit.h>
#import <Masonry/Masonry.h>
#import <ReactiveObjC/ReactiveObjC.h>
#import "GHHomeDetailViewController.h"

@interface GHViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) GHSmartHomeManagerKit *homeManagerKit;

@property (nonatomic, strong) UITableView *tableView;

@end

@implementation GHViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.navigationItem.title = @"家庭列表";
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Add" style:UIBarButtonItemStylePlain target:self action:@selector(clickRightBtn:)];
    
    
    
//    UIButton *requstBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    requstBtn.frame = CGRectMake(100, 100, 100, 100);
//    requstBtn.backgroundColor = UIColor.yellowColor;
//    [requstBtn setTitle:@"家庭列表" forState:UIControlStateNormal];
//    [requstBtn addTarget:self action:@selector(clickRequestBtn:) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:requstBtn];
//
//    UIButton *requstBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    requstBtn.frame = CGRectMake(100, 100, 100, 100);
//    requstBtn.backgroundColor = UIColor.yellowColor;
//    [requstBtn setTitle:@"家庭详情" forState:UIControlStateNormal];
//    [requstBtn addTarget:self action:@selector(clickRequestBtn:) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:requstBtn];
    
    @weakify(self);
    [self.homeManagerKit getHomeListWithComplete:^(NSArray<GHSmartHomeModel *> *homes, NSError *error) {
        @strongify(self);
        if (error) {
            
        } else {
            //数据请求完成
            [self.tableView reloadData];
        }
    }];
}

- (void)clickRightBtn:(id)sender {
    
}

#pragma mark - UITableViewDelegate, UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.homeManagerKit.homes.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
    cell.textLabel.text = self.homeManagerKit.homes[indexPath.row].name;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    GHHomeDetailViewController *vc = GHHomeDetailViewController.alloc.init;
    vc.homeId = self.homeManagerKit.homes[indexPath.row].ID;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (GHSmartHomeManagerKit *)homeManagerKit {
    if (!_homeManagerKit) {
        _homeManagerKit = GHSmartHomeManagerKit.alloc.init;
    }
    return _homeManagerKit;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [UITableView.alloc initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorColor = [[UIColor blackColor] colorWithAlphaComponent:0.1];
        [_tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"UITableViewCell"];
        _tableView.rowHeight = 44;
        _tableView.estimatedRowHeight = 44;
    }
    return _tableView;
}

@end
