//
//  GHDeviceCategoryViewController.h
//  GHSmartKit_Example
//
//  Created by Qincc on 2021/7/3.
//  Copyright © 2021 Cuco Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GHDeviceCategoryViewController : UIViewController

@property (nonatomic, copy) NSString *homeId;

@end

NS_ASSUME_NONNULL_END
