//
//  GHDeviceCategoryViewController.m
//  GHSmartKit_Example
//
//  Created by Qincc on 2021/7/3.
//  Copyright © 2021 Cuco Inc. All rights reserved.
//

#import "GHDeviceCategoryViewController.h"
#import <GHSmartKit/GHSmartKit.h>
#import <Masonry/Masonry.h>
#import <ReactiveObjC/ReactiveObjC.h>

@interface GHDeviceCategoryViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) GHSmartDeviceCategoryManagerKit *deviceManagerKit;

@property (nonatomic, strong) GHSmartDeviceCategoryModel *deviceCategoryModel;

@property (nonatomic, copy) UITableView *tableView;

@end

@implementation GHDeviceCategoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    @weakify(self);
    [self.deviceManagerKit getDeviceCategoryWithComplete:^(id data, NSError *error) {
        if (error) {
            return;
        }
        @strongify(self);
        self.deviceCategoryModel = data;
        [self.tableView reloadData];
    }];
}

- (void)startAPConfig {
    
}

#pragma mark - UITableViewDelegate, UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return self.deviceCategoryModel.defaultLevel2List.count;
    } else if (1 == section) {
        return self.deviceCategoryModel.defaultWglist.count;
    } else {
        return self.deviceCategoryModel.level1List.count;
    }
    return 0;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
    if (0 == indexPath.section) {
        GHSmartDefaultLevel2ListModel *model = self.deviceCategoryModel.defaultLevel2List[indexPath.row];
        cell.textLabel.text = [NSString stringWithFormat:@"%@  %@  %d", model.name, model.tagCode, model.level3Items.count];
    } else if (1 == indexPath.section) {
        GHDefaultWglistModel *model = self.deviceCategoryModel.defaultWglist[indexPath.row];
        cell.textLabel.text = [NSString stringWithFormat:@"%@", model.name];
    } else {
        GHSmartLevel1ListModel *model = self.deviceCategoryModel.level1List[indexPath.row];
        cell.textLabel.text = [NSString stringWithFormat:@"%@  %@  %@", model.name, model.level1Code, model.type];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UILabel *label = UILabel.alloc.init;
    label.text = @"111";
    return label;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 30;
}



- (GHSmartDeviceCategoryManagerKit *)deviceManagerKit {
    if (!_deviceManagerKit) {
        _deviceManagerKit = [GHSmartDeviceCategoryManagerKit.alloc init];
    }
    return _deviceManagerKit;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [UITableView.alloc initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = 44;
        _tableView.estimatedRowHeight = 44;
        _tableView.separatorColor = [[UIColor blackColor] colorWithAlphaComponent:0.1];
        [_tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"UITableViewCell"];
    }
    return _tableView;
}


@end
