//
//  GHHomeDetailViewController.m
//  GHSmartKit_Example
//
//  Created by Qincc on 2021/7/2.
//  Copyright © 2021 Cuco Inc. All rights reserved.
//

#import "GHHomeDetailViewController.h"
#import <GHSmartKit/GHSmartKit.h>
#import <Masonry/Masonry.h>
#import <ReactiveObjC/ReactiveObjC.h>
#include "GHDeviceCategoryViewController.h"

@interface GHHomeDetailViewController ()<UITableViewDelegate, UITableViewDataSource, GHSmartActivatorDelegate>

@property (nonatomic, strong) GHSmartHomeKit *homeKit;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) GHSmartActivator *activator;

@property (nonatomic, strong) NSString *token;


@end

@implementation GHHomeDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Token" style:UIBarButtonItemStylePlain target:self action:@selector(clickRightBtn:)];
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    @weakify(self);
    [self.homeKit getHomeDetailWithComplete:^(GHSmartHomeModel *homeModel, NSError *error) {
        if (error) {
            return;
        }
        @strongify(self);
        self.navigationItem.title = self.homeKit.homeModel.name;
        [self.tableView reloadData];
    }];
}

- (void)clickRightBtn:(id)sender {
    GHSmartDeviceCategoryManagerKit *deviceManagerKit = [GHSmartDeviceCategoryManagerKit.alloc init];
    [deviceManagerKit getDeviceConfigureNetworkTokenWithHomeId:self.homeId complete:^(id  _Nonnull data, NSError * _Nonnull error) {
        self.token = data;
    }];
}

- (void)startAPConfig {
    GHSmartActivator *activator = GHSmartActivator.sharedInstance;
    activator.delegate = self;
    [activator startConfigWiFi:GHActivatorModeAP ssid:@"Alcatel 3X" password:@"1234567890" token:self.token timeout:100];
}

- (GHSmartHomeKit *)homeKit {
    if (!_homeKit) {
        _homeKit = [GHSmartHomeKit homeWithHomeId:self.homeId];
    }
    return _homeKit;
}

#pragma mark - UITableViewDelegate, UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.homeKit.roomList.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
    cell.textLabel.text = [NSString stringWithFormat:@"%@   %lu个设备", self.homeKit.roomList[indexPath.row].name, (unsigned long)self.homeKit.roomList[indexPath.row].devices.count];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self startAPConfig];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)activator:(GHSmartActivator *)activator didReceiveDevice:(NSArray<GHSmartDeviceModel *> *)devicesId step:(GHActivatorStep)step error:(NSError *)error {
    
}

#pragma mark - lazy

- (GHSmartHomeKit *)homeManagerKit {
    if (!_homeKit) {
        _homeKit = [GHSmartHomeKit homeWithHomeId:self.homeId];
    }
    return _homeKit;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [UITableView.alloc initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = 44;
        _tableView.estimatedRowHeight = 44;
        _tableView.separatorColor = [[UIColor blackColor] colorWithAlphaComponent:0.1];
        [_tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"UITableViewCell"];
    }
    return _tableView;
}

@end
