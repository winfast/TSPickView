//
//  NetworkModuleLaunch.h
//  GHome
//
//  Created by Qincc on 2020/12/14.
//

#import <Foundation/Foundation.h>


@interface NetworkModuleLaunch : NSObject

+ (instancetype)shareLaunch;


@end

